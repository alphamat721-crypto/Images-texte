# ImageTexte v1.0.1

Application Android native en Java : reconnaissance de texte dans les images (OCR), bibliothèque de textes, correction, recherche, ajout de texte sur une image et export vers un dossier choisi (y compris une carte SD compatible avec le sélecteur Android).

## Correction installation APK

Le build Release est maintenant explicitement signé avec la configuration de signature `debug` d'Android Gradle Plugin. Cela produit un APK signé installable directement sur un appareil Android. Cette signature est destinée aux installations de test et à la distribution privée. Pour une publication sur Google Play ou des mises à jour pérennes hors de ce dépôt, il faudra utiliser une clé de signature privée conservée en lieu sûr.

Si une ancienne version ImageTexte est déjà installée avec une autre signature, Android peut refuser la mise à jour : désinstallez l'ancienne version (après avoir exporté vos textes) puis installez la nouvelle APK.

## Compilation GitHub

1. Déposer `ImageTexte_v1.0.1.zip` à la racine du dépôt.
2. Copier `.github/workflows/compile-imagetexte.yml` dans le dépôt à ce même chemin.
3. Lancer `Actions > Compiler ImageTexte > Run workflow`, ou pousser le ZIP.
4. Télécharger l'APK signé dans les artefacts ou dans GitHub Releases.

Le workflow reprend la méthode du build HV+ : Java 17, Gradle 8.11.1, Android SDK 36, contrôle des fichiers, compilation Release, vérification de signature et publication.

## Configuration technique

- `applicationId`: `com.imagetexte.app`
- `minSdk`: 26 (Android 8.0)
- `targetSdk`: 35
- `compileSdk`: 36
- Java 17
- OCR : Google ML Kit Text Recognition (Latin)

Le modèle OCR peut nécessiter un téléchargement initial selon la configuration de l'appareil et la disponibilité du service.


### Éditeur photo avancé (1.0.3)
- Rotation du texte par pas de 15 degrés.
- Huit poignées de sélection pour le redimensionnement.
- Contour du texte avec plusieurs couleurs.
- Arrière-plan coloré ou semi-transparent derrière le texte.
- Déplacement tactile et plusieurs calques de texte.
