plugins { id("com.android.application") }

android {
    namespace = "com.imagetexte.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.imagetexte.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.0.3"
    }
    // Release APK signed with the standard debug keystore so it can be installed directly.
    // For Play Store publication, replace this with a private release keystore.
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
