package bf.alphamat.imagetexte;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Configuration;

/**
 * Avertissement avant de quitter l'appli (touche ou geste Retour depuis l'écran d'accueil).
 * « Rester » ou Retour referme la fenêtre ; « Quitter » ferme l'appli comme le ferait Android.
 */
public final class Sortie {

    private static AlertDialog ouverte;

    private Sortie() {
    }

    /**
     * @param style   fenêtre aux couleurs de l'appli (peut être null : style clair ou sombre du téléphone)
     * @param quitter ce qu'Android aurait fait sans la question (en général super.onBackPressed())
     */
    public static void demander(final Activity a, AlertDialog.Builder style, final Runnable quitter) {
        if (a == null || a.isFinishing()) return;
        if (ouverte != null && ouverte.isShowing()) return; // déjà affichée
        CharSequence nom;
        try {
            nom = a.getApplicationInfo().loadLabel(a.getPackageManager());
        } catch (Exception e) {
            nom = "l'appli";
        }
        AlertDialog.Builder b = style;
        if (b == null) {
            boolean nuit = (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            b = new AlertDialog.Builder(a, nuit ? android.R.style.Theme_Material_Dialog_Alert
                    : android.R.style.Theme_Material_Light_Dialog_Alert);
        }
        try {
            ouverte = b.setTitle("Quitter " + nom + " ?")
                    .setMessage("Voulez-vous vraiment fermer " + nom + " ?")
                    .setNegativeButton("Rester", null)
                    .setPositiveButton("Quitter", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            ouverte = null;
                            quitter.run();
                        }
                    })
                    .setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface d) {
                            ouverte = null; // pas de référence gardée sur l'activité
                        }
                    })
                    .show();
        } catch (Exception e) {
            // Fenêtre impossible (activité en cours de fermeture) : on laisse Android faire.
            ouverte = null;
            quitter.run();
        }
    }
}
