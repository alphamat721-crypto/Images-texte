package bf.alphamat.imagetexte;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Écran principal : onglets Lire, Textes et Retouche. */
public class MainActivity extends Activity {

    private static final int CHOISIR_LECTURE = 1, CHOISIR_RETOUCHE = 2, PHOTO = 3;
    private static final int ONGLET_LIRE = 0, ONGLET_TEXTES = 1, ONGLET_RETOUCHE = 2;

    private Visuel.Theme t;
    private int themeIndex;
    private LinearLayout contenu, barreOnglets;
    private ScrollView defil;
    private int onglet = ONGLET_LIRE;
    private String recherche = "";
    private String photoChemin;
    private boolean photoPourRetouche;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MisesAJour.auDemarrage(this);
        if (b != null) {
            onglet = b.getInt("onglet", ONGLET_LIRE);
            photoChemin = b.getString("photo");
            photoPourRetouche = b.getBoolean("photo_retouche", false);
        }
        themeIndex = Prefs.i(this, Prefs.THEME, 0);
        t = Visuel.theme(this);
        Visuel.barres(this, t);
        construire();
        montrer(onglet);
        if (b == null) {
            App.travail().execute(() -> Images.nettoyer(getApplicationContext()));
            if (!traiterPartage(getIntent()) && !Prefs.b(this, Prefs.PREMIER, false)) bienvenue();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        o.putInt("onglet", onglet);
        o.putString("photo", photoChemin);
        o.putBoolean("photo_retouche", photoPourRetouche);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        traiterPartage(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.i(this, Prefs.THEME, 0) != themeIndex) {
            recreate();
            return;
        }
        if (onglet != ONGLET_RETOUCHE) montrer(onglet); // la liste des textes a pu changer
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    // ------------------------------------------------------------------ Structure

    private void construire() {
        FrameLayout racine = new FrameLayout(this);
        racine.addView(new Decor(this, t), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = Ui.colonne(this);

        LinearLayout entete = Ui.ligne(this);
        entete.setPadding(dp(16), dp(14), dp(8), dp(6));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.icone_3d);
        entete.addView(logo, Ui.lpMarges(this, dp(40), dp(40), 0, 0, 10, 0));
        LinearLayout tit = Ui.colonne(this);
        tit.addView(Ui.texte(this, "Image Texte", 22, t.texte, true));
        tit.addView(Ui.texte(this, "v" + App.version() + (BuildConfig.LITE ? " • Lite" : ""), 12, t.texteDoux, false));
        entete.addView(tit, Ui.lpPoids(1));
        TextView aide = Ui.texte(this, "❓", 21, t.texte, false);
        aide.setPadding(dp(10), dp(6), dp(10), dp(6));
        aide.setContentDescription("Aide");
        aide.setOnClickListener(v -> startActivity(new Intent(this, AideActivity.class)));
        entete.addView(aide);
        TextView reg = Ui.texte(this, "⚙", 22, t.texte, false);
        reg.setPadding(dp(10), dp(6), dp(10), dp(6));
        reg.setContentDescription("Réglages");
        reg.setOnClickListener(v -> startActivity(new Intent(this, ReglagesActivity.class)));
        entete.addView(reg);
        col.addView(entete);

        defil = new ScrollView(this);
        defil.setFillViewport(true);
        defil.setVerticalScrollBarEnabled(false);
        contenu = Ui.colonne(this);
        contenu.setPadding(0, 0, 0, dp(20));
        defil.addView(contenu);
        col.addView(defil, new LinearLayout.LayoutParams(-1, 0, 1));

        barreOnglets = Ui.ligne(this);
        barreOnglets.setBackground(Visuel.carte3D(this, t, 22));
        barreOnglets.setPadding(dp(6), dp(6), dp(6), dp(10));
        String[][] o = {{"🔤", "Lire"}, {"📚", "Textes"}, {"🎨", "Retouche"}};
        for (int i = 0; i < o.length; i++) {
            final int k = i;
            LinearLayout b = Ui.colonne(this);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(6), 0, dp(6));
            b.addView(Ui.texte(this, o[i][0], 20, t.texte, false));
            TextView l = Ui.texte(this, o[i][1], 12, t.texte, true);
            l.setGravity(Gravity.CENTER);
            b.addView(l);
            b.setClickable(true);
            b.setOnClickListener(v -> montrer(k));
            Ui.pression(b);
            barreOnglets.addView(b, Ui.lpMarges(this, 0, -2, 4, 0, 4, 0));
            ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1;
        }
        col.addView(barreOnglets, Ui.lpMarges(this, -1, -2, 10, 0, 10, 8));

        racine.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
    }

    private void montrer(int o) {
        boolean change = o != onglet;
        onglet = o;
        for (int i = 0; i < barreOnglets.getChildCount(); i++) {
            LinearLayout b = (LinearLayout) barreOnglets.getChildAt(i);
            boolean actif = i == o;
            b.setBackground(actif ? Visuel.puce(this, t, true) : null);
            ((TextView) b.getChildAt(1)).setTextColor(actif ? 0xFFFFFFFF : t.texte);
        }
        int y = defil.getScrollY();
        contenu.removeAllViews();
        if (o == ONGLET_LIRE) ongletLire();
        else if (o == ONGLET_TEXTES) ongletTextes();
        else ongletRetouche();
        TextView autres = Ui.texte(this, "Mes autres applis et logiciels ›", 12.5f, t.texteDoux, false);
        autres.setGravity(Gravity.CENTER);
        autres.setPadding(dp(20), dp(22), dp(20), dp(4));
        autres.setOnClickListener(v -> Ui.autresApplis(this, t));
        contenu.addView(autres);
        if (change) defil.scrollTo(0, 0);
        else defil.post(() -> defil.scrollTo(0, y));
    }

    private LinearLayout carte() {
        LinearLayout c = Ui.colonne(this);
        c.setBackground(Visuel.carte3D(this, t, 20));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        contenu.addView(c, Ui.lpMarges(this, -1, -2, 14, 6, 14, 6));
        return c;
    }

    private TextView grosBouton(LinearLayout parent, String s, int couleur, View.OnClickListener cl) {
        TextView b = Ui.bouton(this, s, couleur, 0xFFFFFFFF);
        b.setOnClickListener(cl);
        parent.addView(b, Ui.lpMarges(this, -1, -2, 0, 6, 0, 4));
        return b;
    }

    // ------------------------------------------------------------------ Onglet Lire

    private void ongletLire() {
        LinearLayout c = carte();
        c.addView(Ui.texte(this, "Extraire le texte de vos images", 19, t.texte, true));
        TextView d = Ui.texte(this, "Documents, cahiers, affiches, captures d'écran, ordonnances… "
                + "Une ou plusieurs images d'un coup. Tout se fait sur le téléphone, même sans Internet.", 13.5f, t.texteDoux, false);
        d.setPadding(0, dp(4), 0, dp(8));
        c.addView(d);
        grosBouton(c, "📷  Photographier un texte", t.accent, v -> prendrePhoto(false));
        grosBouton(c, "🖼  Choisir une ou plusieurs images", Visuel.sombre(t.accent2, 0.1f), v -> choisirImages(CHOISIR_LECTURE, true));

        LinearLayout opt = Ui.ligne(this);
        opt.setPadding(0, dp(10), 0, 0);
        final TextView puce = Ui.texte(this, "", 13.5f, t.texte, true);
        puce.setPadding(dp(12), dp(8), dp(12), dp(8));
        Runnable maj = () -> {
            boolean a = Prefs.ameliorer(this);
            puce.setText((a ? "✓ " : "") + "✨ Améliorer l'image avant la lecture");
            puce.setBackground(Visuel.puce(this, t, a));
            puce.setTextColor(a ? 0xFFFFFFFF : t.texte);
        };
        maj.run();
        puce.setOnClickListener(v -> {
            Prefs.setB(this, Prefs.AMELIORER, !Prefs.ameliorer(this));
            maj.run();
        });
        Ui.pression(puce);
        opt.addView(puce);
        c.addView(opt);
        TextView note = Ui.texte(this, "À activer pour les photos sombres, floues ou peu contrastées.", 12, t.texteDoux, false);
        note.setPadding(dp(4), dp(4), 0, 0);
        c.addView(note);

        List<Bibliotheque.Fiche> recents = Bibliotheque.liste(this, null);
        if (!recents.isEmpty()) {
            TextView tt = Ui.texte(this, "Derniers textes lus", 15, t.texte, true);
            tt.setPadding(dp(20), dp(14), dp(20), dp(2));
            contenu.addView(tt);
            for (int i = 0; i < Math.min(3, recents.size()); i++) ligneTexte(recents.get(i));
            TextView tous = Ui.texte(this, "Voir tous les textes (" + recents.size() + ") ›", 13.5f, t.accent, true);
            tous.setPadding(dp(20), dp(8), dp(20), 0);
            tous.setOnClickListener(v -> montrer(ONGLET_TEXTES));
            contenu.addView(tous);
        }
    }

    // ------------------------------------------------------------------ Onglet Textes

    private TextView compteur;
    private LinearLayout listeTextes;

    private void ongletTextes() {
        LinearLayout c = carte();
        c.setPadding(dp(14), dp(10), dp(14), dp(10));
        EditText cherche = new EditText(this);
        cherche.setSingleLine(true);
        cherche.setHint("🔎 Rechercher dans vos textes");
        cherche.setTextColor(t.texte);
        cherche.setHintTextColor(t.texteDoux);
        cherche.setBackground(null);
        cherche.setText(recherche);
        cherche.setSelection(cherche.getText().length());
        c.addView(cherche);
        compteur = Ui.texte(this, "", 12.5f, t.texteDoux, false);
        compteur.setPadding(dp(20), dp(2), dp(20), dp(2));
        contenu.addView(compteur);
        listeTextes = Ui.colonne(this);
        contenu.addView(listeTextes);
        cherche.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                recherche = s.toString();
                remplirTextes();
            }
        });
        remplirTextes();
    }

    private void remplirTextes() {
        if (listeTextes == null) return;
        listeTextes.removeAllViews();
        List<Bibliotheque.Fiche> l = Bibliotheque.liste(this, recherche);
        int total = Bibliotheque.nombre(this);
        if (total == 0) {
            compteur.setText("");
            LinearLayout vide = Ui.colonne(this);
            vide.setBackground(Visuel.carte3D(this, t, 20));
            vide.setPadding(dp(18), dp(18), dp(18), dp(18));
            vide.addView(Ui.texte(this, "📚 Aucun texte pour l'instant", 16, t.texte, true));
            TextView d = Ui.texte(this, "Les textes lus dans vos images sont rangés ici. Commencez par l'onglet « Lire ».", 13.5f, t.texteDoux, false);
            d.setPadding(0, dp(6), 0, 0);
            vide.addView(d);
            listeTextes.addView(vide, Ui.lpMarges(this, -1, -2, 14, 6, 14, 6));
            return;
        }
        compteur.setText(recherche.trim().isEmpty() ? total + (total > 1 ? " textes" : " texte")
                : l.size() + " sur " + total + " • appui long sur un texte : copier, partager, supprimer");
        if (l.isEmpty()) {
            TextView r = Ui.texte(this, "Aucun texte ne contient « " + recherche.trim() + " ».", 14, t.texteDoux, false);
            r.setPadding(dp(20), dp(12), dp(20), 0);
            listeTextes.addView(r);
            return;
        }
        LinearLayout sauve = contenu;
        contenu = listeTextes;
        for (Bibliotheque.Fiche f : l) ligneTexte(f);
        contenu = sauve;
    }

    private void ligneTexte(Bibliotheque.Fiche f) {
        LinearLayout lg = Ui.ligne(this);
        lg.setBackground(Visuel.carte3D(this, t, 16));
        lg.setPadding(dp(10), dp(10), dp(12), dp(12));
        String v = f.vignette(this);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(Visuel.puce(this, t, false));
        if (v != null) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            try {
                Bitmap bm = BitmapFactory.decodeFile(v, o);
                if (bm != null) iv.setImageBitmap(bm);
            } catch (Throwable ignore) {
            }
        }
        lg.addView(iv, Ui.lpMarges(this, dp(52), dp(52), 0, 0, 12, 0));
        LinearLayout tx = Ui.colonne(this);
        TextView ti = Ui.texte(this, f.titre, 15, t.texte, true);
        ti.setSingleLine(true);
        ti.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tx.addView(ti);
        String apercu = f.texte.replace('\n', ' ').trim();
        TextView ap = Ui.texte(this, apercu, 12.5f, t.texteDoux, false);
        ap.setMaxLines(2);
        ap.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tx.addView(ap);
        tx.addView(Ui.texte(this, Ui.date(f.date), 11, t.accent, false));
        lg.addView(tx, Ui.lpPoids(1));
        TextView copier = Ui.texte(this, "📋", 18, t.texte, false);
        copier.setPadding(dp(10), dp(6), dp(2), dp(6));
        copier.setContentDescription("Copier");
        copier.setOnClickListener(x -> Galerie.copier(this, f.texte));
        lg.addView(copier);
        lg.setClickable(true);
        lg.setOnClickListener(x -> ouvrirTexte(f.id));
        lg.setOnLongClickListener(x -> {
            menuTexte(f);
            return true;
        });
        Ui.pression(lg);
        contenu.addView(lg, Ui.lpMarges(this, -1, -2, 14, 4, 14, 4));
    }

    private void ouvrirTexte(String id) {
        Intent i = new Intent(this, TexteActivity.class);
        i.putExtra(TexteActivity.EXTRA_ID, id);
        startActivity(i);
    }

    private void menuTexte(Bibliotheque.Fiche f) {
        String[] choix = {"📖 Ouvrir", "📋 Copier", "📤 Partager", "🗑 Supprimer"};
        Ui.dialogue(this, t).setTitle(f.titre).setItems(choix, (d, w) -> {
            switch (w) {
                case 0:
                    ouvrirTexte(f.id);
                    break;
                case 1:
                    Galerie.copier(this, f.texte);
                    break;
                case 2:
                    Galerie.partagerTexte(this, f.texte);
                    break;
                default:
                    Ui.dialogue(this, t).setTitle("Supprimer ce texte ?")
                            .setNegativeButton("Annuler", null)
                            .setPositiveButton("Supprimer", (d2, w2) -> {
                                Bibliotheque.supprimer(this, f.id);
                                montrer(onglet);
                            }).show();
            }
        }).show();
    }

    // ------------------------------------------------------------------ Onglet Retouche

    private void ongletRetouche() {
        LinearLayout c = carte();
        c.addView(Ui.texte(this, "Retoucher une image", 19, t.texte, true));
        TextView d = Ui.texte(this, "Rognez, redressez, embellissez, écrivez ou dessinez sur vos photos, puis enregistrez-les dans la galerie ou partagez-les.", 13.5f, t.texteDoux, false);
        d.setPadding(0, dp(4), 0, dp(8));
        c.addView(d);
        grosBouton(c, "🖼  Ouvrir une image", t.accent, v -> choisirImages(CHOISIR_RETOUCHE, false));
        grosBouton(c, "📷  Prendre une photo", Visuel.sombre(t.accent2, 0.1f), v -> prendrePhoto(true));

        String[][] outils = {
                {"✂️", "Rogner", "Libre, carré, 4:3, 16:9… pour garder l'essentiel"},
                {"🔄", "Pivoter et redresser", "Quart de tour, miroir, et redressement fin au demi-degré près"},
                {"☀️", "Réglages", "Luminosité, contraste, saturation, chaleur"},
                {"🎨", "Filtres", "12 ambiances : noir & blanc, sépia, vintage, dramatique, or…"},
                {"🔠", "Texte", "Plusieurs textes, 5 polices, couleurs, contour, ombre, fond"},
                {"✏️", "Dessin", "Pinceau, surligneur, lignes, flèches, cadres et cercles"},
                {"📄", "Document", "Remettre une page à plat, noir & blanc net, plus net : idéal avant la lecture"},
        };
        TextView tt = Ui.texte(this, "Les outils", 15, t.texte, true);
        tt.setPadding(dp(20), dp(14), dp(20), dp(2));
        contenu.addView(tt);
        LinearLayout l = carte();
        l.setPadding(dp(14), dp(8), dp(14), dp(8));
        for (String[] o : outils) {
            LinearLayout lg = Ui.ligne(this);
            lg.setPadding(0, dp(7), 0, dp(7));
            TextView e = Ui.texte(this, o[0], 20, t.texte, false);
            lg.addView(e, Ui.lp(dp(36), -2));
            LinearLayout tx = Ui.colonne(this);
            tx.addView(Ui.texte(this, o[1], 14.5f, t.texte, true));
            tx.addView(Ui.texte(this, o[2], 12.5f, t.texteDoux, false));
            lg.addView(tx, Ui.lpPoids(1));
            l.addView(lg);
        }
    }

    // ------------------------------------------------------------------ Images et photo

    private void choisirImages(int code, boolean plusieurs) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            if (plusieurs) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, code);
        } catch (Exception e) {
            try {
                Intent g = new Intent(Intent.ACTION_GET_CONTENT);
                g.setType("image/*");
                if (plusieurs) g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(g, "Choisir"), code);
            } catch (Exception e2) {
                Ui.toast(this, "Aucune appli pour choisir des images.");
            }
        }
    }

    private void prendrePhoto(boolean pourRetouche) {
        try {
            File f = new File(Fichiers.dossierPhotos(this), "photo_" + System.currentTimeMillis() + ".jpg");
            Uri u = Fichiers.uri(this, f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, u);
            i.setClipData(ClipData.newRawUri("photo", u));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            photoChemin = f.getAbsolutePath();
            photoPourRetouche = pourRetouche;
            startActivityForResult(i, PHOTO);
        } catch (Exception e) {
            photoChemin = null;
            Ui.toast(this, "Aucune appli Appareil photo disponible. Prenez la photo puis choisissez-la avec « Choisir des images ».");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PHOTO) {
            String chemin = photoChemin;
            photoChemin = null;
            if (res != RESULT_OK || chemin == null) return;
            File f = new File(chemin);
            if (!f.isFile() || f.length() == 0) {
                Ui.toast(this, "La photo n'a pas été reçue. Réessayez, ou utilisez « Choisir des images ».");
                return;
            }
            if (photoPourRetouche) startActivity(EditeurActivity.intention(this, chemin, false, -1));
            else {
                ArrayList<String> l = new ArrayList<>();
                l.add(chemin);
                startActivity(ResultatsActivity.intention(this, l));
            }
            return;
        }
        if (res != RESULT_OK || data == null) return;
        ArrayList<String> l = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) {
                Uri u = cd.getItemAt(i).getUri();
                if (u != null) l.add(u.toString());
            }
        }
        if (l.isEmpty() && data.getData() != null) l.add(data.getData().toString());
        if (l.isEmpty()) return;
        if (req == CHOISIR_RETOUCHE) startActivity(EditeurActivity.intention(this, l.get(0), false, -1));
        else if (req == CHOISIR_LECTURE) startActivity(ResultatsActivity.intention(this, l));
    }

    /** Images reçues depuis une autre appli (Partager › Image Texte, Ouvrir avec…). */
    @SuppressWarnings("deprecation")
    private boolean traiterPartage(Intent i) {
        if (i == null || i.getAction() == null) return false;
        String a = i.getAction();
        final ArrayList<String> l = new ArrayList<>();
        if (Intent.ACTION_SEND.equals(a)) {
            Parcelable p = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (p instanceof Uri) l.add(p.toString());
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) {
            ArrayList<Parcelable> ps = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (ps != null) for (Parcelable p : ps) if (p instanceof Uri) l.add(p.toString());
        } else if ((Intent.ACTION_VIEW.equals(a) || Intent.ACTION_EDIT.equals(a)) && i.getData() != null) {
            startActivity(EditeurActivity.intention(this, i.getData().toString(), false, -1));
            i.setAction(Intent.ACTION_MAIN);
            return true;
        } else {
            return false;
        }
        i.setAction(Intent.ACTION_MAIN); // ne pas retraiter après une rotation
        if (l.isEmpty()) {
            Ui.toast(this, "Aucune image reçue.");
            return true;
        }
        if (l.size() > 1) {
            startActivity(ResultatsActivity.intention(this, l));
            return true;
        }
        Ui.dialogue(this, t).setTitle("Image reçue")
                .setMessage("Que voulez-vous faire avec cette image ?")
                .setPositiveButton("🔤 Lire le texte", (d, w) -> startActivity(ResultatsActivity.intention(this, l)))
                .setNegativeButton("🎨 Retoucher", (d, w) -> startActivity(EditeurActivity.intention(this, l.get(0), false, -1)))
                .show();
        return true;
    }

    private void bienvenue() {
        Prefs.setB(this, Prefs.PREMIER, true);
        ui.postDelayed(() -> {
            if (isFinishing()) return;
            Ui.dialogue(this, t).setTitle("Bienvenue dans Image Texte 👋")
                    .setMessage("• Lire : photographiez ou choisissez des images, leur texte apparaît, prêt à copier.\n"
                            + "• Textes : tous vos textes lus, avec recherche.\n"
                            + "• Retouche : rogner, filtres, texte, dessin…\n\n"
                            + "Astuce : depuis la galerie ou WhatsApp, « Partager › Image Texte » fonctionne aussi.")
                    .setPositiveButton("C'est parti", null)
                    .setNeutralButton("Voir l'aide", (d, w) -> startActivity(new Intent(this, AideActivity.class)))
                    .show();
        }, 400);
    }

    /** Retour depuis l'écran d'accueil : avertissement avant de quitter. */
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        Sortie.demander(this, Ui.dialogue(this, t), () -> super.onBackPressed());
    }
}
