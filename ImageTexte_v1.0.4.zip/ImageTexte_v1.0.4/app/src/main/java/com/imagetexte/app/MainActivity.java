package com.imagetexte.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 10;
    private static final int PICK_IMAGES = 12;
    private static final String APP_VERSION = "1.0.4";
    private static final int PICK_FOLDER = 11;
    private static final String PREFS = "imagetexte_library";
    private LinearLayout root, content, nav;
    private Bitmap workingBitmap;
    private PhotoEditorView photoEditor;
    private Uri selectedFolder;
    private final ArrayList<String> ids = new ArrayList<>();
    private String currentTab = "Scanner";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String savedFolder = getPreferences(MODE_PRIVATE).getString("folder", "");
        selectedFolder = savedFolder.isEmpty() ? null : Uri.parse(savedFolder);
        loadIds();
        buildShell();
        showScanner();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(12,19,32));
        TextView brand = new TextView(this); brand.setText("ImageTexte"); brand.setTextColor(Color.WHITE); brand.setTextSize(25); brand.setTypeface(null, Typeface.BOLD); brand.setPadding(dp(20),dp(20),dp(20),dp(4));
        TextView subtitle = new TextView(this); subtitle.setText("Numérisez · Organisez · Créez  •  Version " + APP_VERSION); subtitle.setTextColor(Color.rgb(0,205,178)); subtitle.setTextSize(13); subtitle.setPadding(dp(20),0,dp(20),dp(16));
        root.addView(brand); root.addView(subtitle);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(8),dp(16),dp(8));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setPadding(dp(6),dp(8),dp(6),dp(10)); nav.setBackgroundColor(Color.rgb(20,30,47));
        String[] tabs = {"Scanner","Textes","Éditeur","Réglages"};
        for (String tab:tabs) { Button b = new Button(this); b.setText(tab); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35,52,72))); b.setOnClickListener(v -> navigate(tab)); nav.addView(b,new LinearLayout.LayoutParams(0,dp(48),1)); }
        root.addView(nav); setContentView(root);
    }
    private void navigate(String tab) { currentTab=tab; if(tab.equals("Scanner"))showScanner(); else if(tab.equals("Textes"))showLibrary(); else if(tab.equals("Éditeur"))showEditor(); else showSettings(); }
    private void resetContent() { content.removeAllViews(); }
    private TextView heading(String s) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(21); t.setTypeface(null,Typeface.BOLD); t.setPadding(0,dp(8),0,dp(10)); return t; }
    private TextView paragraph(String s) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.rgb(190,202,218)); t.setTextSize(14); t.setPadding(0,dp(4),0,dp(10)); return t; }
    private Button action(String s, Runnable r) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0,150,136))); b.setOnClickListener(v->r.run()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50)); p.bottomMargin=dp(10); content.addView(b,p); return b; }

    private void showScanner() {
        resetContent(); content.addView(heading("Scanner intelligent"));
        content.addView(paragraph("Sélectionnez une photo ou une image contenant du texte. ImageTexte reconnaît le texte et vous permet de le corriger avant de l'enregistrer."));
        action("＋  Choisir une image", this::pickImage);
        action("▣  Sélectionner plusieurs images", this::pickImages);
        content.addView(paragraph("Traitement groupé : plusieurs images sont analysées en parallèle et chaque texte reconnu est enregistré séparément dans votre bibliothèque."));
        content.addView(paragraph("Formats pris en charge selon votre appareil : JPG, PNG et autres images lisibles par Android."));
    }
    private void pickImage() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_IMAGE); }
    private void pickImages() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i,PICK_IMAGES);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK||data==null)return;
        if(requestCode==PICK_IMAGE) { Uri uri=data.getData(); if(uri==null)return; keepReadPermission(uri,data); runOcr(uri); }
        else if(requestCode==PICK_IMAGES) {
            ArrayList<Uri> selected=new ArrayList<>();
            if(data.getClipData()!=null) {
                for(int n=0;n<data.getClipData().getItemCount();n++) { Uri uri=data.getClipData().getItemAt(n).getUri(); if(uri!=null){keepReadPermission(uri,data);selected.add(uri);} }
            } else if(data.getData()!=null) { keepReadPermission(data.getData(),data); selected.add(data.getData()); }
            if(!selected.isEmpty()) runBatchOcr(selected); else toast("Aucune image sélectionnée");
        }
        else if(requestCode==PICK_FOLDER) { selectedFolder=data.getData(); getContentResolver().takePersistableUriPermission(selectedFolder,data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); getPreferences(MODE_PRIVATE).edit().putString("folder",selectedFolder.toString()).apply(); Toast.makeText(this,"Dossier de sauvegarde sélectionné",Toast.LENGTH_SHORT).show(); showSettings(); }
    }
    private void keepReadPermission(Uri uri, Intent data) {
        try { getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); } catch(Exception ignored) {}
    }

    // Analyse jusqu'à trois images en parallèle. Chaque résultat est conservé comme document distinct.
    private void runBatchOcr(List<Uri> uris) {
        final int total=uris.size();
        final AtomicInteger completed=new AtomicInteger(0);
        final AtomicInteger saved=new AtomicInteger(0);
        final AtomicInteger failed=new AtomicInteger(0);
        ProgressDialog progress=new ProgressDialog(this);
        progress.setTitle("Traitement de plusieurs images");
        progress.setMessage("Préparation de " + total + " image(s)…");
        progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progress.setMax(total); progress.setProgress(0); progress.setCancelable(false); progress.show();
        ExecutorService pool=Executors.newFixedThreadPool(Math.min(3,total));
        for(Uri uri:uris) {
            pool.execute(() -> {
                TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                try {
                    recognizer.process(InputImage.fromFilePath(this,uri))
                        .addOnSuccessListener(result -> runOnUiThread(() -> {
                            String text=result.getText()==null?"":result.getText().trim();
                            if(!text.isEmpty() && saveTextQuiet(text)) saved.incrementAndGet();
                            else failed.incrementAndGet();
                            updateBatchProgress(progress,completed.incrementAndGet(),total);
                            if(completed.get()==total) finishBatch(progress,pool,saved.get(),failed.get(),total);
                        }))
                        .addOnFailureListener(error -> runOnUiThread(() -> {
                            failed.incrementAndGet();
                            updateBatchProgress(progress,completed.incrementAndGet(),total);
                            if(completed.get()==total) finishBatch(progress,pool,saved.get(),failed.get(),total);
                        }))
                        .addOnCompleteListener(task -> recognizer.close());
                } catch(Exception error) {
                    recognizer.close();
                    runOnUiThread(() -> {
                        failed.incrementAndGet();
                        updateBatchProgress(progress,completed.incrementAndGet(),total);
                        if(completed.get()==total) finishBatch(progress,pool,saved.get(),failed.get(),total);
                    });
                }
            });
        }
    }
    private void updateBatchProgress(ProgressDialog dialog,int done,int total) {
        if(!isFinishing()) { dialog.setProgress(done); dialog.setMessage("Images traitées : " + done + " / " + total); }
    }
    private void finishBatch(ProgressDialog dialog,ExecutorService pool,int saved,int failed,int total) {
        pool.shutdown(); if(dialog.isShowing())dialog.dismiss(); saveIds();
        new AlertDialog.Builder(this).setTitle("Traitement terminé")
            .setMessage(saved + " texte(s) enregistré(s) dans la bibliothèque.\n" + failed + " image(s) sans texte ou en échec.\nTotal : " + total)
            .setPositiveButton("Voir ma bibliothèque",(d,w)->showLibrary())
            .setNegativeButton("Fermer",(d,w)->{ if(saved>0)showLibrary(); }).show();
    }
    private boolean saveTextQuiet(String text) {
        String id=UUID.randomUUID().toString();
        String stamp=new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss",Locale.getDefault()).format(new Date());
        try(FileOutputStream out=openFileOutput(id+".txt",MODE_PRIVATE)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
            getPreferences(MODE_PRIVATE).edit().putString(id+"_title","Scan du "+stamp).apply();
            ids.add(0,id);
            return true;
        } catch(Exception e) { return false; }
    }

    private void runOcr(Uri uri) {
        try { InputStream in=getContentResolver().openInputStream(uri); workingBitmap=BitmapFactory.decodeStream(in); if(in!=null)in.close(); }
        catch(Exception e){ toast("Impossible d'ouvrir cette image"); return; }
        if(workingBitmap==null){toast("Image illisible");return;}
        photoEditor=null;
        if ("Éditeur".equals(currentTab)) showEditor();
        toast("Lecture du texte en cours…");
        TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        try {
            recognizer.process(InputImage.fromFilePath(this,uri)).addOnSuccessListener(result->showRecognizedText(result.getText())).addOnFailureListener(e->toast("Échec de la reconnaissance : "+e.getLocalizedMessage())).addOnCompleteListener(task->recognizer.close());
        } catch (java.io.IOException e) { recognizer.close(); toast("Impossible de lire le fichier image"); }
    }
    private void showRecognizedText(String text) {
        EditText editor=new EditText(this); editor.setText(text); editor.setTextSize(16); editor.setMinLines(8); editor.setGravity(Gravity.TOP); editor.setHint("Le texte reconnu apparaîtra ici…");
        new AlertDialog.Builder(this).setTitle("Texte reconnu — vérification").setView(editor).setNegativeButton("Annuler",(d,w)->{}).setNeutralButton("Copier",(d,w)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("Texte reconnu",editor.getText()));toast("Texte copié");}).setPositiveButton("Enregistrer",(d,w)->saveText(editor.getText().toString())).show();
    }
    private void saveText(String text) {
        if(text.trim().isEmpty()){toast("Aucun texte à enregistrer");return;}
        String id=UUID.randomUUID().toString(); String stamp=new SimpleDateFormat("yyyy-MM-dd_HH-mm",Locale.getDefault()).format(new Date());
        try(FileOutputStream out=openFileOutput(id+".txt",MODE_PRIVATE)){out.write(text.getBytes(StandardCharsets.UTF_8));}
        catch(Exception e){toast("Erreur d'enregistrement");return;}
        getPreferences(MODE_PRIVATE).edit().putString(id+"_title","Texte du "+stamp).apply(); ids.add(0,id); saveIds(); toast("Texte enregistré dans votre bibliothèque"); showLibrary();
    }
    private void loadIds(){String raw=getPreferences(MODE_PRIVATE).getString("ids","");if(!raw.isEmpty()){for(String s:raw.split("\\|"))if(!s.isEmpty())ids.add(s);}}
    private void saveIds(){StringBuilder b=new StringBuilder();for(String id:ids)b.append(id).append('|');getPreferences(MODE_PRIVATE).edit().putString("ids",b.toString()).apply();}
    private String readText(String id){try(java.io.BufferedReader r=new java.io.BufferedReader(new java.io.InputStreamReader(openFileInput(id+".txt"),StandardCharsets.UTF_8))){StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l).append('\n');return b.toString();}catch(Exception e){return "";}}
    private void showLibrary() {
        resetContent(); content.addView(heading("Ma bibliothèque")); content.addView(paragraph(ids.size()+" document(s) enregistré(s) · Recherche et modification de vos textes."));
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Rechercher dans les textes…"); search.setTextColor(Color.WHITE); content.addView(search);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Runnable refresh=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(String id:ids){String txt=readText(id);String title=getPreferences(MODE_PRIVATE).getString(id+"_title","Document");if(!title.toLowerCase(Locale.ROOT).contains(q)&&!txt.toLowerCase(Locale.ROOT).contains(q))continue;TextView item=new TextView(this);item.setText("▤  "+title+"\n"+txt.replace('\n',' ').trim());item.setMaxLines(3);item.setTextColor(Color.WHITE);item.setTextSize(14);item.setPadding(dp(14),dp(14),dp(14),dp(14));item.setBackgroundColor(Color.rgb(27,40,59));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);list.addView(item,p);item.setOnClickListener(v->editSavedText(id));}};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(android.text.Editable e){}}); refresh.run();
        if(ids.isEmpty())content.addView(paragraph("Votre bibliothèque est vide. Lancez un scan pour créer votre premier document."));
    }
    private void editSavedText(String id) { EditText e=new EditText(this);e.setText(readText(id));e.setMinLines(8);new AlertDialog.Builder(this).setTitle(getPreferences(MODE_PRIVATE).getString(id+"_title","Modifier le texte")).setView(e).setNegativeButton("Fermer",null).setNeutralButton("Copier",(d,w)->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("Texte",e.getText()));toast("Copié");}).setPositiveButton("Enregistrer",(d,w)->{try(FileOutputStream o=openFileOutput(id+".txt",MODE_PRIVATE)){o.write(e.getText().toString().getBytes(StandardCharsets.UTF_8));toast("Modifications enregistrées");showLibrary();}catch(Exception ex){toast("Erreur de sauvegarde");}}).show(); }

    private void showEditor() {
        resetContent();
        content.addView(heading("Éditeur photo"));
        content.addView(paragraph("Touchez un texte pour le sélectionner. Glissez-le pour le déplacer, utilisez les poignées autour du cadre pour le redimensionner et les outils pour le faire pivoter ou le styliser."));
        Button open=action("＋  Ouvrir une image",this::pickImage);
        if(workingBitmap==null){content.addView(paragraph("Aucune image ouverte. Choisissez une image pour commencer."));return;}

        photoEditor=new PhotoEditorView(this,workingBitmap);
        LinearLayout.LayoutParams previewParams=new LinearLayout.LayoutParams(-1,0,1f);
        previewParams.bottomMargin=dp(8);
        content.addView(photoEditor,previewParams);

        HorizontalScrollView toolsScroll=new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools=new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);
        toolsScroll.addView(tools);
        addTool(tools,"＋ Texte",()->addEditorText());
        addTool(tools,"Modifier",()->editEditorText());
        addTool(tools,"Couleur",()->chooseEditorColor());
        addTool(tools,"Police",()->chooseEditorFont());
        addTool(tools,"Rotation −",()->{if(photoEditor!=null)photoEditor.rotateSelected(-15);});
        addTool(tools,"Rotation +",()->{if(photoEditor!=null)photoEditor.rotateSelected(15);});
        addTool(tools,"Contour",()->chooseEditorOutline());
        addTool(tools,"Fond",()->chooseEditorBackground());
        addTool(tools,"Gras",()->toggleEditorBold());
        addTool(tools,"Ombre",()->toggleEditorShadow());
        addTool(tools,"Supprimer",()->deleteEditorText());
        addTool(tools,"Suivant",()->{photoEditor.selectNext();});
        content.addView(toolsScroll,new LinearLayout.LayoutParams(-1,dp(52)));
        action("Enregistrer l'image",()->{Bitmap result=photoEditor.renderBitmap();workingBitmap=result;saveImage(result);});
        content.addView(paragraph("Astuce : déplacez le texte au doigt. Les 8 poignées autour du cadre permettent de le redimensionner. Rotation par pas de 15°, contour et fond personnalisables. Plusieurs blocs peuvent être ajoutés."));
    }

    private void addTool(LinearLayout parent,String label,Runnable run){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35,58,82)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(44));p.rightMargin=dp(6);parent.addView(b,p);b.setOnClickListener(v->run.run());
    }
    private void addEditorText(){
        if(photoEditor==null)return;
        EditText input=new EditText(this);input.setHint("Saisissez votre texte");input.setTextColor(Color.WHITE);input.setMinLines(2);
        new AlertDialog.Builder(this).setTitle("Ajouter un bloc de texte").setView(input).setNegativeButton("Annuler",null).setPositiveButton("Ajouter",(d,w)->{
            String value=input.getText().toString().trim();if(!value.isEmpty()){photoEditor.addText(value);}
        }).show();
    }
    private void editEditorText(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez d'abord un texte sur l'image");return;}
        PhotoEditorView.TextLayer layer=photoEditor.selectedLayer();EditText input=new EditText(this);input.setText(layer.text);input.setTextColor(Color.WHITE);input.setMinLines(2);
        new AlertDialog.Builder(this).setTitle("Modifier le texte").setView(input).setNegativeButton("Annuler",null).setPositiveButton("Appliquer",(d,w)->{layer.text=input.getText().toString();photoEditor.invalidate();}).show();
    }
    private void chooseEditorColor(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        String[] names={"Blanc","Noir","Jaune","Rouge","Bleu","Vert","Cyan","Orange"};int[] colors={Color.WHITE,Color.BLACK,Color.YELLOW,Color.RED,Color.BLUE,Color.GREEN,Color.CYAN,0xffff9800};
        new AlertDialog.Builder(this).setTitle("Couleur du texte").setItems(names,(d,w)->{photoEditor.selectedLayer().color=colors[w];photoEditor.invalidate();}).show();
    }
    private void chooseEditorFont(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        String[] names={"Sans-serif","Serif","Monospace","Condensée","Arrondie"};String[] fonts={"sans-serif","serif","monospace","sans-serif-condensed","sans-serif-rounded"};
        new AlertDialog.Builder(this).setTitle("Police du texte").setItems(names,(d,w)->{photoEditor.selectedLayer().font=fonts[w];photoEditor.invalidate();}).show();
    }
    private void chooseEditorOutline(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        String[] names={"Aucun","Blanc","Noir","Jaune","Rouge","Cyan"};int[] colors={Color.TRANSPARENT,Color.WHITE,Color.BLACK,Color.YELLOW,Color.RED,Color.CYAN};
        new AlertDialog.Builder(this).setTitle("Contour du texte").setItems(names,(d,w)->{PhotoEditorView.TextLayer l=photoEditor.selectedLayer();l.outlineColor=colors[w];l.outlineWidth=w==0?0f:Math.max(2f,l.size*.045f);photoEditor.invalidate();}).show();
    }
    private void chooseEditorBackground(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        String[] names={"Transparent","Noir semi-transparent","Blanc","Bleu","Rouge","Vert"};int[] colors={Color.TRANSPARENT,0x99000000,0xddffffff,0xdd123c78,0xddb71c1c,0xdd1b5e20};
        new AlertDialog.Builder(this).setTitle("Arrière-plan du texte").setItems(names,(d,w)->{photoEditor.selectedLayer().backgroundColor=colors[w];photoEditor.invalidate();}).show();
    }
    private void toggleEditorBold(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        PhotoEditorView.TextLayer l=photoEditor.selectedLayer();l.style=(l.style==Typeface.BOLD?Typeface.NORMAL:Typeface.BOLD);photoEditor.invalidate();
    }
    private void toggleEditorShadow(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        PhotoEditorView.TextLayer l=photoEditor.selectedLayer();l.shadow=!l.shadow;photoEditor.invalidate();
    }
    private void deleteEditorText(){
        if(photoEditor==null||photoEditor.selectedLayer()==null){toast("Sélectionnez un texte");return;}
        photoEditor.deleteSelected();
    }
    private void saveImage(Bitmap bitmap) {
        if(selectedFolder==null){toast("Choisissez d'abord un dossier SD dans Réglages");showSettings();return;}
        try {String name="ImageTexte_"+System.currentTimeMillis()+".jpg";Uri file=DocumentsContract.createDocument(getContentResolver(),DocumentsContract.buildDocumentUriUsingTree(selectedFolder,DocumentsContract.getTreeDocumentId(selectedFolder)),"image/jpeg",name);if(file==null)throw new Exception("Création impossible");OutputStream out=getContentResolver().openOutputStream(file);bitmap.compress(Bitmap.CompressFormat.JPEG,95,out);out.close();toast("Image enregistrée sur le support choisi");}
        catch(Exception e){toast("Sauvegarde impossible : "+e.getLocalizedMessage());}
    }
    private void showSettings() {
        resetContent();content.addView(heading("Réglages et sauvegarde"));content.addView(paragraph("ImageTexte version " + APP_VERSION + "\nChoisissez un dossier de destination sur la mémoire externe ou la carte SD. Android vous demandera l'autorisation d'accès."));
        action("Choisir le dossier de sauvegarde",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);startActivityForResult(i,PICK_FOLDER);});
        content.addView(paragraph(selectedFolder==null?"Aucun dossier sélectionné.":"Dossier sélectionné : "+selectedFolder.getLastPathSegment()));
        action("Exporter toute la bibliothèque en un fichier",this::exportLibrary);
        content.addView(paragraph("Les textes restent également conservés dans l'espace privé de l'application. Pensez à exporter régulièrement vos documents."));
    }
    private void exportLibrary() {
        if(selectedFolder==null){toast("Sélectionnez d'abord un dossier de destination");return;}
        try {Uri parent=DocumentsContract.buildDocumentUriUsingTree(selectedFolder,DocumentsContract.getTreeDocumentId(selectedFolder));Uri file=DocumentsContract.createDocument(getContentResolver(),parent,"text/plain","ImageTexte_Bibliotheque.txt");OutputStream out=getContentResolver().openOutputStream(file);StringBuilder b=new StringBuilder("BIBLIOTHÈQUE IMAGETEXTE\n\n");for(String id:ids){b.append("===== ").append(getPreferences(MODE_PRIVATE).getString(id+"_title","Document")).append(" =====\n").append(readText(id)).append("\n\n");}out.write(b.toString().getBytes(StandardCharsets.UTF_8));out.close();toast("Bibliothèque exportée");}
        catch(Exception e){toast("Export impossible : "+e.getLocalizedMessage());}
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
