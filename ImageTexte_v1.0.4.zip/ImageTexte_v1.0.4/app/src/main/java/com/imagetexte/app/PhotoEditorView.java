package com.imagetexte.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Touch editor with movable, scalable, rotatable text layers, outline and background. */
public class PhotoEditorView extends View {
    public static class TextLayer {
        public String text;
        public float x, y, size, rotation;
        public int color, style;
        public String font;
        public boolean shadow = true;
        public int outlineColor = Color.TRANSPARENT;
        public float outlineWidth = 0f;
        public int backgroundColor = Color.TRANSPARENT;
        public float backgroundPadding = 12f;
        public TextLayer(String text, float x, float y, float size, int color) {
            this.text=text; this.x=x; this.y=y; this.size=size; this.color=color;
            this.style=Typeface.BOLD; this.font="sans-serif";
        }
    }

    private Bitmap bitmap;
    private final List<TextLayer> layers = new ArrayList<>();
    private int selected = -1;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float scale=1f, offsetX, offsetY;
    private final RectF imageRect = new RectF();
    private float downX, downY, startLayerX, startLayerY, startSize;
    private boolean resizing=false, dragging=false;
    private int activeHandle=-1;
    private float density;

    public PhotoEditorView(Context context, Bitmap bitmap) {
        super(context); this.bitmap=bitmap; density=getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        borderPaint.setStyle(Paint.Style.STROKE); borderPaint.setStrokeWidth(2*density); borderPaint.setColor(Color.rgb(0,220,210));
        handlePaint.setStyle(Paint.Style.FILL); handlePaint.setColor(Color.WHITE);
        backgroundPaint.setStyle(Paint.Style.FILL);
    }
    public List<TextLayer> getLayers(){ return layers; }
    public int getSelectedIndex(){ return selected; }
    public void addText(String text){
        if(bitmap==null)return;
        TextLayer layer=new TextLayer(text, bitmap.getWidth()*0.08f, bitmap.getHeight()*0.55f, Math.max(28,bitmap.getWidth()*0.055f), Color.WHITE);
        layers.add(layer); selected=layers.size()-1; invalidate();
    }
    public void selectNext(){ if(!layers.isEmpty()){selected=(selected+1)%layers.size();invalidate();} }
    public void deleteSelected(){ if(selected>=0&&selected<layers.size()){layers.remove(selected);selected=layers.isEmpty()?-1:Math.min(selected,layers.size()-1);invalidate();} }
    public TextLayer selectedLayer(){return selected>=0&&selected<layers.size()?layers.get(selected):null;}
    public void rotateSelected(float degrees){TextLayer l=selectedLayer();if(l!=null){l.rotation=(l.rotation+degrees)%360f;invalidate();}}

    public Bitmap renderBitmap(){
        Bitmap out=bitmap.copy(Bitmap.Config.ARGB_8888,true); Canvas c=new Canvas(out);
        for(TextLayer l:layers) drawLayer(c,l);
        return out;
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas); canvas.drawColor(Color.rgb(8,13,23)); if(bitmap==null)return;
        float sx=getWidth()/(float)bitmap.getWidth(), sy=getHeight()/(float)bitmap.getHeight();
        scale=Math.min(sx,sy); float w=bitmap.getWidth()*scale, h=bitmap.getHeight()*scale;
        offsetX=(getWidth()-w)/2f; offsetY=(getHeight()-h)/2f; imageRect.set(offsetX,offsetY,offsetX+w,offsetY+h);
        canvas.drawBitmap(bitmap,null,imageRect,imagePaint);
        canvas.save(); canvas.translate(offsetX,offsetY); canvas.scale(scale,scale);
        for(int i=0;i<layers.size();i++){
            TextLayer l=layers.get(i); RectF r=layerBounds(l); float cx=r.centerX(), cy=r.centerY();
            canvas.save(); canvas.rotate(l.rotation,cx,cy); drawLayer(canvas,l);
            if(i==selected){
                borderPaint.setStrokeWidth(2f/scale); canvas.drawRect(r,borderPaint);
                float hs=10f/scale;
                for(float[] p:handlePoints(r)){canvas.drawCircle(p[0],p[1],hs,handlePaint);canvas.drawCircle(p[0],p[1],hs,borderPaint);}
            }
            canvas.restore();
        }
        canvas.restore();
    }
    private float[][] handlePoints(RectF r){float cx=r.centerX(),cy=r.centerY();return new float[][]{{r.left,r.top},{cx,r.top},{r.right,r.top},{r.right,cy},{r.right,r.bottom},{cx,r.bottom},{r.left,r.bottom},{r.left,cy}};}
    private Typeface typeface(TextLayer l){return Typeface.create(l.font==null?"sans-serif":l.font,l.style);}
    private String[] lines(TextLayer l){return l.text.split("\\n",-1);}
    private void prepare(TextLayer l){textPaint.setColor(l.color);textPaint.setTextSize(l.size);textPaint.setTypeface(typeface(l));textPaint.setStyle(Paint.Style.FILL);textPaint.clearShadowLayer();}
    private RectF layerBounds(TextLayer l){
        prepare(l); float width=0;for(String s:lines(l))width=Math.max(width,textPaint.measureText(s));
        Paint.FontMetrics fm=textPaint.getFontMetrics();float lineH=fm.descent-fm.ascent;
        float extra=l.outlineWidth>0?l.outlineWidth*2:0;
        return new RectF(l.x-5-extra,l.y+fm.ascent-5-extra,l.x+width+8+extra,l.y+fm.ascent+lineH*lines(l).length+5+extra);
    }
    private void drawLayer(Canvas c,TextLayer l){
        prepare(l);RectF r=layerBounds(l);
        if(l.backgroundColor!=Color.TRANSPARENT){backgroundPaint.setColor(l.backgroundColor);RectF bg=new RectF(r);bg.inset(-l.backgroundPadding,-l.backgroundPadding);c.drawRoundRect(bg,12,12,backgroundPaint);}
        Paint.FontMetrics fm=textPaint.getFontMetrics();float lineH=fm.descent-fm.ascent;float baseline=l.y;
        for(String line:lines(l)){
            if(l.outlineColor!=Color.TRANSPARENT&&l.outlineWidth>0){textPaint.setStyle(Paint.Style.STROKE);textPaint.setStrokeJoin(Paint.Join.ROUND);textPaint.setStrokeWidth(l.outlineWidth);textPaint.setColor(l.outlineColor);c.drawText(line,l.x,baseline,textPaint);}
            textPaint.setStyle(Paint.Style.FILL);textPaint.setColor(l.color);
            if(l.shadow)textPaint.setShadowLayer(Math.max(2,l.size*.08f),2,2,Color.BLACK);else textPaint.clearShadowLayer();
            c.drawText(line,l.x,baseline,textPaint);textPaint.clearShadowLayer();baseline+=lineH*1.12f;
        }
    }
    private float[] rotatePoint(float x,float y,float cx,float cy,float deg){double a=Math.toRadians(deg),cs=Math.cos(a),sn=Math.sin(a);float dx=x-cx,dy=y-cy;return new float[]{(float)(cx+dx*cs-dy*sn),(float)(cy+dx*sn+dy*cs)};}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(bitmap==null)return false;
        float vx=e.getX(),vy=e.getY();float x=(vx-offsetX)/scale,y=(vy-offsetY)/scale;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=x;downY=y;dragging=false;resizing=false;activeHandle=-1;
                if(selected>=0){TextLayer cur=layers.get(selected);RectF b=layerBounds(cur);float cx=b.centerX(),cy=b.centerY();float[][] pts=handlePoints(b);
                    for(int i=0;i<pts.length;i++){float[] p=rotatePoint(pts[i][0],pts[i][1],cx,cy,cur.rotation);if(Math.hypot(x-p[0],y-p[1])<34f/scale){activeHandle=i;resizing=true;break;}}
                }
                if(!resizing){int hit=-1;for(int i=layers.size()-1;i>=0;i--){TextLayer l=layers.get(i);RectF b=layerBounds(l);float[] q=rotatePoint(x,y,b.centerX(),b.centerY(),-l.rotation);if(b.contains(q[0],q[1])){hit=i;break;}}
                    if(hit>=0){selected=hit;dragging=true;}else selected=-1;}
                if(selected>=0){TextLayer l=layers.get(selected);startLayerX=l.x;startLayerY=l.y;startSize=l.size;}
                invalidate();return true;
            case MotionEvent.ACTION_MOVE:
                if(selected>=0&&dragging){TextLayer l=layers.get(selected);l.x=startLayerX+(x-downX);l.y=startLayerY+(y-downY);invalidate();}
                else if(selected>=0&&resizing){TextLayer l=layers.get(selected);float dx=x-downX,dy=y-downY;float delta;
                    if(activeHandle==1||activeHandle==5)delta=dy;else if(activeHandle==3||activeHandle==7)delta=dx;else delta=(dx+dy)*(activeHandle<3||activeHandle==7?-.35f:.35f);
                    if(activeHandle==0||activeHandle==2||activeHandle==6)delta=(Math.abs(dx)+Math.abs(dy))*.35f*(dx+dy>=0?1:-1);
                    l.size=Math.max(12,Math.min(bitmap.getWidth()*.35f,startSize+delta*.45f));invalidate();}
                return true;
            case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:dragging=false;resizing=false;activeHandle=-1;performClick();return true;
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
