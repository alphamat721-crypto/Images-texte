# ImageTexte v1.0.4

Application Android native pour scanner des images, extraire et organiser les textes, puis ajouter des textes sur des photos.

## Nouveautés 1.0.4
- Sélection multiple d’images depuis le sélecteur Android.
- Reconnaissance OCR groupée avec jusqu’à trois images traitées en parallèle.
- Enregistrement séparé de chaque texte reconnu dans la bibliothèque.
- Progression et bilan du traitement groupé.
- Numéro de version 1.0.4 affiché dans l’en-tête de l’application et dans les paramètres.

## Compilation
Placer `ImageTexte_v1.0.4.zip` à la racine du dépôt GitHub avec le workflow `.github/workflows/compile-imagetexte.yml`, puis lancer GitHub Actions. Le workflow doit sélectionner `ImageTexte_v*.zip`.

Projet Android : Java 17, compileSdk 36, minSdk 26.
