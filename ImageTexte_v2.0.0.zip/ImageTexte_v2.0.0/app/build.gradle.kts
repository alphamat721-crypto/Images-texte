plugins {
    id("com.android.application")
}

android {
    namespace = "bf.alphamat.imagetexte"
    compileSdk = 36

    defaultConfig {
        applicationId = "bf.alphamat.imagetexte"
        minSdk = 21
        targetSdk = 34
        versionCode = 20
        versionName = "2.0.0"
        // Téléphones et tablettes Android (processeurs ARM) : APK beaucoup plus léger.
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    // Deux APK depuis le même code (même paquet, même clé) :
    // - complet : Android 8.0 et plus, décors animés, images de travail plus grandes ;
    // - lite    : Android 5.0 / 5.1 et plus, décors fixes, mémoire réduite.
    flavorDimensions += "edition"
    productFlavors {
        create("complet") {
            dimension = "edition"
            minSdk = 26
            buildConfigField("boolean", "LITE", "false")
        }
        create("lite") {
            dimension = "edition"
            minSdk = 21
            versionNameSuffix = "-lite"
            buildConfigField("boolean", "LITE", "true")
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file("imagetexte.jks")
            storePassword = "ImageTexte2026bf"
            keyAlias = "imagetexte"
            keyPassword = "ImageTexte2026bf"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        // Bibliothèques natives compressées dans l'APK (téléchargement plus léger).
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf("META-INF/*.kotlin_module", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    // Lecture du texte sur l'appareil, modèle latin intégré (fonctionne sans Internet).
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
