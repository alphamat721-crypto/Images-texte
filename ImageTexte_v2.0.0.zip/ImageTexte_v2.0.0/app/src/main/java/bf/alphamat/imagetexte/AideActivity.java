package bf.alphamat.imagetexte;

import android.app.Activity;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Page d'aide : tout le fonctionnement de l'application, en menus repliables. */
public class AideActivity extends Activity {

    private static final String[][] SECTIONS = {
            {"🚀", "Démarrage rapide",
                    "1. Onglet « Lire » : touchez « Photographier un texte » ou « Choisir une ou plusieurs images ».\n"
                            + "2. Image Texte lit le texte de chaque image, l'une après l'autre. Une barre montre l'avancement.\n"
                            + "3. Le texte apparaît sous chaque image : vous pouvez le corriger directement, le copier, le partager.\n"
                            + "4. Il est rangé automatiquement dans l'onglet « Textes » (réglable).\n\n"
                            + "Tout se passe sur le téléphone : pas besoin d'Internet, vos images ne sont envoyées nulle part."},
            {"📷", "Photographier un texte",
                    "• Tenez le téléphone bien parallèle à la page, sans ombre de votre main.\n"
                            + "• Approchez-vous pour que le texte remplisse l'écran ; touchez l'écran pour faire la mise au point.\n"
                            + "• Évitez les reflets (papier glacé, écran) et la lumière trop faible.\n"
                            + "• Pour une longue page, prenez plusieurs photos (haut, bas) puis choisissez-les ensemble : "
                            + "le bouton « Réunir en un seul texte » les rassemble."},
            {"🖼", "Lire plusieurs images d'un coup",
                    "Dans « Choisir une ou plusieurs images », faites un appui long sur une première image, puis touchez les autres "
                            + "(selon votre téléphone, il peut s'agir de cases à cocher), et validez.\n"
                            + "Les images sont lues à la suite. En haut de l'écran des résultats :\n"
                            + "• 📋 Tout copier / 📤 Tout partager : tous les textes à la fois.\n"
                            + "• 🗂 Réunir en un seul texte : enregistre un seul texte avec des repères « — Image 2 — ».\n"
                            + "• ⬇ Fichier .txt : crée un fichier texte où vous voulez (téléphone, carte SD, Drive…)."},
            {"📤", "Depuis la galerie, WhatsApp, Facebook…",
                    "Dans n'importe quelle appli, touchez « Partager » sur une image, puis choisissez « Image Texte ».\n"
                            + "• Une seule image : Image Texte vous demande « Lire le texte » ou « Retoucher ».\n"
                            + "• Plusieurs images : la lecture démarre directement.\n"
                            + "Vous pouvez aussi utiliser « Ouvrir avec » / « Modifier avec » Image Texte : l'image s'ouvre dans la retouche."},
            {"✍️", "Corriger, copier, enregistrer le texte lu",
                    "• Touchez le texte pour le corriger, comme dans un message.\n"
                            + "• 📋 Copier : le texte va dans le presse-papiers, prêt à coller (WhatsApp, Word, SMS…).\n"
                            + "• 💾 Enregistrer : range le texte (ou vos corrections) dans l'onglet Textes. "
                            + "Si le bouton affiche « ✓ Enregistré », c'est déjà fait.\n"
                            + "• Pour copier seulement un morceau : appui long sur un mot, puis tirez les poignées de sélection."},
            {"✂️", "Texte mal lu ? « Retoucher et relire »",
                    "Sous chaque image lue, le bouton « ✂️ Retoucher et relire » ouvre l'image dans la retouche :\n"
                            + "1. Rogner : gardez seulement la zone du texte (enlève les décors qui gênent).\n"
                            + "2. Document › 📐 Remettre à plat : si la page a été photographiée de biais.\n"
                            + "3. Document › ⚫ Noir & blanc net : supprime les ombres et le fond gris.\n"
                            + "4. Touchez « ✓ Relire » en haut : le texte est relu et remplace l'ancien (le texte déjà enregistré est mis à jour)."},
            {"📚", "Onglet Textes",
                    "Tous vos textes, du plus récent au plus ancien, avec une petite image de l'original.\n"
                            + "• 🔎 Rechercher : tapez un mot ; les accents ne comptent pas (« ecole » trouve « école »).\n"
                            + "• Toucher un texte : l'ouvrir pour le lire, le modifier (enregistré automatiquement), le renommer (✎), "
                            + "le copier, le partager, l'enregistrer en fichier .txt ou le supprimer.\n"
                            + "• 📋 à droite d'un texte : copie rapide.\n"
                            + "• Appui long sur un texte : menu Ouvrir / Copier / Partager / Supprimer."},
            {"🎨", "Retouche : ouvrir une image",
                    "Onglet « Retouche » › « Ouvrir une image » ou « Prendre une photo ».\n"
                            + "En bas : les outils. Chaque outil s'ouvre avec ✕ (annuler) et ✓ (appliquer).\n"
                            + "En haut :\n"
                            + "• ↶ Annuler / ↷ Rétablir : revenir en arrière ou en avant, étape par étape.\n"
                            + "• 👁 Maintenir le doigt dessus : affiche l'image sans le réglage en cours, pour comparer.\n"
                            + "• 🔤 Lire le texte de l'image retouchée.\n"
                            + "• 💾 Enregistrer dans la galerie (Images/ImageTexte) — l'original n'est jamais modifié.\n"
                            + "• 📤 Partager directement, sans enregistrer.\n"
                            + "Appui long sur une icône du haut : son nom s'affiche."},
            {"✂️", "Rogner",
                    "Tirez les coins ou le milieu des côtés du cadre ; touchez l'intérieur pour le déplacer.\n"
                            + "Proportions : Libre, Carré (photo de profil), 4:3, 3:4, 16:9 (écran large), 9:16 (statut WhatsApp). "
                            + "« Tout » reprend l'image entière. Les dimensions en pixels s'affichent au centre."},
            {"🔄", "Pivoter et redresser",
                    "• ↺ / ↻ 90° : quart de tour.\n"
                            + "• ⇋ Miroir : inverse gauche et droite. ⇵ Haut/bas : retourne l'image.\n"
                            + "• Curseur « Redresser » : corrige un horizon penché ou une page de travers, de -45° à +45° par demi-degré. "
                            + "Une grille aide à aligner ; l'image est légèrement agrandie pour ne pas laisser de coins vides."},
            {"☀️", "Réglages et filtres",
                    "Réglages : Luminosité, Contraste, Saturation (couleurs plus vives ou plus ternes), Chaleur (plus orangé ou plus bleuté). "
                            + "« Remettre à zéro » annule tous les curseurs.\n"
                            + "Filtres : 12 ambiances avec aperçu (Noir & blanc, Sépia, Éclatant, Froid, Chaud, Vintage, Dramatique, Doux, "
                            + "Encre, Nuit bleue, Or). Touchez-en un pour l'essayer, ✓ pour le garder."},
            {"🔠", "Écrire sur l'image",
                    "• « ＋ Ajouter » : tapez votre texte (plusieurs lignes possibles).\n"
                            + "• Glissez le texte avec un doigt pour le placer.\n"
                            + "• Avec deux doigts : écartez pour agrandir, tournez pour incliner (aimanté à l'horizontale).\n"
                            + "• Touchez deux fois un texte pour le modifier.\n"
                            + "• Style : Couleur, Police (5 choix), Gras, Contour, Ombre, Fond (bandeau derrière le texte).\n"
                            + "• Plusieurs textes possibles : touchez celui à modifier. 🗑 supprime le texte choisi.\n"
                            + "• ✓ grave les textes dans l'image."},
            {"✏️", "Dessiner",
                    "Outils : Pinceau (à main levée), Surligneur (trait large transparent, pour mettre en valeur), Ligne, Flèche, "
                            + "Cadre et Cercle (pour entourer).\n"
                            + "Choisissez la couleur et l'épaisseur. « ↶ Trait » efface le dernier trait. ✓ grave le dessin dans l'image."},
            {"📄", "Document",
                    "Spécial pages, factures, tickets, tableaux, cahiers :\n"
                            + "• 📐 Remettre à plat : placez les 4 points sur les 4 coins de la page (une loupe apparaît sous le doigt). "
                            + "La page est redressée comme si elle avait été scannée.\n"
                            + "• ⚫ Noir & blanc net : fond blanc, texte noir, ombres supprimées. Le meilleur avant la lecture.\n"
                            + "• ✨ Couleurs nettes : renforce le contraste en gardant les couleurs.\n"
                            + "• ◐ Gris contrasté : version grise et nette.\n"
                            + "• 🔍 Plus net : accentue les contours des lettres.\n"
                            + "Ces boutons s'appliquent tout de suite ; ↶ annule."},
            {"⚙", "Réglages de l'appli",
                    "Menus repliables (ouvrir un menu referme le précédent) :\n"
                            + "• Thème 3D : 5 ambiances en relief (Saphir nocturne, Perle d'aurore, Émeraude royale, Ébène & or, Corail tropical).\n"
                            + "• Lecture du texte : « Lignes comme sur l'image » ou « Paragraphes » (lignes recollées), amélioration automatique, "
                            + "enregistrement automatique.\n"
                            + "• Images enregistrées : JPEG ou PNG, qualité, taille de travail (Normale ou Haute définition).\n"
                            + "• Mes textes : tout exporter en un fichier .txt, ou tout supprimer."},
            {"📱", "Version complète et version Lite",
                    "• Image Texte (complète) : Android 8 et plus, décors animés, images de travail plus grandes.\n"
                            + "• Image Texte Lite : Android 5.1 et plus, décors fixes, moins de mémoire utilisée, mêmes fonctions.\n"
                            + "Les deux ont le même nom de paquet : installez l'une OU l'autre."},
            {"🛠", "Problèmes fréquents",
                    "• « Aucun texte trouvé » : rognez autour du texte, essayez Document › Noir & blanc net, ou reprenez la photo plus près et mieux éclairée.\n"
                            + "• Des lettres fausses : corrigez-les directement dans le texte ; activez « Améliorer l'image avant la lecture » pour les photos sombres.\n"
                            + "• « Mémoire insuffisante » : Réglages › Images › Taille de travail « Normale », ou rognez d'abord l'image.\n"
                            + "• Android 6 à 9 : la première fois que vous enregistrez une image, autorisez l'accès au stockage.\n"
                            + "• La photo n'arrive pas après l'appareil photo : certaines applis photo ne renvoient rien ; prenez la photo puis utilisez « Choisir des images »."},
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Visuel.Theme t = Visuel.theme(this);
        Visuel.barres(this, t);
        FrameLayout racine = new FrameLayout(this);
        racine.addView(new Decor(this, t), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = Ui.colonne(this);
        col.setPadding(0, 0, 0, Ui.dp(this, 24));

        LinearLayout entete = Ui.ligne(this);
        entete.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 6));
        TextView retour = Ui.texte(this, "←", 24, t.texte, true);
        retour.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 12), 0);
        retour.setOnClickListener(v -> finish());
        entete.addView(retour);
        entete.addView(Ui.texte(this, "Aide", 22, t.texte, true), Ui.lpPoids(1));
        col.addView(entete);
        TextView intro = Ui.texte(this, "Touchez un sujet pour l'ouvrir. Image Texte v" + App.version(), 13, t.texteDoux, false);
        intro.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 6));
        col.addView(intro);

        Accordeon acc = new Accordeon(this, t, col);
        for (String[] s : SECTIONS) {
            LinearLayout c = acc.section(s[0], s[1], null);
            TextView tx = Ui.texte(this, s[2], 14.5f, t.texte, false);
            tx.setLineSpacing(0, 1.22f);
            tx.setTextIsSelectable(true);
            tx.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
            c.addView(tx);
        }
        acc.ouvrir(0);

        TextView autres = Ui.texte(this, "Mes autres applis et logiciels ›", 13, t.texteDoux, false);
        autres.setPadding(Ui.dp(this, 20), Ui.dp(this, 14), Ui.dp(this, 20), 0);
        autres.setOnClickListener(v -> Ui.autresApplis(this, t));
        col.addView(autres);

        racine.addView(Ui.defilement(this, col), new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
    }
}
