# ImageTexte v1.0.0

Application Android native (Java) pour extraire du texte depuis une image, corriger et classer les textes, rechercher dans la bibliothèque, modifier les textes et ajouter une légende sur une image.

## Fonctionnalités incluses
- Sélection d'images depuis le stockage Android.
- Reconnaissance OCR avec Google ML Kit (modèle latin).
- Vérification et correction du texte avant enregistrement.
- Bibliothèque locale avec recherche, modification et copie.
- Choix d'un dossier de destination via le sélecteur Android (carte SD si disponible).
- Export de la bibliothèque en fichier texte.
- Ajout d'une légende sur une image, avec choix de taille et couleur, puis export JPEG.
- Interface en français avec onglets Scanner, Textes, Éditeur et Réglages.

## Compilation GitHub
1. Créer un dépôt GitHub privé ou public.
2. Décompresser cette archive à la racine du dépôt (le dossier `.github` doit être conservé).
3. Ajouter un wrapper Gradle (`gradlew`, `gradle/wrapper/gradle-wrapper.properties` et le JAR wrapper) ou installer/configurer le wrapper depuis Android Studio.
4. Lancer l'action **Compiler ImageTexte** depuis l'onglet Actions. L'APK est publié comme artefact `ImageTexte-APK`.
5. Pour créer une GitHub Release, pousser un tag commençant par `v`.

## Configuration technique
- Android Gradle Plugin 8.10.1
- Java 17
- Compile SDK 36, minimum Android 8.0 (API 26)
- ML Kit Text Recognition 16.0.1

## Notes
- La reconnaissance fournie ici cible le texte latin. Une connexion Internet peut être nécessaire au premier téléchargement du modèle ML Kit selon l'environnement et l'appareil.
- La sauvegarde sur carte SD dépend du support du sélecteur de fichiers Android et des autorisations accordées par l'utilisateur.
- Cette archive contient le code source et le workflow GitHub. L'APK n'a pas été compilé dans cet environnement.
