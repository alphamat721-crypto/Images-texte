package bf.alphamat.imagetexte;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Retouche d'image : rogner, pivoter/redresser, réglages, filtres, texte, dessin, document.
 * Chaque outil s'ouvre avec ✕ (annuler) / ✓ (appliquer) ; chaque application est gardée dans l'historique.
 */
public class EditeurActivity extends Activity implements ToileVue.Ecouteur {

    static final String EXTRA_SOURCE = "source";
    static final String EXTRA_POUR_LECTURE = "pour_lecture";
    static final String EXTRA_INDEX = "index";
    static final String RESULTAT_CHEMIN = "chemin";

    private static final int CHOISIR = 11;
    private static final int O_AUCUN = -1, O_ROGNER = 0, O_PIVOTER = 1, O_REGLAGES = 2, O_FILTRES = 3,
            O_TEXTE = 4, O_DESSIN = 5, O_DOCUMENT = 6, O_PERSPECTIVE = 7;

    static final int[] COULEURS = {0xFFFFFFFF, 0xFF000000, 0xFF8E8E93, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00,
            0xFF34C759, 0xFF00C7BE, 0xFF0A84FF, 0xFF5856D6, 0xFFAF52DE, 0xFFFF2D55,
            0xFF8B5A2B, 0xFFE8B84A, 0xFFF5E6C8, 0xFF64D2FF};

    private Visuel.Theme t;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ToileVue toile;
    private LinearLayout panneau, outils, barreHaut;
    private TextView bAnnuler, bRetablir;
    private final List<Bitmap> pile = new ArrayList<>();
    private int pos = -1;
    private int outil = O_AUCUN;
    private boolean modifie, pourLecture, occupe;
    private int index = -1;
    private Runnable appliquer;
    private int[] reglages = new int[4];
    private int filtreChoisi;
    private float angle;
    private ProgressDialog attente;
    private Runnable apresPermission;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Visuel.Theme base = Visuel.theme(this);
        t = new Visuel.Theme(base.nom, base.ambiance, 0xFF0B0D12, 0xFF14171F, base.accent, base.accent2,
                0xFF1B1F2A, 0x44FFFFFF, 0xFFFFFFFF, 0xB3FFFFFF, base.decor, true);
        Visuel.barres(this, t);
        pourLecture = getIntent().getBooleanExtra(EXTRA_POUR_LECTURE, false);
        index = getIntent().getIntExtra(EXTRA_INDEX, -1);
        construire();
        String source = getIntent().getStringExtra(EXTRA_SOURCE);
        if (source == null && getIntent().getData() != null) source = getIntent().getData().toString();
        if (source == null) choisirImage();
        else charger(source);
    }

    // ------------------------------------------------------------------ Interface

    private void construire() {
        FrameLayout racine = new FrameLayout(this);
        GradientDrawable fond = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{t.haut, t.bas});
        racine.setBackground(fond);
        LinearLayout col = Ui.colonne(this);

        barreHaut = Ui.ligne(this);
        barreHaut.setPadding(dp(4), dp(6), dp(6), dp(4));
        TextView retour = icone("←", "Retour");
        retour.setOnClickListener(v -> onBackPressed());
        barreHaut.addView(retour);
        TextView titre = Ui.texte(this, pourLecture ? "Préparer la lecture" : "Retouche", 17, t.texte, true);
        titre.setSingleLine(true);
        barreHaut.addView(titre, Ui.lpPoids(1));
        bAnnuler = icone("↶", "Annuler");
        bAnnuler.setOnClickListener(v -> annuler());
        barreHaut.addView(bAnnuler);
        bRetablir = icone("↷", "Rétablir");
        bRetablir.setOnClickListener(v -> retablir());
        barreHaut.addView(bRetablir);
        TextView avant = icone("👁", "Maintenir pour voir l'original");
        avant.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) toile.montrerAvant(true);
            else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL)
                toile.montrerAvant(false);
            return true;
        });
        barreHaut.addView(avant);
        if (pourLecture) {
            TextView ok = Ui.bouton(this, "✓ Relire", t.accent, 0xFFFFFFFF);
            ok.setTextSize(14);
            ok.setPadding(dp(12), dp(6), dp(12), dp(9));
            ok.setOnClickListener(v -> renvoyerPourLecture());
            barreHaut.addView(ok, Ui.lpMarges(this, -2, -2, 4, 0, 0, 0));
        } else {
            TextView lire = icone("🔤", "Lire le texte");
            lire.setOnClickListener(v -> lireTexte());
            barreHaut.addView(lire);
            TextView enreg = icone("💾", "Enregistrer");
            enreg.setOnClickListener(v -> enregistrer(false));
            barreHaut.addView(enreg);
            TextView part = icone("📤", "Partager");
            part.setOnClickListener(v -> partager());
            barreHaut.addView(part);
        }
        col.addView(barreHaut);

        toile = new ToileVue(this);
        toile.setAccent(t.accent);
        toile.setEcouteur(this);
        col.addView(toile, new LinearLayout.LayoutParams(-1, 0, 1));

        panneau = Ui.colonne(this);
        panneau.setBackground(Visuel.carte3D(this, t, 20));
        panneau.setPadding(dp(10), dp(8), dp(10), dp(10));
        panneau.setVisibility(View.GONE);
        col.addView(panneau, Ui.lpMarges(this, -1, -2, 8, 4, 8, 2));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        outils = Ui.ligne(this);
        outils.setPadding(dp(6), dp(6), dp(6), dp(10));
        String[][] liste = {{"✂️", "Rogner"}, {"🔄", "Pivoter"}, {"☀️", "Réglages"}, {"🎨", "Filtres"},
                {"🔠", "Texte"}, {"✏️", "Dessin"}, {"📄", "Document"}};
        for (int i = 0; i < liste.length; i++) {
            final int o = i;
            LinearLayout b = Ui.colonne(this);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(10), dp(6), dp(10), dp(6));
            b.setBackground(Visuel.puce(this, t, false));
            b.addView(Ui.texte(this, liste[i][0], 20, t.texte, false));
            TextView l = Ui.texte(this, liste[i][1], 11.5f, t.texteDoux, true);
            l.setGravity(Gravity.CENTER);
            b.addView(l);
            b.setClickable(true);
            b.setOnClickListener(v -> ouvrirOutil(o));
            Ui.pression(b);
            outils.addView(b, Ui.lpMarges(this, dp(76), -2, 3, 0, 3, 0));
        }
        hs.addView(outils);
        col.addView(hs);

        racine.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
        majBoutons();
    }

    private TextView icone(String s, String description) {
        TextView v = Ui.texte(this, s, 20, t.texte, true);
        v.setGravity(Gravity.CENTER);
        v.setContentDescription(description);
        v.setClickable(true);
        v.setOnLongClickListener(x -> {
            Ui.toastCourt(this, description);
            return true;
        });
        Ui.pression(v);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(44)));
        return v;
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void majBoutons() {
        if (bAnnuler == null) return;
        bAnnuler.setAlpha(pos > 0 ? 1f : 0.3f);
        bRetablir.setAlpha(pos < pile.size() - 1 ? 1f : 0.3f);
    }

    // ------------------------------------------------------------------ Chargement

    private void choisirImage() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i, CHOISIR);
        } catch (Exception e) {
            Ui.toast(this, "Aucune appli pour choisir une image.");
            finish();
        }
    }

    private void charger(String source) {
        montrerAttente("Ouverture de l'image…");
        final int cote = Prefs.coteRetouche(this);
        App.travail().execute(() -> {
            Bitmap b = null;
            String err = null;
            try {
                b = Images.charger(this, source, cote);
            } catch (Throwable e) {
                err = Lecteur.messageErreur(e);
            }
            final Bitmap fb = b;
            final String fe = err;
            ui.post(() -> {
                cacherAttente();
                if (isFinishing()) {
                    if (fb != null) fb.recycle();
                    return;
                }
                if (fb == null) {
                    Ui.toast(this, fe == null ? "Image illisible." : fe);
                    finish();
                    return;
                }
                pile.add(fb);
                pos = 0;
                toile.setImage(fb);
                majBoutons();
                if (!Prefs.b(this, "astuce_editeur", false)) {
                    Prefs.setB(this, "astuce_editeur", true);
                    Ui.toast(this, "Astuce : maintenez 👁 pour comparer avec l'original.");
                }
            });
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == CHOISIR) {
            if (res == RESULT_OK && data != null && data.getData() != null) charger(data.getData().toString());
            else finish();
        }
    }

    private Bitmap actuelle() {
        return pos >= 0 && pos < pile.size() ? pile.get(pos) : null;
    }

    // ------------------------------------------------------------------ Historique

    private void valider(Bitmap nouvelle) {
        if (nouvelle == null) return;
        while (pile.size() > pos + 1) {
            Bitmap x = pile.remove(pile.size() - 1);
            if (x != nouvelle) x.recycle();
        }
        pile.add(nouvelle);
        while (pile.size() > Prefs.historique() + 1) {
            Bitmap x = pile.remove(0);
            x.recycle();
        }
        pos = pile.size() - 1;
        modifie = true;
        toile.setImage(nouvelle);
        majBoutons();
    }

    private void annuler() {
        if (occupe) return;
        if (outil != O_AUCUN) {
            fermerOutil();
            return;
        }
        if (pos <= 0) {
            Ui.toastCourt(this, "Rien à annuler");
            return;
        }
        pos--;
        modifie = true;
        toile.setImage(actuelle());
        majBoutons();
    }

    private void retablir() {
        if (occupe || outil != O_AUCUN || pos >= pile.size() - 1) return;
        pos++;
        modifie = true;
        toile.setImage(actuelle());
        majBoutons();
    }

    /** Exécute un traitement lourd en arrière-plan puis l'ajoute à l'historique. */
    interface Traitement {
        Bitmap faire(Bitmap b) throws Exception;
    }

    private void traiter(String message, Traitement tr, Runnable ensuite) {
        final Bitmap b = actuelle();
        if (b == null || occupe) return;
        occupe = true;
        montrerAttente(message);
        App.travail().execute(() -> {
            Bitmap r = null;
            String err = null;
            try {
                r = tr.faire(b);
            } catch (OutOfMemoryError e) {
                err = "Mémoire insuffisante. Choisissez « Taille de travail : normale » dans Réglages, ou rognez d'abord l'image.";
            } catch (Throwable e) {
                err = "Opération impossible : " + e.getMessage();
            }
            final Bitmap fr = r;
            final String fe = err;
            ui.post(() -> {
                occupe = false;
                cacherAttente();
                if (isFinishing()) return;
                if (fr == null) {
                    Ui.toast(this, fe == null ? "Opération impossible." : fe);
                    return;
                }
                // Android renvoie parfois la même image quand rien ne change : on ne l'ajoute pas deux fois.
                if (fr == b) return;
                valider(fr);
                if (ensuite != null) ensuite.run();
            });
        });
    }

    @SuppressWarnings("deprecation")
    private void montrerAttente(String m) {
        cacherAttente();
        attente = new ProgressDialog(this, android.R.style.Theme_Material_Dialog_Alert);
        attente.setMessage(m);
        attente.setCancelable(false);
        attente.show();
    }

    private void cacherAttente() {
        if (attente != null) {
            try {
                attente.dismiss();
            } catch (Exception ignore) {
            }
            attente = null;
        }
    }

    // ------------------------------------------------------------------ Outils

    private void ouvrirOutil(int o) {
        if (actuelle() == null || occupe) return;
        if (outil != O_AUCUN) fermerOutil();
        outil = o;
        panneau.removeAllViews();
        panneau.setVisibility(View.VISIBLE);
        outils.setAlpha(0.35f);
        appliquer = null;
        switch (o) {
            case O_ROGNER:
                panneauRogner();
                break;
            case O_PIVOTER:
                panneauPivoter();
                break;
            case O_REGLAGES:
                panneauReglages();
                break;
            case O_FILTRES:
                panneauFiltres();
                break;
            case O_TEXTE:
                panneauTexte();
                break;
            case O_DESSIN:
                panneauDessin();
                break;
            case O_DOCUMENT:
                panneauDocument();
                break;
            case O_PERSPECTIVE:
                panneauPerspective();
                break;
            default:
                break;
        }
    }

    private void fermerOutil() {
        outil = O_AUCUN;
        appliquer = null;
        panneau.removeAllViews();
        panneau.setVisibility(View.GONE);
        outils.setAlpha(1f);
        toile.setApercu(null, false);
        toile.setAngleApercu(0, false);
        toile.setMode(ToileVue.AUCUN);
    }

    /** Barre « ✕ titre ✓ » en haut du panneau. */
    private void barre(String titre, boolean avecValider) {
        LinearLayout l = Ui.ligne(this);
        TextView x = Ui.texte(this, "✕", 20, t.texteDoux, true);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(v -> fermerOutil());
        l.addView(x, Ui.lp(dp(44), dp(36)));
        TextView ti = Ui.texte(this, titre, 15, t.texte, true);
        ti.setGravity(Gravity.CENTER);
        l.addView(ti, Ui.lpPoids(1));
        if (avecValider) {
            TextView ok = Ui.texte(this, "✓", 22, t.accent, true);
            ok.setGravity(Gravity.CENTER);
            ok.setOnClickListener(v -> {
                if (appliquer != null) appliquer.run();
                else fermerOutil();
            });
            l.addView(ok, Ui.lp(dp(44), dp(36)));
        } else {
            l.addView(new View(this), Ui.lp(dp(44), dp(36)));
        }
        panneau.addView(l);
    }

    private TextView puce(String s, boolean active, View.OnClickListener cl) {
        TextView p = Ui.texte(this, s, 13.5f, active ? 0xFFFFFFFF : t.texte, true);
        p.setGravity(Gravity.CENTER);
        p.setPadding(dp(12), dp(7), dp(12), dp(7));
        p.setBackground(Visuel.puce(this, t, active));
        p.setClickable(true);
        p.setOnClickListener(cl);
        Ui.pression(p);
        return p;
    }

    private HorizontalScrollView rangee(LinearLayout contenu) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(contenu);
        return hs;
    }

    private void choixActif(LinearLayout groupe, int actif) {
        for (int i = 0; i < groupe.getChildCount(); i++) {
            View v = groupe.getChildAt(i);
            v.setBackground(Visuel.puce(this, t, i == actif));
            if (v instanceof TextView) ((TextView) v).setTextColor(i == actif ? 0xFFFFFFFF : t.texte);
        }
    }

    /** Curseur avec libellé et valeur affichée. */
    private SeekBar curseur(String nom, int min, int max, int valeur, Ui.SurInt sur) {
        LinearLayout l = Ui.ligne(this);
        TextView n = Ui.texte(this, nom, 13, t.texte, false);
        l.addView(n, Ui.lp(dp(92), -2));
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(valeur - min);
        TextView v = Ui.texte(this, String.valueOf(valeur), 13, t.accent, true);
        v.setGravity(Gravity.END);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                v.setText(String.valueOf(p + min));
                sur.v(p + min);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        l.addView(s, Ui.lpPoids(1));
        l.addView(v, Ui.lp(dp(40), -2));
        panneau.addView(l, Ui.lpMarges(this, -1, -2, 0, 2, 0, 2));
        return s;
    }

    // ---- Rogner

    private void panneauRogner() {
        barre("Rogner", true);
        toile.setMode(ToileVue.ROGNER);
        LinearLayout l = Ui.ligne(this);
        String[] noms = {"Libre", "Carré", "4:3", "3:4", "16:9", "9:16", "Tout"};
        float[] ratios = {0, 1, 4 / 3f, 3 / 4f, 16 / 9f, 9 / 16f, -1};
        for (int i = 0; i < noms.length; i++) {
            final int k = i;
            l.addView(puce(noms[i], i == 0, v -> {
                if (ratios[k] < 0) {
                    toile.cadreToutRetablir();
                    choixActif(l, 0);
                } else {
                    toile.setRatio(ratios[k]);
                    choixActif(l, k);
                }
            }), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        }
        panneau.addView(rangee(l));
        TextView aide = Ui.texte(this, "Tirez les coins ou les côtés ; touchez l'intérieur pour déplacer le cadre.", 12, t.texteDoux, false);
        aide.setPadding(dp(4), dp(4), dp(4), 0);
        panneau.addView(aide);
        appliquer = () -> {
            RectF r = toile.getCadre();
            Bitmap b = actuelle();
            if (b != null && r.width() >= b.getWidth() - 1 && r.height() >= b.getHeight() - 1) {
                fermerOutil();
                return;
            }
            fermerOutil();
            traiter("Rognage…", x -> Retouches.rogner(x, r), null);
        };
    }

    // ---- Pivoter / redresser

    private void panneauPivoter() {
        barre("Pivoter et redresser", true);
        angle = 0;
        LinearLayout l = Ui.ligne(this);
        l.addView(puce("↺ 90°", false, v -> traiter("Rotation…", x -> Retouches.tourner90(x, false), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("↻ 90°", false, v -> traiter("Rotation…", x -> Retouches.tourner90(x, true), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("⇋ Miroir", false, v -> traiter("Miroir…", x -> Retouches.retourner(x, true), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("⇵ Haut/bas", false, v -> traiter("Retournement…", x -> Retouches.retourner(x, false), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        panneau.addView(rangee(l));
        final TextView valeur = Ui.texte(this, "Redresser : 0°", 13, t.texte, true);
        valeur.setPadding(dp(4), dp(6), 0, 0);
        panneau.addView(valeur);
        SeekBar s = new SeekBar(this);
        s.setMax(180);
        s.setProgress(90);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                angle = (p - 90) / 2f;
                valeur.setText("Redresser : " + (angle == (int) angle ? String.valueOf((int) angle) : String.valueOf(angle)) + "°");
                toile.setAngleApercu(angle, true);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
                toile.setAngleApercu(angle, true);
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        panneau.addView(s);
        appliquer = () -> {
            float a = angle;
            fermerOutil();
            if (a != 0) traiter("Redressement…", x -> Retouches.redresser(x, a), null);
        };
    }

    // ---- Réglages

    private void panneauReglages() {
        barre("Réglages", true);
        reglages = new int[4];
        String[] noms = {"Luminosité", "Contraste", "Saturation", "Chaleur"};
        final SeekBar[] curs = new SeekBar[4];
        for (int i = 0; i < 4; i++) {
            final int k = i;
            curs[i] = curseur(noms[i], -100, 100, 0, v -> {
                reglages[k] = v;
                toile.setApercu(Retouches.reglages(reglages[0], reglages[1], reglages[2], reglages[3]), false);
            });
        }
        TextView zero = puce("Remettre à zéro", false, v -> {
            for (SeekBar s : curs) s.setProgress(100);
        });
        LinearLayout l = Ui.ligne(this);
        l.addView(zero);
        panneau.addView(l, Ui.lpMarges(this, -2, -2, 0, 4, 0, 0));
        appliquer = () -> {
            int[] r = reglages.clone();
            fermerOutil();
            if (r[0] == 0 && r[1] == 0 && r[2] == 0 && r[3] == 0) return;
            traiter("Application des réglages…", x -> Retouches.appliquerCouleurs(x,
                    Retouches.reglages(r[0], r[1], r[2], r[3]), false), null);
        };
    }

    // ---- Filtres

    private void panneauFiltres() {
        barre("Filtres", true);
        filtreChoisi = 0;
        LinearLayout l = Ui.ligne(this);
        Bitmap b = actuelle();
        Bitmap mini = null;
        try {
            int lg = Math.max(b.getWidth(), b.getHeight());
            mini = Bitmap.createScaledBitmap(b, Math.max(1, b.getWidth() * 150 / lg), Math.max(1, b.getHeight() * 150 / lg), true);
        } catch (Throwable ignore) {
        }
        for (int i = 0; i < Retouches.FILTRES.length; i++) {
            final int k = i;
            LinearLayout c = Ui.colonne(this);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setPadding(dp(4), dp(4), dp(4), dp(4));
            c.setBackground(Visuel.puce(this, t, i == 0));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (mini != null) {
                Bitmap v = Bitmap.createBitmap(mini.getWidth(), mini.getHeight(), Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(v);
                Paint pp = new Paint(Paint.FILTER_BITMAP_FLAG);
                pp.setColorFilter(new ColorMatrixColorFilter(Retouches.filtre(i)));
                cv.drawBitmap(mini, 0, 0, pp);
                if (Retouches.vignette(i)) Retouches.dessinerVignette(cv, new RectF(0, 0, v.getWidth(), v.getHeight()));
                iv.setImageBitmap(v);
            }
            c.addView(iv, Ui.lp(dp(64), dp(64)));
            TextView n = Ui.texte(this, Retouches.FILTRES[i], 11, t.texte, true);
            n.setGravity(Gravity.CENTER);
            n.setSingleLine(true);
            c.addView(n, Ui.lp(dp(70), -2));
            c.setClickable(true);
            c.setOnClickListener(v -> {
                filtreChoisi = k;
                toile.setApercu(k == 0 ? null : Retouches.filtre(k), Retouches.vignette(k));
                for (int j = 0; j < l.getChildCount(); j++) l.getChildAt(j).setBackground(Visuel.puce(this, t, j == k));
            });
            Ui.pression(c);
            l.addView(c, Ui.lpMarges(this, -2, -2, 3, 2, 3, 2));
        }
        if (mini != null && mini != b) mini.recycle();
        panneau.addView(rangee(l));
        appliquer = () -> {
            int f = filtreChoisi;
            fermerOutil();
            if (f == 0) return;
            traiter("Application du filtre…", x -> Retouches.appliquerCouleurs(x, Retouches.filtre(f), Retouches.vignette(f)), null);
        };
    }

    // ---- Texte

    private TextView bGras, bOmbre;

    private void panneauTexte() {
        barre("Texte", true);
        toile.setMode(ToileVue.TEXTE);
        LinearLayout l = Ui.ligne(this);
        l.addView(puce("＋ Ajouter", true, v -> saisirTexte(null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("✎ Modifier", false, v -> {
            if (toile.getChoisi() != null) saisirTexte(toile.getChoisi());
            else Ui.toastCourt(this, "Touchez d'abord un texte");
        }), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("🎨 Couleur", false, v -> surChoisi(k -> choisirCouleur("Couleur du texte", false, c -> {
            k.couleur = c;
            toile.rafraichir();
        }))), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("Aa Police", false, v -> surChoisi(this::choisirPolice)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        bGras = puce("𝐁 Gras", false, v -> surChoisi(k -> {
            k.gras = !k.gras;
            toile.rafraichir();
            majTexte(k);
        }));
        l.addView(bGras, Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("◯ Contour", false, v -> surChoisi(k -> choisirCouleur("Contour", true, c -> {
            k.contour = c;
            toile.rafraichir();
        }))), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        bOmbre = puce("◐ Ombre", false, v -> surChoisi(k -> {
            k.ombre = !k.ombre;
            toile.rafraichir();
            majTexte(k);
        }));
        l.addView(bOmbre, Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("▭ Fond", false, v -> surChoisi(k -> choisirCouleur("Fond derrière le texte", true, c -> {
            k.fond = c == 0 ? 0 : Visuel.alpha(c, 0xB4);
            toile.rafraichir();
        }))), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("🗑", false, v -> toile.supprimerChoisi()), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        panneau.addView(rangee(l));
        TextView aide = Ui.texte(this, "Glissez pour déplacer • deux doigts pour agrandir et tourner • touchez deux fois pour modifier.", 12, t.texteDoux, false);
        aide.setPadding(dp(4), dp(4), dp(4), 0);
        panneau.addView(aide);
        appliquer = () -> {
            if (toile.calques.isEmpty()) {
                fermerOutil();
                return;
            }
            final List<ToileVue.Calque> c = new ArrayList<>(toile.calques);
            fermerOutil();
            traiter("Ajout du texte…", x -> {
                Bitmap r = x.copy(Bitmap.Config.ARGB_8888, true);
                Canvas cv = new Canvas(r);
                Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
                for (ToileVue.Calque k : c) ToileVue.dessinerCalque(cv, k, pt);
                return r;
            }, null);
        };
        saisirTexte(null);
    }

    interface SurCalque {
        void v(ToileVue.Calque k);
    }

    private void surChoisi(SurCalque s) {
        ToileVue.Calque k = toile.getChoisi();
        if (k == null) {
            Ui.toastCourt(this, "Ajoutez ou touchez d'abord un texte");
            return;
        }
        s.v(k);
    }

    private void majTexte(ToileVue.Calque k) {
        if (bGras == null) return;
        boolean g = k != null && k.gras, o = k != null && k.ombre;
        bGras.setBackground(Visuel.puce(this, t, g));
        bGras.setTextColor(g ? 0xFFFFFFFF : t.texte);
        bOmbre.setBackground(Visuel.puce(this, t, o));
        bOmbre.setTextColor(o ? 0xFFFFFFFF : t.texte);
    }

    private void saisirTexte(ToileVue.Calque k) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setMinLines(2);
        e.setHint("Écrivez votre texte (plusieurs lignes possibles)");
        if (k != null) {
            e.setText(k.texte);
            e.setSelection(e.getText().length());
        }
        LinearLayout box = Ui.colonne(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        AlertDialog d = Ui.dialogue(this, t).setTitle(k == null ? "Ajouter un texte" : "Modifier le texte")
                .setView(box)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("OK", (di, w) -> {
                    String s = e.getText().toString();
                    if (s.trim().isEmpty()) {
                        if (k != null) toile.supprimerChoisi();
                        return;
                    }
                    if (k == null) toile.ajouterTexte(s);
                    else {
                        k.texte = s;
                        toile.rafraichir();
                    }
                }).create();
        if (d.getWindow() != null)
            d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    private void choisirPolice(ToileVue.Calque k) {
        LinearLayout col = Ui.colonne(this);
        col.setPadding(dp(16), dp(8), dp(16), dp(8));
        final AlertDialog[] d = new AlertDialog[1];
        for (int i = 0; i < ToileVue.POLICES.length; i++) {
            final int p = i;
            ToileVue.Calque essai = new ToileVue.Calque();
            essai.police = i;
            essai.gras = k.gras;
            TextView tv = Ui.texte(this, ToileVue.POLICES[i] + " — Abc 123", 19, t.texte, false);
            tv.setTypeface(ToileVue.police(essai));
            tv.setPadding(dp(12), dp(12), dp(12), dp(12));
            tv.setBackground(Visuel.puce(this, t, i == k.police));
            if (i == k.police) tv.setTextColor(0xFFFFFFFF);
            tv.setOnClickListener(v -> {
                k.police = p;
                toile.rafraichir();
                if (d[0] != null) d[0].dismiss();
            });
            col.addView(tv, Ui.lpMarges(this, -1, -2, 0, 3, 0, 3));
        }
        d[0] = Ui.dialogue(this, t).setTitle("Police").setView(Ui.defilement(this, col)).setNegativeButton("Fermer", null).show();
    }

    /** Palette de couleurs ; avec {@code aucun}, la première case retire la couleur (valeur 0). */
    void choisirCouleur(String titre, boolean aucun, Ui.SurInt sur) {
        final AlertDialog[] d = new AlertDialog[1];
        LinearLayout col = Ui.colonne(this);
        col.setPadding(dp(16), dp(10), dp(16), dp(4));
        List<Integer> liste = new ArrayList<>();
        if (aucun) liste.add(0);
        for (int c : COULEURS) liste.add(c);
        LinearLayout ligne = null;
        for (int i = 0; i < liste.size(); i++) {
            if (i % 6 == 0) {
                ligne = Ui.ligne(this);
                ligne.setGravity(Gravity.CENTER);
                col.addView(ligne);
            }
            final int c = liste.get(i);
            View v;
            if (c == 0) {
                TextView x = Ui.texte(this, "⊘", 22, t.texte, true);
                x.setGravity(Gravity.CENTER);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setStroke(dp(2), t.texteDoux);
                x.setBackground(g);
                v = x;
            } else {
                v = new View(this);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(c);
                g.setStroke(dp(2), 0x66FFFFFF);
                v.setBackground(g);
            }
            v.setOnClickListener(x -> {
                sur.v(c);
                if (d[0] != null) d[0].dismiss();
            });
            Ui.pression(v);
            ligne.addView(v, Ui.lpMarges(this, dp(40), dp(40), 5, 5, 5, 5));
        }
        d[0] = Ui.dialogue(this, t).setTitle(titre).setView(col).setNegativeButton("Fermer", null).show();
    }

    @Override
    public void calqueChoisi(ToileVue.Calque c) {
        majTexte(c);
    }

    @Override
    public void modifierCalque(ToileVue.Calque c) {
        saisirTexte(c);
    }

    @Override
    public void dessinChange() {
    }

    // ---- Dessin

    private void panneauDessin() {
        barre("Dessin", true);
        toile.setMode(ToileVue.DESSIN);
        LinearLayout l = Ui.ligne(this);
        String[] noms = {"🖌 Pinceau", "🖍 Surligneur", "╱ Ligne", "➜ Flèche", "▭ Cadre", "◯ Cercle"};
        for (int i = 0; i < noms.length; i++) {
            final int k = i;
            l.addView(puce(noms[i], i == toile.outil, v -> {
                toile.outil = k;
                choixActif(l, k);
            }), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        }
        panneau.addView(rangee(l));
        LinearLayout c = Ui.ligne(this);
        final List<View> pastilles = new ArrayList<>();
        for (int col : COULEURS) {
            View v = new View(this);
            pastilles.add(v);
            v.setOnClickListener(x -> {
                toile.couleurDessin = col;
                majPastilles(pastilles);
            });
            c.addView(v, Ui.lpMarges(this, dp(30), dp(30), 4, 4, 4, 4));
        }
        majPastilles(pastilles);
        panneau.addView(rangee(c));
        LinearLayout bas = Ui.ligne(this);
        TextView ep = Ui.texte(this, "Épaisseur", 13, t.texte, false);
        bas.addView(ep, Ui.lp(dp(80), -2));
        SeekBar s = new SeekBar(this);
        s.setMax(39);
        s.setProgress(Math.round(toile.epaisseurDessin) - 1);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                toile.epaisseurDessin = p + 1;
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        bas.addView(s, Ui.lpPoids(1));
        bas.addView(puce("↶ Trait", false, v -> toile.annulerTrait()));
        panneau.addView(bas);
        appliquer = () -> {
            if (toile.traits.isEmpty()) {
                fermerOutil();
                return;
            }
            final List<ToileVue.Trait> tr = new ArrayList<>(toile.traits);
            fermerOutil();
            traiter("Ajout du dessin…", x -> {
                Bitmap r = x.copy(Bitmap.Config.ARGB_8888, true);
                Canvas cv = new Canvas(r);
                for (ToileVue.Trait k : tr) ToileVue.dessinerTrait(cv, k);
                return r;
            }, null);
        };
    }

    private void majPastilles(List<View> pastilles) {
        for (int i = 0; i < pastilles.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(COULEURS[i]);
            boolean actif = COULEURS[i] == toile.couleurDessin;
            g.setStroke(dp(actif ? 3 : 1), actif ? t.accent : 0x66FFFFFF);
            pastilles.get(i).setBackground(g);
            pastilles.get(i).setScaleX(actif ? 1.15f : 1f);
            pastilles.get(i).setScaleY(actif ? 1.15f : 1f);
        }
    }

    // ---- Document

    private void panneauDocument() {
        barre("Document (avant la lecture)", false);
        TextView intro = Ui.texte(this, "Pour une page, un ticket ou un tableau photographié : chaque bouton s'applique tout de suite (↶ pour revenir).", 12, t.texteDoux, false);
        intro.setPadding(dp(4), 0, dp(4), dp(4));
        panneau.addView(intro);
        LinearLayout l = Ui.ligne(this);
        l.addView(puce("📐 Remettre à plat", true, v -> ouvrirOutil(O_PERSPECTIVE)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("⚫ Noir & blanc net", false, v -> traiter("Nettoyage du document…", x -> Retouches.noirEtBlanc(x, 50), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("✨ Couleurs nettes", false, v -> traiter("Amélioration…", x -> Retouches.niveauxAuto(x, false), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("◐ Gris contrasté", false, v -> traiter("Amélioration…", x -> Retouches.niveauxAuto(x, true), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        l.addView(puce("🔍 Plus net", false, v -> traiter("Accentuation…", x -> Retouches.nettete(x, 60), null)), Ui.lpMarges(this, -2, -2, 3, 4, 3, 4));
        panneau.addView(rangee(l));
    }

    private void panneauPerspective() {
        barre("Remettre la page à plat", true);
        toile.setMode(ToileVue.PERSPECTIVE);
        TextView aide = Ui.texte(this, "Placez les 4 points sur les 4 coins de la page (une loupe vous aide). Touchez ✓ : la page est redressée et recadrée.", 12, t.texteDoux, false);
        aide.setPadding(dp(4), 0, dp(4), dp(2));
        panneau.addView(aide);
        appliquer = () -> {
            float[] c = toile.getCoins();
            int cote = Prefs.coteRetouche(this);
            fermerOutil();
            traiter("Redressement de la page…", x -> Retouches.perspective(x, c, cote), null);
        };
    }

    // ------------------------------------------------------------------ Enregistrer, partager, lire

    private boolean outilOuvert() {
        if (outil != O_AUCUN) {
            Ui.toastCourt(this, "Touchez d'abord ✓ (appliquer) ou ✕ (annuler)");
            return true;
        }
        return occupe || actuelle() == null;
    }

    private void enregistrer(boolean puisQuitter) {
        if (outilOuvert()) return;
        if (!Galerie.permissionOk(this)) {
            apresPermission = () -> enregistrer(puisQuitter);
            return;
        }
        final Bitmap b = actuelle();
        final boolean png = Prefs.png(this);
        final int q = Prefs.qualite(this);
        occupe = true;
        montrerAttente("Enregistrement…");
        App.travail().execute(() -> {
            Uri u = null;
            String err = null;
            try {
                u = Galerie.enregistrer(this, b, png, q);
            } catch (Throwable e) {
                err = e.getMessage();
            }
            final Uri fu = u;
            final String fe = err;
            ui.post(() -> {
                occupe = false;
                cacherAttente();
                if (isFinishing()) return;
                if (fu == null) {
                    Ui.toast(this, "Enregistrement impossible" + (fe != null ? " : " + fe : "."));
                    return;
                }
                modifie = false;
                if (puisQuitter) {
                    Ui.toast(this, "Image enregistrée dans Images/" + Galerie.DOSSIER);
                    finish();
                    return;
                }
                Ui.dialogue(this, t).setTitle("Image enregistrée ✓")
                        .setMessage("Elle se trouve dans Images/" + Galerie.DOSSIER + " (visible dans la galerie du téléphone).")
                        .setPositiveButton("Partager", (d, w) -> Galerie.partagerImage(this, fu, png ? "image/png" : "image/jpeg"))
                        .setNegativeButton("OK", null).show();
            });
        });
    }

    private void partager() {
        if (outilOuvert()) return;
        final Bitmap b = actuelle();
        final boolean png = Prefs.png(this);
        final int q = Prefs.qualite(this);
        occupe = true;
        montrerAttente("Préparation…");
        App.travail().execute(() -> {
            File f = null;
            try {
                f = Images.ecrireTemporaire(this, b, Galerie.nom(), png, q);
            } catch (Throwable ignore) {
            }
            final File ff = f;
            ui.post(() -> {
                occupe = false;
                cacherAttente();
                if (isFinishing()) return;
                if (ff == null) {
                    Ui.toast(this, "Partage impossible.");
                    return;
                }
                Galerie.partagerImage(this, Fichiers.uri(this, ff), png ? "image/png" : "image/jpeg");
            });
        });
    }

    /** Écrit l'image actuelle dans un fichier privé (pour la lecture du texte). */
    private void ecrireEdition(Ui.SurBool fini, String[] chemin) {
        final Bitmap b = actuelle();
        occupe = true;
        montrerAttente("Préparation…");
        App.travail().execute(() -> {
            boolean ok = false;
            try {
                File d = new File(getCacheDir(), "edition");
                //noinspection ResultOfMethodCallIgnored
                d.mkdirs();
                File f = new File(d, "lecture_" + System.currentTimeMillis() + ".png");
                try (java.io.OutputStream out = new java.io.FileOutputStream(f)) {
                    ok = b.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
                chemin[0] = f.getAbsolutePath();
            } catch (Throwable ignore) {
            }
            final boolean fok = ok;
            ui.post(() -> {
                occupe = false;
                cacherAttente();
                if (!isFinishing()) fini.v(fok);
            });
        });
    }

    private void lireTexte() {
        if (outilOuvert()) return;
        final String[] chemin = new String[1];
        ecrireEdition(ok -> {
            if (!ok) {
                Ui.toast(this, "Préparation impossible.");
                return;
            }
            Intent i = new Intent(this, ResultatsActivity.class);
            ArrayList<String> l = new ArrayList<>();
            l.add(chemin[0]);
            i.putStringArrayListExtra(ResultatsActivity.EXTRA_SOURCES, l);
            startActivity(i);
        }, chemin);
    }

    private void renvoyerPourLecture() {
        if (outilOuvert()) return;
        final String[] chemin = new String[1];
        ecrireEdition(ok -> {
            if (!ok) {
                Ui.toast(this, "Préparation impossible.");
                return;
            }
            Intent r = new Intent();
            r.putExtra(RESULTAT_CHEMIN, chemin[0]);
            r.putExtra(EXTRA_INDEX, index);
            setResult(RESULT_OK, r);
            modifie = false;
            finish();
        }, chemin);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req != Galerie.DEMANDE_STOCKAGE) return;
        Runnable r = apresPermission;
        apresPermission = null;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            if (r != null) r.run();
        } else {
            Ui.toast(this, "Sans l'autorisation de stockage, l'image ne peut pas être enregistrée. Utilisez « Partager ».");
        }
    }

    @Override
    public void onBackPressed() {
        if (outil != O_AUCUN) {
            fermerOutil();
            return;
        }
        if (occupe) return;
        if (modifie && !pourLecture) {
            Ui.dialogue(this, t).setTitle("Quitter la retouche ?")
                    .setMessage("Vos modifications ne sont pas enregistrées.")
                    .setPositiveButton("Enregistrer", (d, w) -> enregistrer(true))
                    .setNegativeButton("Quitter", (d, w) -> finish())
                    .setNeutralButton("Rester", null).show();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        cacherAttente();
        super.onDestroy();
        // Libère la mémoire des images ; le traitement éventuel en cours garde sa propre copie de référence.
        if (!occupe) {
            for (Bitmap b : pile) if (b != null && !b.isRecycled()) b.recycle();
        }
        pile.clear();
    }

    /** Ouvre l'éditeur sur une image en transmettant l'autorisation de lecture. */
    static Intent intention(Activity a, String source, boolean pourLecture, int index) {
        Intent i = new Intent(a, EditeurActivity.class);
        i.putExtra(EXTRA_SOURCE, source);
        i.putExtra(EXTRA_POUR_LECTURE, pourLecture);
        i.putExtra(EXTRA_INDEX, index);
        if (source != null && !source.startsWith("/")) {
            i.setClipData(ClipData.newRawUri("image", Uri.parse(source)));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        return i;
    }
}
