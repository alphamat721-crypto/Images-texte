package bf.alphamat.imagetexte;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Chargement sûr des images (taille limitée, orientation EXIF corrigée) et petits fichiers temporaires. */
final class Images {

    private Images() {
    }

    /** Une « source » est soit un chemin de fichier (commence par /), soit une adresse content:// ou file://. */
    static InputStream ouvrir(Context c, String source) throws IOException {
        if (source == null) throw new IOException("Aucune image");
        if (source.startsWith("/")) return new FileInputStream(source);
        Uri u = Uri.parse(source);
        if (ContentResolver.SCHEME_FILE.equals(u.getScheme()) && u.getPath() != null) return new FileInputStream(u.getPath());
        InputStream in = c.getContentResolver().openInputStream(u);
        if (in == null) throw new IOException("Image illisible");
        return in;
    }

    /**
     * Charge l'image en limitant son plus grand côté à {@code maxCote} pixels, correctement orientée.
     * Ne renvoie jamais null : lève une IOException avec un message clair.
     */
    static Bitmap charger(Context c, String source, int maxCote) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = ouvrir(c, source)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        if (o.outWidth <= 0 || o.outHeight <= 0) throw new IOException("Ce fichier n'est pas une image lisible");
        int lg = Math.max(o.outWidth, o.outHeight);
        int ech = 1;
        while (lg / (ech * 2) >= maxCote) ech *= 2;
        Bitmap b = null;
        for (int essai = 0; essai < 4 && b == null; essai++) {
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = ech;
            d.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream in = ouvrir(c, source)) {
                b = BitmapFactory.decodeStream(in, null, d);
            } catch (OutOfMemoryError e) {
                b = null;
                ech *= 2;
            }
            if (b == null && essai == 0 && ech == d.inSampleSize) break;
        }
        if (b == null) throw new IOException("Image trop grande ou abîmée");
        b = reduire(b, maxCote);
        int rot = orientation(c, source);
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            try {
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != b) b.recycle();
                b = r;
            } catch (OutOfMemoryError ignore) {
                // On garde l'image non tournée plutôt que d'échouer.
            }
        }
        if (b.getConfig() != Bitmap.Config.ARGB_8888) {
            try {
                Bitmap m = b.copy(Bitmap.Config.ARGB_8888, false);
                if (m != null) {
                    if (m != b) b.recycle();
                    b = m;
                }
            } catch (OutOfMemoryError ignore) {
            }
        }
        return b;
    }

    static Bitmap reduire(Bitmap b, int maxCote) {
        int w = b.getWidth(), h = b.getHeight();
        int lg = Math.max(w, h);
        if (lg <= maxCote) return b;
        float f = maxCote / (float) lg;
        int nw = Math.max(1, Math.round(w * f)), nh = Math.max(1, Math.round(h * f));
        try {
            Bitmap r = Bitmap.createScaledBitmap(b, nw, nh, true);
            if (r != b) b.recycle();
            return r;
        } catch (OutOfMemoryError e) {
            return b;
        }
    }

    /** Rotation EXIF en degrés (0, 90, 180, 270). Toute erreur donne 0. */
    static int orientation(Context c, String source) {
        File tmp = null;
        try {
            ExifInterface ex;
            if (source.startsWith("/")) {
                ex = new ExifInterface(source);
            } else if (Uri.parse(source).getScheme() != null && Uri.parse(source).getScheme().equals("file")) {
                ex = new ExifInterface(Uri.parse(source).getPath());
            } else if (Build.VERSION.SDK_INT >= 24) {
                try (InputStream in = ouvrir(c, source)) {
                    ex = new ExifInterface(in);
                }
            } else {
                // Android 5 / 6 : ExifInterface ne lit que des fichiers ; on copie le début de l'image (l'EXIF y est).
                tmp = new File(c.getCacheDir(), "exif_tmp.jpg");
                try (InputStream in = ouvrir(c, source); OutputStream out = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[16384];
                    int total = 0, n;
                    while (total < 262144 && (n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        total += n;
                    }
                }
                ex = new ExifInterface(tmp.getAbsolutePath());
            }
            int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (o) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                case ExifInterface.ORIENTATION_TRANSPOSE:
                    return 90;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    return 180;
                case ExifInterface.ORIENTATION_ROTATE_270:
                case ExifInterface.ORIENTATION_TRANSVERSE:
                    return 270;
                default:
                    return 0;
            }
        } catch (Throwable e) {
            return 0;
        } finally {
            if (tmp != null) //noinspection ResultOfMethodCallIgnored
                tmp.delete();
        }
    }

    /** Copie de travail sans transparence (fond blanc), utile avant JPEG ou lecture de texte. */
    static Bitmap surFondBlanc(Bitmap b) {
        Bitmap r = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(r);
        cv.drawColor(0xFFFFFFFF);
        cv.drawBitmap(b, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG));
        return r;
    }

    /** Dossier temporaire partagé avec les autres applis via {@link Fichiers}. */
    static File dossierPartage(Context c) {
        File d = new File(c.getCacheDir(), "partage");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    static File ecrireTemporaire(Context c, Bitmap b, String nom, boolean png, int qualite) throws IOException {
        File f = new File(dossierPartage(c), nom + (png ? ".png" : ".jpg"));
        try (OutputStream out = new FileOutputStream(f)) {
            Bitmap aEcrire = png ? b : (b.hasAlpha() ? surFondBlanc(b) : b);
            if (!aEcrire.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, qualite, out))
                throw new IOException("Écriture impossible");
            if (aEcrire != b) aEcrire.recycle();
        }
        return f;
    }

    /** Vide les fichiers temporaires de plus d'un jour. */
    static void nettoyer(Context c) {
        long limite = System.currentTimeMillis() - 24L * 3600 * 1000;
        File[] dossiers = {dossierPartage(c), new File(c.getCacheDir(), "photos"), new File(c.getCacheDir(), "edition")};
        for (File d : dossiers) {
            File[] l = d.listFiles();
            if (l == null) continue;
            for (File f : l) if (f.lastModified() < limite) //noinspection ResultOfMethodCallIgnored
                f.delete();
        }
    }
}
