package bf.alphamat.imagetexte;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Réglages en menus repliables (ouvrir un menu referme le précédent). */
public class ReglagesActivity extends Activity {

    private static final int EXPORT = 41;
    private Visuel.Theme t;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        t = Visuel.theme(this);
        Visuel.barres(this, t);
        construire(b == null ? -1 : b.getInt("ouvert", -1));
    }

    private Accordeon acc;

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        if (acc != null) o.putInt("ouvert", acc.ouverte());
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void construire(int aOuvrir) {
        FrameLayout racine = new FrameLayout(this);
        racine.addView(new Decor(this, t), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = Ui.colonne(this);
        col.setPadding(0, 0, 0, dp(24));

        LinearLayout entete = Ui.ligne(this);
        entete.setPadding(dp(8), dp(12), dp(16), dp(6));
        TextView retour = Ui.texte(this, "←", 24, t.texte, true);
        retour.setPadding(dp(10), 0, dp(12), 0);
        retour.setOnClickListener(v -> finish());
        entete.addView(retour);
        entete.addView(Ui.texte(this, "Réglages", 22, t.texte, true), Ui.lpPoids(1));
        col.addView(entete);

        acc = new Accordeon(this, t, col);

        // 0 — Thème
        LinearLayout th = acc.section("🎨", "Thème 3D", t.nom);
        for (int i = 0; i < Visuel.THEMES.length; i++) {
            final int k = i;
            Visuel.Theme x = Visuel.THEMES[i];
            boolean actif = Prefs.i(this, Prefs.THEME, 0) == i;
            LinearLayout lg = Ui.ligne(this);
            lg.setPadding(dp(6), dp(6), dp(10), dp(6));
            lg.setBackground(Visuel.puce(this, t, actif));
            FrameLayout apercu = new FrameLayout(this);
            apercu.addView(new Decor(this, x, false), new FrameLayout.LayoutParams(-1, -1));
            apercu.setClipToOutline(true);
            apercu.setBackground(Visuel.puce(this, x, false));
            lg.addView(apercu, Ui.lpMarges(this, dp(64), dp(44), 0, 0, 10, 0));
            LinearLayout tx = Ui.colonne(this);
            tx.addView(Ui.texte(this, x.nom, 15, actif ? 0xFFFFFFFF : t.texte, true));
            tx.addView(Ui.texte(this, x.ambiance, 12, actif ? 0xDDFFFFFF : t.texteDoux, false));
            lg.addView(tx, Ui.lpPoids(1));
            if (actif) lg.addView(Ui.texte(this, "✓", 18, 0xFFFFFFFF, true));
            lg.setClickable(true);
            lg.setOnClickListener(v -> {
                Prefs.setI(this, Prefs.THEME, k);
                recreate();
            });
            Ui.pression(lg);
            th.addView(lg, Ui.lpMarges(this, -1, -2, 0, 3, 0, 3));
        }

        // 1 — Lecture
        LinearLayout lec = acc.section("🔤", "Lecture du texte", "Mise en page, amélioration, enregistrement");
        lec.addView(sousTitre("Mise en page du texte lu"));
        LinearLayout mp = Ui.ligne(this);
        String[] mps = {"Lignes comme sur l'image", "Paragraphes"};
        for (int i = 0; i < 2; i++) {
            final int k = i;
            mp.addView(choix(mps[i], Prefs.i(this, Prefs.MISE_EN_PAGE, 0) == i, v -> {
                Prefs.setI(this, Prefs.MISE_EN_PAGE, k);
                actifs(mp, k);
            }), Ui.lpMarges(this, -2, -2, 0, 2, 6, 2));
        }
        lec.addView(mp);
        lec.addView(note("« Paragraphes » recolle les lignes et les mots coupés par un tiret : pratique pour copier un article."));
        lec.addView(interrupteur("Améliorer l'image avant la lecture",
                "Contraste renforcé en gris : utile pour les photos sombres ou floues.", Prefs.AMELIORER, false));
        lec.addView(interrupteur("Enregistrer automatiquement les textes lus",
                "Chaque texte lu est rangé dans l'onglet Textes.", Prefs.AUTO_ENREG, true));
        lec.addView(note("La lecture fonctionne sans Internet et reconnaît l'alphabet latin (français, anglais, langues africaines écrites en lettres latines…). "
                + "L'écriture manuscrite très liée est moins bien reconnue."));

        // 2 — Images
        LinearLayout img = acc.section("🖼", "Images enregistrées", "Format, qualité, taille de travail");
        img.addView(sousTitre("Format"));
        LinearLayout fm = Ui.ligne(this);
        String[] fms = {"JPEG (léger)", "PNG (sans perte)"};
        for (int i = 0; i < 2; i++) {
            final int k = i;
            fm.addView(choix(fms[i], Prefs.i(this, Prefs.FORMAT, 0) == i, v -> {
                Prefs.setI(this, Prefs.FORMAT, k);
                actifs(fm, k);
            }), Ui.lpMarges(this, -2, -2, 0, 2, 6, 2));
        }
        img.addView(fm);
        img.addView(sousTitre("Qualité JPEG"));
        LinearLayout ql = Ui.ligne(this);
        SeekBar sq = new SeekBar(this);
        sq.setMax(40);
        sq.setProgress(Prefs.qualite(this) - 60);
        TextView vq = Ui.texte(this, Prefs.qualite(this) + " %", 13, t.accent, true);
        sq.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                vq.setText((p + 60) + " %");
                if (u) Prefs.setI(ReglagesActivity.this, Prefs.QUALITE, p + 60);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        ql.addView(sq, Ui.lpPoids(1));
        ql.addView(vq, Ui.lp(dp(52), -2));
        img.addView(ql);
        img.addView(sousTitre("Taille de travail dans la retouche"));
        LinearLayout tl = Ui.ligne(this);
        String[] tls = {"Normale", "Haute définition"};
        for (int i = 0; i < 2; i++) {
            final int k = i;
            tl.addView(choix(tls[i], Prefs.i(this, Prefs.TAILLE_RETOUCHE, 0) == i, v -> {
                Prefs.setI(this, Prefs.TAILLE_RETOUCHE, k);
                actifs(tl, k);
            }), Ui.lpMarges(this, -2, -2, 0, 2, 6, 2));
        }
        img.addView(tl);
        img.addView(note("Normale : " + (BuildConfig.LITE ? "1280" : "1920") + " px, rapide et économe. Haute : "
                + (BuildConfig.LITE ? "1600" : "2560") + " px, plus détaillée mais demande plus de mémoire. "
                + "Les images sont enregistrées dans Images/" + Galerie.DOSSIER + "."));

        // 3 — Bibliothèque
        LinearLayout bib = acc.section("📚", "Mes textes", Bibliotheque.nombre(this) + " texte(s) enregistré(s)");
        bib.addView(action("⬇ Exporter tous les textes en un fichier .txt", v -> exporterTout()));
        bib.addView(action("🗑 Supprimer tous les textes", v -> {
            if (Bibliotheque.nombre(this) == 0) {
                Ui.toastCourt(this, "Aucun texte enregistré");
                return;
            }
            Ui.dialogue(this, t).setTitle("Tout supprimer ?")
                    .setMessage("Les " + Bibliotheque.nombre(this) + " textes seront effacés définitivement de l'appli. Vos images ne sont pas touchées.")
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Tout supprimer", (d, w) -> {
                        Bibliotheque.toutSupprimer(this);
                        Ui.toast(this, "Tous les textes ont été supprimés.");
                        recreate();
                    }).show();
        }));

        // 4 — À propos
        LinearLayout ap = acc.section("ℹ️", "À propos", "Image Texte v" + App.version());
        ap.addView(note("Image Texte v" + App.version() + (BuildConfig.LITE ? " (Lite, Android 5.1 et plus)" : " (Android 8 et plus)")
                + "\nLecture du texte et retouche, entièrement sur le téléphone : vos images ne quittent jamais votre appareil."));
        ap.addView(action("❓ Aide complète", v -> startActivity(new Intent(this, AideActivity.class))));
        ap.addView(action("🔄 Rechercher une mise à jour", v -> MisesAJour.verifier(this, true)));
        ap.addView(action("📱 Mes autres applis et logiciels", v -> Ui.autresApplis(this, t)));

        racine.addView(Ui.defilement(this, col), new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
        if (aOuvrir >= 0) acc.ouvrir(aOuvrir);
    }

    private TextView sousTitre(String s) {
        TextView v = Ui.texte(this, s, 13.5f, t.texte, true);
        v.setPadding(dp(2), dp(10), 0, dp(4));
        return v;
    }

    private TextView note(String s) {
        TextView v = Ui.texte(this, s, 12.5f, t.texteDoux, false);
        v.setPadding(dp(2), dp(6), dp(2), dp(4));
        return v;
    }

    private TextView choix(String s, boolean actif, View.OnClickListener cl) {
        TextView p = Ui.texte(this, s, 13.5f, actif ? 0xFFFFFFFF : t.texte, true);
        p.setGravity(Gravity.CENTER);
        p.setPadding(dp(12), dp(8), dp(12), dp(8));
        p.setBackground(Visuel.puce(this, t, actif));
        p.setClickable(true);
        p.setOnClickListener(cl);
        Ui.pression(p);
        return p;
    }

    private void actifs(LinearLayout g, int k) {
        for (int i = 0; i < g.getChildCount(); i++) {
            TextView v = (TextView) g.getChildAt(i);
            v.setBackground(Visuel.puce(this, t, i == k));
            v.setTextColor(i == k ? 0xFFFFFFFF : t.texte);
        }
    }

    private View interrupteur(String titre, String desc, String cle, boolean defaut) {
        LinearLayout lg = Ui.ligne(this);
        lg.setPadding(dp(2), dp(10), 0, dp(6));
        LinearLayout tx = Ui.colonne(this);
        tx.addView(Ui.texte(this, titre, 14.5f, t.texte, true));
        tx.addView(Ui.texte(this, desc, 12, t.texteDoux, false));
        lg.addView(tx, Ui.lpPoids(1));
        final TextView b = Ui.texte(this, "", 13, t.texte, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        Runnable maj = () -> {
            boolean on = Prefs.b(this, cle, defaut);
            b.setText(on ? "Activé" : "Désactivé");
            b.setBackground(Visuel.puce(this, t, on));
            b.setTextColor(on ? 0xFFFFFFFF : t.texte);
        };
        maj.run();
        View.OnClickListener cl = v -> {
            Prefs.setB(this, cle, !Prefs.b(this, cle, defaut));
            maj.run();
        };
        b.setOnClickListener(cl);
        lg.setOnClickListener(cl);
        Ui.pression(b);
        lg.addView(b, Ui.lpMarges(this, dp(96), -2, 8, 0, 0, 0));
        return lg;
    }

    private TextView action(String s, View.OnClickListener cl) {
        TextView v = Ui.texte(this, s, 14, t.texte, true);
        v.setPadding(dp(12), dp(11), dp(12), dp(11));
        v.setBackground(Visuel.puce(this, t, false));
        v.setClickable(true);
        v.setOnClickListener(cl);
        Ui.pression(v);
        LinearLayout.LayoutParams p = Ui.lpMarges(this, -1, -2, 0, 4, 0, 4);
        v.setLayoutParams(p);
        return v;
    }

    private void exporterTout() {
        if (Bibliotheque.nombre(this) == 0) {
            Ui.toastCourt(this, "Aucun texte enregistré");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TITLE, "ImageTexte_tous_les_textes.txt");
            startActivityForResult(i, EXPORT);
        } catch (Exception e) {
            Ui.toast(this, "Aucune appli pour enregistrer un fichier.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != EXPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
            if (out == null) throw new java.io.IOException("Fichier inaccessible");
            out.write(Bibliotheque.toutEnUn(this).getBytes(StandardCharsets.UTF_8));
            Ui.toast(this, "Tous les textes ont été exportés.");
        } catch (Exception e) {
            Ui.toast(this, "Écriture impossible : " + e.getMessage());
        }
    }
}
