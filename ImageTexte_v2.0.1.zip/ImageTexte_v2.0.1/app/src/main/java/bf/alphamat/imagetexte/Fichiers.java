package bf.alphamat.imagetexte;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Petit fournisseur de fichiers (sans bibliothèque externe) :
 * - « partage/… » : images et textes à envoyer aux autres applis (lecture seule) ;
 * - « photos/… » : photo prise par l'appareil photo (écriture autorisée pour l'appli Appareil photo).
 * Seuls ces deux dossiers du cache sont accessibles ; tout chemin qui en sort est refusé.
 */
public class Fichiers extends ContentProvider {

    static String autorite(Context c) {
        return c.getPackageName() + ".fichiers";
    }

    static Uri uri(Context c, File f) {
        File parent = f.getParentFile();
        String dossier = parent == null ? "" : parent.getName();
        return new Uri.Builder().scheme("content").authority(autorite(c))
                .appendPath(dossier).appendPath(f.getName()).build();
    }

    static File dossierPhotos(Context c) {
        File d = new File(c.getCacheDir(), "photos");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    private File fichier(Uri uri) throws FileNotFoundException {
        Context c = getContext();
        if (c == null) throw new FileNotFoundException();
        java.util.List<String> seg = uri.getPathSegments();
        if (seg == null || seg.size() != 2) throw new FileNotFoundException("Chemin invalide");
        String dossier = seg.get(0), nom = seg.get(1);
        if (!dossier.equals("partage") && !dossier.equals("photos")) throw new FileNotFoundException("Dossier interdit");
        if (nom.contains("/") || nom.contains("..")) throw new FileNotFoundException("Nom interdit");
        File base = new File(c.getCacheDir(), dossier);
        File f = new File(base, nom);
        try {
            if (!f.getCanonicalPath().startsWith(base.getCanonicalPath() + File.separator))
                throw new FileNotFoundException("Chemin interdit");
        } catch (IOException e) {
            throw new FileNotFoundException("Chemin invalide");
        }
        return f;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = fichier(uri);
        boolean ecriture = mode != null && mode.contains("w");
        if (ecriture) {
            if (!"photos".equals(uri.getPathSegments().get(0))) throw new FileNotFoundException("Lecture seule");
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_WRITE
                    | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE);
        }
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f;
        try {
            f = fichier(uri);
        } catch (FileNotFoundException e) {
            return null;
        }
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor mc = new MatrixCursor(cols, 1);
        Object[] ligne = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) ligne[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) ligne[i] = f.length();
            else ligne[i] = null;
        }
        mc.addRow(ligne);
        return mc;
    }

    @Override
    public String getType(Uri uri) {
        String n = uri.getLastPathSegment();
        if (n == null) return "application/octet-stream";
        n = n.toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
