package bf.alphamat.imagetexte;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Traitements d'image. Chaque méthode renvoie une NOUVELLE image et ne touche jamais à l'originale
 * (l'éditeur garde les anciennes pour « Annuler »).
 */
final class Retouches {

    private Retouches() {
    }

    // ---------------------------------------------------------------- Couleurs

    /** Réglages fins. Chaque valeur va de -100 à +100 (0 = inchangé). */
    static ColorMatrix reglages(int luminosite, int contraste, int saturation, int chaleur) {
        ColorMatrix m = new ColorMatrix();
        ColorMatrix s = new ColorMatrix();
        s.setSaturation(Math.max(0f, 1f + saturation / 100f));
        m.postConcat(s);
        float c = 1f + contraste / 100f;
        if (contraste > 0) c = 1f + contraste / 60f;
        float t = 128f * (1f - c);
        m.postConcat(new ColorMatrix(new float[]{
                c, 0, 0, 0, t,
                0, c, 0, 0, t,
                0, 0, c, 0, t,
                0, 0, 0, 1, 0}));
        float l = luminosite * 1.1f;
        float w = chaleur * 0.35f;
        m.postConcat(new ColorMatrix(new float[]{
                1, 0, 0, 0, l + w,
                0, 1, 0, 0, l + w * 0.25f,
                0, 0, 1, 0, l - w,
                0, 0, 0, 1, 0}));
        return m;
    }

    static final String[] FILTRES = {"Original", "Noir & blanc", "Sépia", "Éclatant", "Froid", "Chaud",
            "Vintage", "Dramatique", "Doux", "Encre", "Nuit bleue", "Or"};

    /** true si le filtre ajoute un assombrissement des bords. */
    static boolean vignette(int filtre) {
        return filtre == 6 || filtre == 7 || filtre == 11;
    }

    static ColorMatrix filtre(int f) {
        ColorMatrix m = new ColorMatrix();
        switch (f) {
            case 1: // Noir & blanc
                m.setSaturation(0f);
                m.postConcat(reglages(0, 10, 0, 0));
                break;
            case 2: // Sépia
                m.setSaturation(0f);
                m.postConcat(new ColorMatrix(new float[]{
                        1.07f, 0, 0, 0, 18,
                        0, 0.94f, 0, 0, 6,
                        0, 0, 0.74f, 0, -8,
                        0, 0, 0, 1, 0}));
                break;
            case 3: // Éclatant
                m.set(reglages(4, 18, 55, 0));
                break;
            case 4: // Froid
                m.set(reglages(2, 8, -5, -55));
                break;
            case 5: // Chaud
                m.set(reglages(3, 6, 10, 60));
                break;
            case 6: // Vintage : noirs délavés, teinte crème
                m.setSaturation(0.55f);
                m.postConcat(new ColorMatrix(new float[]{
                        0.88f, 0, 0, 0, 34,
                        0, 0.84f, 0, 0, 26,
                        0, 0, 0.72f, 0, 18,
                        0, 0, 0, 1, 0}));
                break;
            case 7: // Dramatique
                m.set(reglages(-6, 45, -25, 0));
                break;
            case 8: // Doux
                m.set(reglages(10, -25, -10, 10));
                break;
            case 9: // Encre : noir et blanc très contrasté
                m.setSaturation(0f);
                m.postConcat(reglages(5, 90, 0, 0));
                break;
            case 10: // Nuit bleue
                m.setSaturation(0.6f);
                m.postConcat(new ColorMatrix(new float[]{
                        0.75f, 0, 0, 0, -6,
                        0, 0.9f, 0, 0, 4,
                        0, 0, 1.15f, 0, 22,
                        0, 0, 0, 1, 0}));
                break;
            case 11: // Or
                m.set(reglages(4, 20, 15, 70));
                break;
            default:
                break;
        }
        return m;
    }

    /** Assombrit doucement les bords (effet photo ancienne). */
    static void dessinerVignette(Canvas c, RectF zone) {
        float cx = zone.centerX(), cy = zone.centerY();
        float r = (float) Math.hypot(zone.width(), zone.height()) * 0.62f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, r, new int[]{0x00000000, 0x00000000, 0x8C000000},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(zone, p);
    }

    static Bitmap appliquerCouleurs(Bitmap b, ColorMatrix m, boolean vignette) {
        Bitmap r = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(r);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new ColorMatrixColorFilter(m));
        c.drawBitmap(b, 0, 0, p);
        if (vignette) dessinerVignette(c, new RectF(0, 0, b.getWidth(), b.getHeight()));
        return r;
    }

    // ---------------------------------------------------------------- Géométrie

    static Bitmap tourner90(Bitmap b, boolean horaire) {
        Matrix m = new Matrix();
        m.postRotate(horaire ? 90 : -90);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
    }

    static Bitmap retourner(Bitmap b, boolean horizontal) {
        Matrix m = new Matrix();
        if (horizontal) m.postScale(-1, 1);
        else m.postScale(1, -1);
        return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
    }

    /** Agrandissement nécessaire pour qu'une image tournée de {@code degres} remplisse encore tout le cadre. */
    static float echelleRedressement(int w, int h, float degres) {
        double a = Math.toRadians(Math.abs(degres));
        double cs = Math.cos(a), sn = Math.sin(a);
        return (float) Math.max((w * cs + h * sn) / w, (w * sn + h * cs) / h);
    }

    /** Redresse l'image d'un petit angle (horizon penché, document de travers) en gardant le même cadre. */
    static Bitmap redresser(Bitmap b, float degres) {
        int w = b.getWidth(), h = b.getHeight();
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(r);
        float s = echelleRedressement(w, h, degres);
        c.rotate(degres, w / 2f, h / 2f);
        c.scale(s, s, w / 2f, h / 2f);
        c.drawBitmap(b, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return r;
    }

    static Bitmap rogner(Bitmap b, RectF zone) {
        Rect r = new Rect(Math.round(zone.left), Math.round(zone.top), Math.round(zone.right), Math.round(zone.bottom));
        r.left = Math.max(0, Math.min(b.getWidth() - 1, r.left));
        r.top = Math.max(0, Math.min(b.getHeight() - 1, r.top));
        r.right = Math.max(r.left + 1, Math.min(b.getWidth(), r.right));
        r.bottom = Math.max(r.top + 1, Math.min(b.getHeight(), r.bottom));
        return Bitmap.createBitmap(b, r.left, r.top, r.width(), r.height());
    }

    /**
     * Remet à plat un document photographié de biais.
     * {@code coins} = 8 valeurs (x,y) dans l'ordre : haut-gauche, haut-droit, bas-droit, bas-gauche.
     */
    static Bitmap perspective(Bitmap b, float[] coins, int maxCote) {
        float largeur = Math.max(dist(coins, 0, 1), dist(coins, 3, 2));
        float hauteur = Math.max(dist(coins, 0, 3), dist(coins, 1, 2));
        float f = Math.min(1f, maxCote / Math.max(largeur, hauteur));
        int w = Math.max(16, Math.round(largeur * f)), h = Math.max(16, Math.round(hauteur * f));
        float[] dst = {0, 0, w, 0, w, h, 0, h};
        Matrix m = new Matrix();
        if (!m.setPolyToPoly(coins, 0, dst, 0, 4)) throw new IllegalArgumentException("Coins invalides");
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(r);
        c.drawColor(0xFFFFFFFF);
        c.drawBitmap(b, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return r;
    }

    private static float dist(float[] p, int i, int j) {
        return (float) Math.hypot(p[i * 2] - p[j * 2], p[i * 2 + 1] - p[j * 2 + 1]);
    }

    // ---------------------------------------------------------------- Document

    private static int lum(int c) {
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    /**
     * Étire automatiquement les niveaux (le plus sombre devient noir, le plus clair blanc).
     * Avec {@code gris}, renvoie une image en niveaux de gris : idéal avant la lecture du texte.
     */
    static Bitmap niveauxAuto(Bitmap b, boolean gris) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int[] histo = new int[256];
        for (int c : px) histo[lum(c)]++;
        int n = px.length, bas = 0, haut = 255, cumul = 0;
        int seuilBas = n / 100, seuilHaut = n - n / 100;
        for (int i = 0; i < 256; i++) {
            cumul += histo[i];
            if (cumul <= seuilBas) bas = i;
            if (cumul < seuilHaut) haut = i;
        }
        if (haut - bas < 30) {
            bas = Math.max(0, bas - 15);
            haut = Math.min(255, haut + 15);
        }
        int[] lut = new int[256];
        float etendue = Math.max(1, haut - bas);
        for (int i = 0; i < 256; i++) lut[i] = Math.max(0, Math.min(255, Math.round((i - bas) * 255f / etendue)));
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int a = c & 0xFF000000;
            if (gris) {
                int v = lut[lum(c)];
                px[i] = a | (v << 16) | (v << 8) | v;
            } else {
                px[i] = a | (lut[(c >> 16) & 0xFF] << 16) | (lut[(c >> 8) & 0xFF] << 8) | lut[c & 0xFF];
            }
        }
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        r.setPixels(px, 0, w, 0, 0, w, h);
        return r;
    }

    /**
     * Document en noir et blanc net (seuil adaptatif) : supprime les ombres et le fond gris d'une page photographiée.
     * {@code force} de 0 à 100 : plus la valeur est haute, plus les traits fins sont gardés.
     */
    static Bitmap noirEtBlanc(Bitmap b, int force) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int[] integ = new int[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            int somme = 0;
            int ligne = y * w;
            for (int x = 0; x < w; x++) {
                int v = lum(px[ligne + x]);
                px[ligne + x] = v;
                somme += v;
                integ[(y + 1) * (w + 1) + x + 1] = integ[y * (w + 1) + x + 1] + somme;
            }
        }
        int demi = Math.max(8, Math.max(w, h) / 24);
        float t = 0.08f + (100 - Math.max(0, Math.min(100, force))) * 0.0012f; // 0.08 .. 0.20
        for (int y = 0; y < h; y++) {
            int y1 = Math.max(0, y - demi), y2 = Math.min(h - 1, y + demi);
            for (int x = 0; x < w; x++) {
                int x1 = Math.max(0, x - demi), x2 = Math.min(w - 1, x + demi);
                int compte = (x2 - x1 + 1) * (y2 - y1 + 1);
                long s = (long) integ[(y2 + 1) * (w + 1) + x2 + 1] - integ[y1 * (w + 1) + x2 + 1]
                        - integ[(y2 + 1) * (w + 1) + x1] + integ[y1 * (w + 1) + x1];
                int v = px[y * w + x];
                boolean noir = (long) v * compte < s * (1f - t);
                px[y * w + x] = noir ? 0xFF111111 : 0xFFFFFFFF;
            }
        }
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        r.setPixels(px, 0, w, 0, 0, w, h);
        return r;
    }

    /** Rend les textes plus nets (accentuation légère, matrice 3×3). */
    static Bitmap nettete(Bitmap b, int force) {
        int w = b.getWidth(), h = b.getHeight();
        int[] src = new int[w * h];
        b.getPixels(src, 0, w, 0, 0, w, h);
        int[] dst = new int[w * h];
        float k = Math.max(0, Math.min(100, force)) / 100f; // 0..1
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int c = src[i];
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) {
                    dst[i] = c;
                    continue;
                }
                int n = src[i - w], s = src[i + w], o = src[i - 1], e = src[i + 1];
                int r = canal(c, n, s, o, e, 16, k), g = canal(c, n, s, o, e, 8, k), bl = canal(c, n, s, o, e, 0, k);
                dst[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | bl;
            }
        }
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        r.setPixels(dst, 0, w, 0, 0, w, h);
        return r;
    }

    private static int canal(int c, int n, int s, int o, int e, int dec, float k) {
        int v = (c >> dec) & 0xFF;
        int voisins = ((n >> dec) & 0xFF) + ((s >> dec) & 0xFF) + ((o >> dec) & 0xFF) + ((e >> dec) & 0xFF);
        float res = v + k * (4 * v - voisins);
        return Math.max(0, Math.min(255, Math.round(res)));
    }
}
