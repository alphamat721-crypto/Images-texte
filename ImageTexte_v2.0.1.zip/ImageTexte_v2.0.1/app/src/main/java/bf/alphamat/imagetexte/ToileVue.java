package bf.alphamat.imagetexte;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Zone d'édition : affiche l'image (ajustée à l'écran) et gère, selon le mode,
 * le cadre de rognage, les 4 coins de la perspective, les calques de texte et le dessin.
 * Toutes les positions sont gardées en pixels de l'image : le résultat final est exact.
 */
class ToileVue extends View {

    static final int AUCUN = 0, ROGNER = 1, PERSPECTIVE = 2, TEXTE = 3, DESSIN = 4;

    static final int P_PINCEAU = 0, P_SURLIGNEUR = 1, P_LIGNE = 2, P_FLECHE = 3, P_RECT = 4, P_CERCLE = 5;

    static final String[] POLICES = {"Moderne", "Élégante", "Machine", "Manuscrite", "Condensée"};

    interface Ecouteur {
        void calqueChoisi(Calque c);

        void modifierCalque(Calque c);

        void dessinChange();
    }

    static final class Calque {
        String texte = "Votre texte";
        float x, y, taille, angle;
        int couleur = 0xFFFFFFFF;
        int police = 0;
        boolean gras = true;
        int contour = 0;       // 0 = aucun, sinon couleur
        boolean ombre = true;
        int fond = 0;          // 0 = aucun, sinon couleur (semi-transparente)
    }

    static final class Trait {
        int outil, couleur;
        float epaisseur;
        final Path chemin = new Path();
        float x1, y1, x2, y2;
    }

    private Bitmap image;
    private final Matrix versVue = new Matrix(), versImage = new Matrix();
    private final Paint pImage = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTexte = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tmp = new Path();
    private final float d;
    private int accent = 0xFF4F8BFF;
    private Ecouteur ecouteur;

    private int mode = AUCUN;
    private ColorMatrix apercuCouleurs;
    private boolean apercuVignette, montrerAvant, grille;
    private float angleApercu;

    // Rognage
    private final RectF cadre = new RectF();
    private float ratio; // largeur / hauteur ; 0 = libre
    private int poignee = -1;
    private float dX, dY;
    private final RectF cadreDepart = new RectF();

    // Perspective
    private final float[] coins = new float[8];
    private int coin = -1;
    private float doigtX, doigtY;

    // Textes
    final List<Calque> calques = new ArrayList<>();
    private Calque choisi;
    private float dist0, angle0, taille0, angleCalque0;
    private long dernierTap;
    private boolean deplace;

    // Dessin
    final List<Trait> traits = new ArrayList<>();
    private Trait enCours;
    int outil = P_PINCEAU, couleurDessin = 0xFFFF3B30;
    float epaisseurDessin = 8; // en « points » : converti selon la taille de l'image

    ToileVue(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setLayerType(LAYER_TYPE_SOFTWARE, null); // ombres de texte et loupe identiques sur tous les Android
    }

    void setEcouteur(Ecouteur e) {
        ecouteur = e;
    }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setImage(Bitmap b) {
        image = b;
        calculer();
        invalidate();
    }

    Bitmap getImage() {
        return image;
    }

    int getMode() {
        return mode;
    }

    void setMode(int m) {
        mode = m;
        poignee = -1;
        coin = -1;
        enCours = null;
        if (m != TEXTE) {
            calques.clear();
            choisi = null;
        }
        if (m != DESSIN) traits.clear();
        if (image != null) {
            if (m == ROGNER) {
                ratio = 0;
                cadre.set(0, 0, image.getWidth(), image.getHeight());
            } else if (m == PERSPECTIVE) {
                float w = image.getWidth(), h = image.getHeight();
                float mx = w * 0.08f, my = h * 0.08f;
                float[] c = {mx, my, w - mx, my, w - mx, h - my, mx, h - my};
                System.arraycopy(c, 0, coins, 0, 8);
            }
        }
        invalidate();
    }

    void setApercu(ColorMatrix m, boolean vignette) {
        apercuCouleurs = m;
        apercuVignette = vignette;
        pImage.setColorFilter(m == null ? null : new ColorMatrixColorFilter(m));
        invalidate();
    }

    void setAngleApercu(float a, boolean avecGrille) {
        angleApercu = a;
        grille = avecGrille;
        invalidate();
    }

    void montrerAvant(boolean v) {
        montrerAvant = v;
        invalidate();
    }

    // ------------------------------------------------------------ Géométrie de l'affichage

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        calculer();
    }

    private void calculer() {
        versVue.reset();
        if (image == null || getWidth() == 0 || getHeight() == 0) return;
        float marge = 14 * d;
        float lw = getWidth() - 2 * marge, lh = getHeight() - 2 * marge;
        float s = Math.min(lw / image.getWidth(), lh / image.getHeight());
        float dx = (getWidth() - image.getWidth() * s) / 2f, dy = (getHeight() - image.getHeight() * s) / 2f;
        versVue.setScale(s, s);
        versVue.postTranslate(dx, dy);
        versVue.invert(versImage);
    }

    private float echelle() {
        float[] v = new float[9];
        versVue.getValues(v);
        return v[Matrix.MSCALE_X] == 0 ? 1 : v[Matrix.MSCALE_X];
    }

    private float[] enImage(float x, float y) {
        float[] pt = {x, y};
        versImage.mapPoints(pt);
        return pt;
    }

    /** Taille de référence de l'image (pour l'épaisseur des traits et la taille des textes). */
    float unite() {
        return image == null ? 1 : Math.max(image.getWidth(), image.getHeight()) / 1000f;
    }

    // ------------------------------------------------------------ Dessin

    @Override
    protected void onDraw(Canvas c) {
        if (image == null || image.isRecycled()) return;
        c.save();
        c.concat(versVue);
        if (!montrerAvant && angleApercu != 0) {
            float s = Retouches.echelleRedressement(image.getWidth(), image.getHeight(), angleApercu);
            c.save();
            c.clipRect(0, 0, image.getWidth(), image.getHeight());
            c.rotate(angleApercu, image.getWidth() / 2f, image.getHeight() / 2f);
            c.scale(s, s, image.getWidth() / 2f, image.getHeight() / 2f);
            c.drawBitmap(image, 0, 0, pImage);
            c.restore();
        } else {
            if (montrerAvant) {
                ColorMatrixColorFilter f = (ColorMatrixColorFilter) pImage.getColorFilter();
                pImage.setColorFilter(null);
                c.drawBitmap(image, 0, 0, pImage);
                pImage.setColorFilter(f);
            } else {
                c.drawBitmap(image, 0, 0, pImage);
            }
        }
        if (!montrerAvant && apercuVignette) Retouches.dessinerVignette(c, new RectF(0, 0, image.getWidth(), image.getHeight()));
        if (!montrerAvant) {
            for (Trait t : traits) dessinerTrait(c, t);
            for (Calque k : calques) dessinerCalque(c, k, pTexte);
        }
        c.restore();

        if (grille) dessinerGrille(c);
        if (mode == ROGNER) dessinerCadre(c);
        else if (mode == PERSPECTIVE) dessinerCoins(c);
        else if (mode == TEXTE && choisi != null && !montrerAvant) dessinerSelection(c);
    }

    private RectF rectVue() {
        RectF r = new RectF(0, 0, image.getWidth(), image.getHeight());
        versVue.mapRect(r);
        return r;
    }

    private void dessinerGrille(Canvas c) {
        RectF r = rectVue();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1, d * 0.8f));
        p.setColor(0x88FFFFFF);
        p.setPathEffect(null);
        for (int i = 1; i < 6; i++) {
            float x = r.left + r.width() * i / 6f, y = r.top + r.height() * i / 6f;
            c.drawLine(x, r.top, x, r.bottom, p);
            c.drawLine(r.left, y, r.right, y, p);
        }
    }

    private void dessinerCadre(Canvas c) {
        RectF r = new RectF(cadre);
        versVue.mapRect(r);
        RectF tout = rectVue();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xAA000000);
        c.drawRect(tout.left, tout.top, tout.right, r.top, p);
        c.drawRect(tout.left, r.bottom, tout.right, tout.bottom, p);
        c.drawRect(tout.left, r.top, r.left, r.bottom, p);
        c.drawRect(r.right, r.top, tout.right, r.bottom, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1, d));
        p.setColor(0x99FFFFFF);
        for (int i = 1; i < 3; i++) {
            float x = r.left + r.width() * i / 3f, y = r.top + r.height() * i / 3f;
            c.drawLine(x, r.top, x, r.bottom, p);
            c.drawLine(r.left, y, r.right, y, p);
        }
        p.setStrokeWidth(2 * d);
        p.setColor(0xFFFFFFFF);
        c.drawRect(r, p);
        p.setStrokeWidth(4 * d);
        p.setColor(accent);
        float l = 18 * d;
        float[][] angles = {{r.left, r.top, 1, 1}, {r.right, r.top, -1, 1}, {r.right, r.bottom, -1, -1}, {r.left, r.bottom, 1, -1}};
        for (float[] a : angles) {
            c.drawLine(a[0], a[1], a[0] + l * a[2], a[1], p);
            c.drawLine(a[0], a[1], a[0], a[1] + l * a[3], p);
        }
        // Petites poignées au milieu des côtés.
        p.setStrokeWidth(5 * d);
        c.drawLine(r.centerX() - 10 * d, r.top, r.centerX() + 10 * d, r.top, p);
        c.drawLine(r.centerX() - 10 * d, r.bottom, r.centerX() + 10 * d, r.bottom, p);
        c.drawLine(r.left, r.centerY() - 10 * d, r.left, r.centerY() + 10 * d, p);
        c.drawLine(r.right, r.centerY() - 10 * d, r.right, r.centerY() + 10 * d, p);
        // Dimensions.
        String dim = Math.round(cadre.width()) + " × " + Math.round(cadre.height());
        pTexte.setTypeface(Typeface.DEFAULT_BOLD);
        pTexte.setTextSize(12 * d);
        pTexte.setColor(0xFFFFFFFF);
        pTexte.setShadowLayer(3 * d, 0, 1, 0xCC000000);
        pTexte.setStyle(Paint.Style.FILL);
        pTexte.setTextAlign(Paint.Align.CENTER);
        c.drawText(dim, r.centerX(), r.centerY() + 4 * d, pTexte);
        pTexte.clearShadowLayer();
        pTexte.setTextAlign(Paint.Align.LEFT);
    }

    private void dessinerCoins(Canvas c) {
        float[] v = coins.clone();
        versVue.mapPoints(v);
        tmp.reset();
        tmp.moveTo(v[0], v[1]);
        tmp.lineTo(v[2], v[3]);
        tmp.lineTo(v[4], v[5]);
        tmp.lineTo(v[6], v[7]);
        tmp.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Visuel.alpha(accent, 50));
        c.drawPath(tmp, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f * d);
        p.setColor(accent);
        c.drawPath(tmp, p);
        for (int i = 0; i < 4; i++) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(v[i * 2], v[i * 2 + 1], 13 * d, p);
            p.setColor(accent);
            c.drawCircle(v[i * 2], v[i * 2 + 1], 8 * d, p);
        }
        if (coin >= 0) dessinerLoupe(c, v[coin * 2], v[coin * 2 + 1]);
    }

    /** Loupe ×2.5 au-dessus du doigt pour placer les coins au pixel près. */
    private void dessinerLoupe(Canvas c, float x, float y) {
        float r = 58 * d;
        float cx = x < getWidth() / 2f ? getWidth() - r - 12 * d : r + 12 * d;
        float cy = r + 12 * d;
        if (y < cy + r + 20 * d) cy = getHeight() - r - 12 * d;
        tmp.reset();
        tmp.addCircle(cx, cy, r, Path.Direction.CW);
        c.save();
        c.clipPath(tmp);
        c.drawColor(0xFF000000);
        float z = 2.5f;
        c.translate(cx - x * z, cy - y * z);
        c.scale(z, z);
        c.concat(versVue);
        c.drawBitmap(image, 0, 0, pImage);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * d);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r, p);
        p.setStrokeWidth(1.5f * d);
        p.setColor(accent);
        c.drawLine(cx - 12 * d, cy, cx + 12 * d, cy, p);
        c.drawLine(cx, cy - 12 * d, cx, cy + 12 * d, p);
    }

    static Typeface police(Calque k) {
        Typeface base;
        switch (k.police) {
            case 1:
                base = Typeface.SERIF;
                break;
            case 2:
                base = Typeface.MONOSPACE;
                break;
            case 3:
                base = Typeface.create("casual", Typeface.NORMAL);
                break;
            case 4:
                base = Typeface.create("sans-serif-condensed", Typeface.NORMAL);
                break;
            default:
                base = Typeface.SANS_SERIF;
        }
        return Typeface.create(base, k.gras ? Typeface.BOLD : Typeface.NORMAL);
    }

    /** Rectangle du texte, centré sur (0,0), avant rotation. */
    static RectF mesurer(Calque k, Paint pt) {
        pt.setTypeface(police(k));
        pt.setTextSize(k.taille);
        String[] lignes = k.texte.split("\n", -1);
        float lw = 0;
        for (String l : lignes) lw = Math.max(lw, pt.measureText(l));
        Paint.FontMetrics fm = pt.getFontMetrics();
        float lh = fm.descent - fm.ascent;
        float h = lh * lignes.length;
        float m = k.taille * 0.25f;
        return new RectF(-lw / 2 - m, -h / 2 - m * 0.6f, lw / 2 + m, h / 2 + m * 0.6f);
    }

    /** Dessine un calque de texte en coordonnées de l'image (sert à l'aperçu ET au résultat final). */
    static void dessinerCalque(Canvas c, Calque k, Paint pt) {
        if (k.texte == null || k.texte.isEmpty()) return;
        RectF r = mesurer(k, pt);
        c.save();
        c.translate(k.x, k.y);
        c.rotate(k.angle);
        if (k.fond != 0) {
            Paint pf = new Paint(Paint.ANTI_ALIAS_FLAG);
            pf.setColor(k.fond);
            c.drawRoundRect(r, k.taille * 0.25f, k.taille * 0.25f, pf);
        }
        String[] lignes = k.texte.split("\n", -1);
        Paint.FontMetrics fm = pt.getFontMetrics();
        float lh = fm.descent - fm.ascent;
        float y = -lh * lignes.length / 2f - fm.ascent;
        pt.setTextAlign(Paint.Align.CENTER);
        for (String l : lignes) {
            if (k.contour != 0) {
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeJoin(Paint.Join.ROUND);
                pt.setStrokeWidth(Math.max(2f, k.taille * 0.12f));
                pt.setColor(k.contour);
                if (k.ombre) pt.setShadowLayer(k.taille * 0.12f, k.taille * 0.04f, k.taille * 0.06f, 0x99000000);
                else pt.clearShadowLayer();
                c.drawText(l, 0, y, pt);
            }
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(k.couleur);
            if (k.ombre && k.contour == 0) pt.setShadowLayer(k.taille * 0.12f, k.taille * 0.04f, k.taille * 0.06f, 0xAA000000);
            else pt.clearShadowLayer();
            c.drawText(l, 0, y, pt);
            y += lh;
        }
        pt.clearShadowLayer();
        pt.setTextAlign(Paint.Align.LEFT);
        c.restore();
    }

    private void dessinerSelection(Canvas c) {
        RectF r = mesurer(choisi, pTexte);
        c.save();
        c.concat(versVue);
        c.translate(choisi.x, choisi.y);
        c.rotate(choisi.angle);
        float s = echelle();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * d / s);
        p.setColor(0xFFFFFFFF);
        p.setPathEffect(new DashPathEffect(new float[]{8 * d / s, 6 * d / s}, 0));
        c.drawRoundRect(r, 6 * d / s, 6 * d / s, p);
        p.setPathEffect(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(accent);
        c.drawCircle(r.right, r.bottom, 6 * d / s, p);
        c.restore();
    }

    static void dessinerTrait(Canvas c, Trait t) {
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
        pt.setColor(t.couleur);
        pt.setStrokeWidth(t.epaisseur);
        switch (t.outil) {
            case P_SURLIGNEUR:
                pt.setColor(Visuel.alpha(t.couleur, 110));
                pt.setStrokeCap(Paint.Cap.SQUARE);
                c.drawPath(t.chemin, pt);
                break;
            case P_LIGNE:
                c.drawLine(t.x1, t.y1, t.x2, t.y2, pt);
                break;
            case P_FLECHE: {
                c.drawLine(t.x1, t.y1, t.x2, t.y2, pt);
                double a = Math.atan2(t.y2 - t.y1, t.x2 - t.x1);
                float l = Math.max(t.epaisseur * 3.5f, 14);
                Path tete = new Path();
                tete.moveTo(t.x2, t.y2);
                tete.lineTo((float) (t.x2 - l * Math.cos(a - 0.45)), (float) (t.y2 - l * Math.sin(a - 0.45)));
                tete.moveTo(t.x2, t.y2);
                tete.lineTo((float) (t.x2 - l * Math.cos(a + 0.45)), (float) (t.y2 - l * Math.sin(a + 0.45)));
                c.drawPath(tete, pt);
                break;
            }
            case P_RECT:
                c.drawRect(Math.min(t.x1, t.x2), Math.min(t.y1, t.y2), Math.max(t.x1, t.x2), Math.max(t.y1, t.y2), pt);
                break;
            case P_CERCLE:
                c.drawOval(new RectF(Math.min(t.x1, t.x2), Math.min(t.y1, t.y2), Math.max(t.x1, t.x2), Math.max(t.y1, t.y2)), pt);
                break;
            default:
                c.drawPath(t.chemin, pt);
        }
    }

    // ------------------------------------------------------------ Rognage : proportions

    void setRatio(float r) {
        if (image == null) return;
        ratio = r;
        if (r <= 0) {
            invalidate();
            return;
        }
        float cx = cadre.centerX(), cy = cadre.centerY();
        float w = cadre.width(), h = cadre.height();
        if (w / h > r) w = h * r;
        else h = w / r;
        // Agrandir au maximum possible dans l'image en gardant la proportion.
        float maxW = image.getWidth(), maxH = image.getHeight();
        float fw = Math.min(maxW, maxH * r);
        float fh = fw / r;
        if (w < fw * 0.5f) {
            w = fw * 0.8f;
            h = fh * 0.8f;
        }
        cadre.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
        garderDansImage();
        invalidate();
    }

    void cadreToutRetablir() {
        if (image == null) return;
        ratio = 0;
        cadre.set(0, 0, image.getWidth(), image.getHeight());
        invalidate();
    }

    RectF getCadre() {
        return new RectF(cadre);
    }

    float[] getCoins() {
        return coins.clone();
    }

    private void garderDansImage() {
        float W = image.getWidth(), H = image.getHeight();
        if (cadre.width() > W) {
            float f = W / cadre.width();
            cadre.set(cadre.left, cadre.top, cadre.left + W, cadre.top + cadre.height() * f);
        }
        if (cadre.height() > H) {
            float f = H / cadre.height();
            cadre.set(cadre.left, cadre.top, cadre.left + cadre.width() * f, cadre.top + H);
        }
        if (cadre.left < 0) cadre.offset(-cadre.left, 0);
        if (cadre.top < 0) cadre.offset(0, -cadre.top);
        if (cadre.right > W) cadre.offset(W - cadre.right, 0);
        if (cadre.bottom > H) cadre.offset(0, H - cadre.bottom);
    }

    // ------------------------------------------------------------ Textes : API

    Calque ajouterTexte(String texte) {
        if (image == null) return null;
        Calque k = new Calque();
        k.texte = texte;
        k.x = image.getWidth() / 2f;
        k.y = image.getHeight() / 2f + calques.size() * unite() * 70;
        if (k.y > image.getHeight() * 0.9f) k.y = image.getHeight() / 2f;
        k.taille = unite() * 70;
        if (choisi != null) { // reprend le style du texte précédent
            k.couleur = choisi.couleur;
            k.police = choisi.police;
            k.gras = choisi.gras;
            k.contour = choisi.contour;
            k.ombre = choisi.ombre;
            k.fond = choisi.fond;
        }
        calques.add(k);
        choisir(k);
        return k;
    }

    Calque getChoisi() {
        return choisi;
    }

    void supprimerChoisi() {
        if (choisi == null) return;
        calques.remove(choisi);
        choisir(calques.isEmpty() ? null : calques.get(calques.size() - 1));
    }

    void rafraichir() {
        invalidate();
    }

    private void choisir(Calque k) {
        choisi = k;
        if (ecouteur != null) ecouteur.calqueChoisi(k);
        invalidate();
    }

    private Calque calqueSous(float ix, float iy) {
        for (int i = calques.size() - 1; i >= 0; i--) {
            Calque k = calques.get(i);
            RectF r = mesurer(k, pTexte);
            float marge = 14 * d / echelle();
            r.inset(-marge, -marge);
            double a = Math.toRadians(-k.angle);
            float dx = ix - k.x, dy = iy - k.y;
            float rx = (float) (dx * Math.cos(a) - dy * Math.sin(a));
            float ry = (float) (dx * Math.sin(a) + dy * Math.cos(a));
            if (r.contains(rx, ry)) return k;
        }
        return null;
    }

    // ------------------------------------------------------------ Dessin : API

    void annulerTrait() {
        if (!traits.isEmpty()) traits.remove(traits.size() - 1);
        if (ecouteur != null) ecouteur.dessinChange();
        invalidate();
    }

    // ------------------------------------------------------------ Toucher

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (image == null) return false;
        switch (mode) {
            case ROGNER:
                return toucherCadre(e);
            case PERSPECTIVE:
                return toucherCoins(e);
            case TEXTE:
                return toucherTexte(e);
            case DESSIN:
                return toucherDessin(e);
            default:
                return false;
        }
    }

    private boolean toucherCadre(MotionEvent e) {
        float[] pt = enImage(e.getX(), e.getY());
        float tol = 28 * d / echelle();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                boolean g = Math.abs(pt[0] - cadre.left) < tol, dr = Math.abs(pt[0] - cadre.right) < tol;
                boolean h = Math.abs(pt[1] - cadre.top) < tol, b = Math.abs(pt[1] - cadre.bottom) < tol;
                boolean dansX = pt[0] > cadre.left - tol && pt[0] < cadre.right + tol;
                boolean dansY = pt[1] > cadre.top - tol && pt[1] < cadre.bottom + tol;
                poignee = -1;
                if (g && h) poignee = 0;
                else if (dr && h) poignee = 1;
                else if (dr && b) poignee = 2;
                else if (g && b) poignee = 3;
                else if (h && dansX) poignee = 4;
                else if (dr && dansY) poignee = 5;
                else if (b && dansX) poignee = 6;
                else if (g && dansY) poignee = 7;
                else if (cadre.contains(pt[0], pt[1])) poignee = 8;
                dX = pt[0];
                dY = pt[1];
                cadreDepart.set(cadre);
                if (poignee >= 0) getParent().requestDisallowInterceptTouchEvent(true);
                return poignee >= 0;
            }
            case MotionEvent.ACTION_MOVE: {
                if (poignee < 0) return false;
                float mx = pt[0] - dX, my = pt[1] - dY;
                RectF r = new RectF(cadreDepart);
                float min = Math.max(24, Math.min(image.getWidth(), image.getHeight()) * 0.04f);
                float W = image.getWidth(), H = image.getHeight();
                if (poignee == 8) {
                    r.offset(mx, my);
                    cadre.set(r);
                    garderDansImage();
                } else {
                    if (poignee == 0 || poignee == 3 || poignee == 7) r.left = Math.max(0, Math.min(r.right - min, r.left + mx));
                    if (poignee == 1 || poignee == 2 || poignee == 5) r.right = Math.min(W, Math.max(r.left + min, r.right + mx));
                    if (poignee == 0 || poignee == 1 || poignee == 4) r.top = Math.max(0, Math.min(r.bottom - min, r.top + my));
                    if (poignee == 2 || poignee == 3 || poignee == 6) r.bottom = Math.min(H, Math.max(r.top + min, r.bottom + my));
                    if (ratio > 0) appliquerRatio(r, poignee);
                    cadre.set(r);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                poignee = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    /** Garde la proportion choisie en ajustant le côté opposé à la poignée tirée. */
    private void appliquerRatio(RectF r, int pg) {
        float W = image.getWidth(), H = image.getHeight();
        boolean horiz = pg == 5 || pg == 7;
        float w = r.width(), h = r.height();
        if (horiz) h = w / ratio;
        else if (pg == 4 || pg == 6) w = h * ratio;
        else if (w / h > ratio) w = h * ratio;
        else h = w / ratio;
        // Limites de l'image.
        float maxW = (pg == 0 || pg == 3 || pg == 7) ? r.right : W - r.left;
        float maxH = (pg == 0 || pg == 1 || pg == 4) ? r.bottom : H - r.top;
        if (pg == 4 || pg == 6) maxW = W;
        if (pg == 5 || pg == 7) maxH = H;
        if (w > maxW) {
            w = maxW;
            h = w / ratio;
        }
        if (h > maxH) {
            h = maxH;
            w = h * ratio;
        }
        if (pg == 0 || pg == 3 || pg == 7) r.left = r.right - w;
        else if (pg == 4 || pg == 6) {
            float cx = r.centerX();
            r.left = cx - w / 2;
            r.right = cx + w / 2;
        } else r.right = r.left + w;
        if (pg == 0 || pg == 1 || pg == 4) r.top = r.bottom - h;
        else if (pg == 5 || pg == 7) {
            float cy = r.centerY();
            r.top = cy - h / 2;
            r.bottom = cy + h / 2;
        } else r.bottom = r.top + h;
        if (r.left < 0) r.offset(-r.left, 0);
        if (r.top < 0) r.offset(0, -r.top);
        if (r.right > W) r.offset(W - r.right, 0);
        if (r.bottom > H) r.offset(0, H - r.bottom);
    }

    private boolean toucherCoins(MotionEvent e) {
        float[] pt = enImage(e.getX(), e.getY());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                coin = -1;
                float best = 40 * d / echelle();
                for (int i = 0; i < 4; i++) {
                    float dd = (float) Math.hypot(pt[0] - coins[i * 2], pt[1] - coins[i * 2 + 1]);
                    if (dd < best) {
                        best = dd;
                        coin = i;
                    }
                }
                if (coin >= 0) {
                    doigtX = pt[0] - coins[coin * 2];
                    doigtY = pt[1] - coins[coin * 2 + 1];
                    getParent().requestDisallowInterceptTouchEvent(true);
                    invalidate();
                }
                return coin >= 0;
            }
            case MotionEvent.ACTION_MOVE:
                if (coin < 0) return false;
                coins[coin * 2] = Math.max(0, Math.min(image.getWidth(), pt[0] - doigtX));
                coins[coin * 2 + 1] = Math.max(0, Math.min(image.getHeight(), pt[1] - doigtY));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                coin = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private boolean toucherTexte(MotionEvent e) {
        float[] pt = enImage(e.getX(), e.getY());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                Calque k = calqueSous(pt[0], pt[1]);
                deplace = false;
                if (k != null) {
                    long t = e.getEventTime();
                    boolean doubleTap = k == choisi && t - dernierTap < 320;
                    dernierTap = t;
                    if (k != choisi) choisir(k);
                    if (doubleTap && ecouteur != null) {
                        ecouteur.modifierCalque(k);
                        return true;
                    }
                    dX = pt[0] - k.x;
                    dY = pt[1] - k.y;
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else if (choisi != null) {
                    choisir(null);
                }
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (choisi != null && e.getPointerCount() == 2) {
                    dist0 = ecart(e);
                    angle0 = angle(e);
                    taille0 = choisi.taille;
                    angleCalque0 = choisi.angle;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (choisi == null) return true;
                if (e.getPointerCount() >= 2 && dist0 > 0) {
                    float f = ecart(e) / dist0;
                    choisi.taille = Math.max(unite() * 12, Math.min(unite() * 600, taille0 * f));
                    float a = angleCalque0 + (angle(e) - angle0);
                    // Petit aimant vers l'horizontale et la verticale.
                    float mod = ((a % 90) + 90) % 90;
                    if (mod < 3) a -= mod;
                    else if (mod > 87) a += 90 - mod;
                    choisi.angle = a;
                    deplace = true;
                } else if (e.getPointerCount() == 1) {
                    choisi.x = Math.max(0, Math.min(image.getWidth(), pt[0] - dX));
                    choisi.y = Math.max(0, Math.min(image.getHeight(), pt[1] - dY));
                    deplace = true;
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                dist0 = 0;
                // Reprendre le déplacement avec le doigt restant sans saut.
                int reste = e.getActionIndex() == 0 ? 1 : 0;
                if (choisi != null) {
                    float[] q = enImage(e.getX(reste), e.getY(reste));
                    dX = q[0] - choisi.x;
                    dY = q[1] - choisi.y;
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dist0 = 0;
                if (deplace && ecouteur != null) ecouteur.calqueChoisi(choisi);
                return true;
            default:
                return true;
        }
    }

    private static float ecart(MotionEvent e) {
        return (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
    }

    private static float angle(MotionEvent e) {
        return (float) Math.toDegrees(Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)));
    }

    private boolean toucherDessin(MotionEvent e) {
        float[] pt = enImage(e.getX(), e.getY());
        float x = Math.max(0, Math.min(image.getWidth(), pt[0]));
        float y = Math.max(0, Math.min(image.getHeight(), pt[1]));
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                enCours = new Trait();
                enCours.outil = outil;
                enCours.couleur = couleurDessin;
                enCours.epaisseur = Math.max(1f, epaisseurDessin * unite() * (outil == P_SURLIGNEUR ? 3f : 1f));
                enCours.chemin.moveTo(x, y);
                enCours.x1 = enCours.x2 = x;
                enCours.y1 = enCours.y2 = y;
                traits.add(enCours);
                getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (enCours == null) return true;
                if (e.getPointerCount() > 1) return true;
                for (int i = 0; i < e.getHistorySize(); i++) {
                    float[] h = enImage(e.getHistoricalX(i), e.getHistoricalY(i));
                    enCours.chemin.lineTo(Math.max(0, Math.min(image.getWidth(), h[0])), Math.max(0, Math.min(image.getHeight(), h[1])));
                }
                enCours.chemin.lineTo(x, y);
                enCours.x2 = x;
                enCours.y2 = y;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (enCours != null) {
                    boolean point = Math.hypot(enCours.x2 - enCours.x1, enCours.y2 - enCours.y1) < 2;
                    if (point && (outil == P_PINCEAU || outil == P_SURLIGNEUR)) {
                        enCours.chemin.lineTo(x + 0.5f, y + 0.5f); // un simple toucher fait un point
                    } else if (point) {
                        traits.remove(enCours); // forme vide : on l'ignore
                    }
                }
                enCours = null;
                if (ecouteur != null) ecouteur.dessinChange();
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (enCours != null) traits.remove(enCours);
                enCours = null;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
