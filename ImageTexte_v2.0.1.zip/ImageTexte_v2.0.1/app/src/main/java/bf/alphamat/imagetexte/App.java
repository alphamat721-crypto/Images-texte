package bf.alphamat.imagetexte;

import android.app.Application;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Application : version affichée et file de travail en arrière-plan partagée. */
public class App extends Application {

    private static ExecutorService travail;

    static String version() {
        String v = BuildConfig.VERSION_NAME;
        return v == null ? "" : v;
    }

    /** Un seul fil pour les traitements lourds : évite de saturer la mémoire sur les petits téléphones. */
    static synchronized ExecutorService travail() {
        if (travail == null || travail.isShutdown()) travail = Executors.newSingleThreadExecutor();
        return travail;
    }
}
