package bf.alphamat.imagetexte;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Petits outils d'interface communs. */
final class Ui {

    interface SurBool {
        void v(boolean b);
    }

    interface SurInt {
        void v(int i);
    }

    private Ui() {
    }

    static int dp(Context c, float v) {
        return Visuel.dp(c, v);
    }

    static TextView texte(Context c, CharSequence s, float sp, int couleur, boolean gras) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(couleur);
        if (gras) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    static LinearLayout colonne(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout ligne(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpMarges(Context c, int w, int h, float g, float hDp, float d, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, g), dp(c, hDp), dp(c, d), dp(c, b));
        return p;
    }

    static LinearLayout.LayoutParams lpPoids(float poids) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, poids);
    }

    /** Bouton en relief avec petit effet d'enfoncement. */
    static TextView bouton(Context c, String s, int couleur, int couleurTexte) {
        TextView b = texte(c, s, 15, couleurTexte, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Visuel.bouton3D(c, couleur, 16));
        b.setPadding(dp(c, 16), dp(c, 11), dp(c, 16), dp(c, 15));
        b.setClickable(true);
        b.setFocusable(true);
        pression(b);
        return b;
    }

    @SuppressLint("ClickableViewAccessibility")
    static void pression(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
                } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(160).start();
                }
                return false;
            }
        });
    }

    static AlertDialog.Builder dialogue(Context c, Visuel.Theme t) {
        return new AlertDialog.Builder(c, t.sombre ? android.R.style.Theme_Material_Dialog_Alert
                : android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    static void ouvrirLien(Context c, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast(c, "Aucune appli pour ouvrir ce lien.");
        }
    }

    private static final String WA = "https://wa.me/22677769765?text=";

    private static String demande(String nom) {
        return WA + Uri.encode("Bonjour, je souhaite l'application " + nom);
    }

    /**
     * Toutes les applis et logiciels d'Alphamat : {catégorie} ou {emoji, nom, description, lien}.
     * Les applis Android se demandent sur WhatsApp (dépôts privés) ; les applis web s'ouvrent directement.
     */
    static final String[][] AUTRES_APPLIS = {
            {"🌐 Applis web — gratuites, s'ouvrent tout de suite"},
            {"🎯", "BINGO", "Jeu d'énigmes et classement", "https://bingoz.pages.dev/"},
            {"😂", "MatStoriesLab", "Histoires drôles à partager sur Facebook et WhatsApp", "https://matstorieslab.pages.dev/"},
            {"🇧🇫", "Faso Tiim", "Pharmacies de garde", "https://fasotiim.pages.dev/"},
            {"🛒", "SuguRaaga", "Marché en ligne : acheteurs et vendeurs", "https://suguraga.pages.dev/"},
            {"🔎", "Retour", "Recherche inversée d'images, vidéos et textes", "https://retour.pages.dev/"},
            {"📱 Applis Android — à demander sur WhatsApp"},
            {"📸", "CaptureGest", "Captures d'écran : bulle flottante, gestes, rognage", demande("CaptureGest")},
            {"🎵", "Sonorix", "Lecteur de musique 3D, égaliseur, bass booster, visualiseurs", demande("Sonorix")},
            {"🔄", "Files Converter", "Convertisseur vidéo, audio, images et documents", demande("Files Converter")},
            {"📞", "Appelo+", "Appels et SMS avec sauvegarde automatique", demande("Appelo+")},
            {"💾", "StatuBox", "Sauvegarde des statuts WhatsApp et stickers", demande("StatuBox")},
            {"⌨️", "Clavier Chic", "Clavier élégant à thèmes 3D, suggestions, emojis", demande("Clavier Chic")},
            {"🎙", "Enregistreur d'appels", "Enregistre vos conversations téléphoniques", demande("Enregistreur d'appels")},
            {"🎈", "Bloc Bulles", "Jeu de bulles et de blocs, 100 niveaux", demande("Bloc Bulles")},
            {"➕", "Calcul Malin", "Jeux de calcul pour enfants", demande("Calcul Malin")},
            {"🔤", "Mots Malins", "Jeux de lecture et de mots pour enfants", demande("Mots Malins")},
            {"🧠", "Petit Génie", "Mémoire, logique et éveil pour enfants", demande("Petit Génie")},
            {"📲", "BINGO, MatStoriesLab, Faso Tiim, SuguRaaga, Retour", "Aussi en applis Android, utilisables sans Internet", demande("(version Android de mes applis web)")},
            {"💻 Logiciels Windows"},
            {"💼", "Baara", "Logiciel de gestion", WA + Uri.encode("Bonjour, je souhaite le logiciel Baara")},
            {"🏥", "Lognafa", "Gestion hospitalière intégrée", WA + Uri.encode("Bonjour, je souhaite le logiciel Lognafa")},
            {"✉️ Contact"},
            {"💬", "WhatsApp", "+226 77 76 97 65", WA + Uri.encode("Bonjour, je vous contacte depuis Image Texte")},
            {"✉️", "E-mail", "alphamat721@gmail.com", "mailto:alphamat721@gmail.com?subject=Vos%20applis%20et%20logiciels"},
    };

    static void autresApplis(final Activity a, Visuel.Theme t) {
        final android.app.AlertDialog[] boite = new android.app.AlertDialog[1];
        int texte = t.sombre ? 0xFFFFFFFF : 0xFF1C1C22;
        int doux = t.sombre ? 0xB3FFFFFF : 0xFF5A5A66;
        LinearLayout col = colonne(a);
        col.setPadding(dp(a, 18), dp(a, 4), dp(a, 18), dp(a, 8));
        for (final String[] l : AUTRES_APPLIS) {
            if (l.length == 1) {
                TextView cat = texte(a, l[0], 14, t.accent, true);
                cat.setPadding(0, dp(a, 14), 0, dp(a, 4));
                col.addView(cat);
                continue;
            }
            LinearLayout ligne = ligne(a);
            ligne.setPadding(dp(a, 6), dp(a, 8), dp(a, 6), dp(a, 8));
            ligne.setBackground(Visuel.puce(a, t, false));
            TextView em = texte(a, l[0], 20, texte, false);
            em.setGravity(Gravity.CENTER);
            ligne.addView(em, lp(dp(a, 38), -2));
            LinearLayout tx = colonne(a);
            tx.addView(texte(a, l[1], 15, texte, true));
            tx.addView(texte(a, l[2], 12.5f, doux, false));
            ligne.addView(tx, lpPoids(1));
            ligne.addView(texte(a, "›", 20, t.accent, true));
            ligne.setClickable(true);
            ligne.setOnClickListener(v -> {
                if (boite[0] != null) boite[0].dismiss();
                ouvrirLien(a, l[3]);
            });
            pression(ligne);
            LinearLayout.LayoutParams lpL = lp(-1, -2);
            lpL.setMargins(0, dp(a, 3), 0, dp(a, 3));
            col.addView(ligne, lpL);
        }
        boite[0] = dialogue(a, t).setTitle("Mes autres applis et logiciels")
                .setView(defilement(a, col))
                .setNegativeButton("Fermer", null)
                .show();
    }

    static ScrollView defilement(Context c, View contenu) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setVerticalScrollBarEnabled(false);
        s.addView(contenu);
        return s;
    }

    static void toast(Context c, String s) {
        try {
            Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_LONG).show();
        } catch (Exception ignore) {
        }
    }

    static void toastCourt(Context c, String s) {
        try {
            Toast.makeText(c.getApplicationContext(), s, Toast.LENGTH_SHORT).show();
        } catch (Exception ignore) {
        }
    }

    static String taille(long o) {
        if (o <= 0) return "—";
        if (o < 1024) return o + " o";
        if (o < 1024 * 1024) return Math.round(o / 1024.0) + " Ko";
        return String.format(Locale.FRANCE, "%.1f Mo", o / (1024.0 * 1024.0));
    }

    static String date(long ms) {
        return new SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", Locale.FRANCE).format(new Date(ms));
    }

    static String heure(long ms) {
        return new SimpleDateFormat("HH:mm", Locale.FRANCE).format(new Date(ms));
    }

}
