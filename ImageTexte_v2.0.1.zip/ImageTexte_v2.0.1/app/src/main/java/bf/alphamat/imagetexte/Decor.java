package bf.alphamat.imagetexte;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Fond illustré du thème : dégradé + décor en relief (sphères, vagues, cristaux, rayons, bulles), animé doucement. */
class Decor extends View {

    private Visuel.Theme t;
    private final Paint fond = new Paint();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path chemin = new Path();
    private ValueAnimator anim;
    private float phase;
    private final boolean anime;

    Decor(Context c, Visuel.Theme t) {
        this(c, t, !BuildConfig.LITE);
    }

    Decor(Context c, Visuel.Theme t, boolean anime) {
        super(c);
        this.t = t;
        this.anime = anime;
    }

    void setTheme(Visuel.Theme t) {
        this.t = t;
        fond.setShader(null);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        fond.setShader(null);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!anime) return;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(24000);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                phase = (float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        anim = null;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int v) {
        super.onWindowVisibilityChanged(v);
        if (anim == null) return;
        if (v == VISIBLE) {
            if (anim.isPaused()) anim.resume();
        } else if (anim.isRunning()) {
            anim.pause();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        if (fond.getShader() == null) {
            fond.setShader(new LinearGradient(0, 0, w * 0.35f, h, t.haut, t.bas, Shader.TileMode.CLAMP));
        }
        c.drawRect(0, 0, w, h, fond);
        double a = phase * Math.PI * 2;
        switch (t.decor) {
            case Visuel.DECOR_VAGUES:
                vagues(c, w, h, a);
                break;
            case Visuel.DECOR_CRISTAUX:
                cristaux(c, w, h, a);
                break;
            case Visuel.DECOR_RAYONS:
                rayons(c, w, h, a);
                break;
            case Visuel.DECOR_BULLES:
                bulles(c, w, h, a);
                break;
            default:
                orbes(c, w, h, a);
        }
    }

    /** Sphère de verre : dégradé radial décalé vers le haut-gauche + petit éclat. */
    private void sphere(Canvas c, float x, float y, float r, int couleur, int alphaMax) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(x - r * 0.35f, y - r * 0.4f, r * 1.35f,
                new int[]{Visuel.alpha(Visuel.clair(couleur, 0.55f), alphaMax), Visuel.alpha(couleur, alphaMax * 2 / 3),
                        Visuel.alpha(Visuel.sombre(couleur, 0.4f), alphaMax / 4)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
        p.setColor(Visuel.alpha(0xFFFFFFFF, alphaMax));
        c.drawOval(x - r * 0.55f, y - r * 0.68f, x - r * 0.05f, y - r * 0.38f, p);
    }

    private void orbes(Canvas c, int w, int h, double a) {
        float u = Math.min(w, h);
        sphere(c, w * 0.85f + (float) Math.sin(a) * u * 0.03f, h * 0.10f + (float) Math.cos(a) * u * 0.02f, u * 0.22f, t.accent, 90);
        sphere(c, w * 0.08f + (float) Math.cos(a * 2) * u * 0.02f, h * 0.42f, u * 0.13f, t.accent2, 80);
        sphere(c, w * 0.70f, h * 0.78f + (float) Math.sin(a + 1) * u * 0.04f, u * 0.17f, t.accent2, 60);
        sphere(c, w * 0.30f + (float) Math.sin(a * 3) * u * 0.02f, h * 0.93f, u * 0.09f, t.accent, 70);
        sphere(c, w * 0.45f, h * 0.22f + (float) Math.cos(a * 2) * u * 0.03f, u * 0.045f, 0xFFFFFFFF, 50);
    }

    private void vagues(Canvas c, int w, int h, double a) {
        p.setStyle(Paint.Style.FILL);
        for (int k = 0; k < 4; k++) {
            float base = h * (0.70f + k * 0.08f);
            float amp = h * 0.025f * (1 + k * 0.3f);
            chemin.reset();
            chemin.moveTo(0, h);
            for (int x = 0; x <= w; x += Math.max(8, w / 40)) {
                double y = base + Math.sin(x * 2 * Math.PI / (w * (0.9 + k * 0.25)) + a * (k % 2 == 0 ? 1 : -1) + k) * amp;
                chemin.lineTo(x, (float) y);
            }
            chemin.lineTo(w, h);
            chemin.close();
            int col = k % 2 == 0 ? t.accent : t.accent2;
            p.setShader(new LinearGradient(0, base - amp, 0, h,
                    Visuel.alpha(Visuel.clair(col, 0.4f), 70 - k * 8), Visuel.alpha(col, 30), Shader.TileMode.CLAMP));
            c.drawPath(chemin, p);
        }
        p.setShader(null);
        sphere(c, w * 0.85f, h * 0.12f, Math.min(w, h) * 0.14f, t.accent2, 55);
    }

    private void cristal(Canvas c, float x, float y, float r, double rot, int couleur, int al) {
        p.setStyle(Paint.Style.FILL);
        float[][] faces = {{0, -1, 0.6f, -0.2f, 0, 0.2f}, {0, -1, -0.6f, -0.2f, 0, 0.2f},
                {0.6f, -0.2f, 0, 1, 0, 0.2f}, {-0.6f, -0.2f, 0, 1, 0, 0.2f}};
        int[] teintes = {Visuel.clair(couleur, 0.55f), Visuel.clair(couleur, 0.2f), couleur, Visuel.sombre(couleur, 0.35f)};
        double cs = Math.cos(rot), sn = Math.sin(rot);
        for (int f = 0; f < faces.length; f++) {
            chemin.reset();
            for (int k = 0; k < 6; k += 2) {
                float px = faces[f][k] * r, py = faces[f][k + 1] * r;
                float rx = (float) (px * cs - py * sn) + x, ry = (float) (px * sn + py * cs) + y;
                if (k == 0) chemin.moveTo(rx, ry);
                else chemin.lineTo(rx, ry);
            }
            chemin.close();
            p.setShader(null);
            p.setColor(Visuel.alpha(teintes[f], al));
            c.drawPath(chemin, p);
        }
    }

    private void cristaux(Canvas c, int w, int h, double a) {
        float u = Math.min(w, h);
        cristal(c, w * 0.84f, h * 0.12f, u * 0.20f, Math.sin(a) * 0.25 + 0.3, t.accent, 110);
        cristal(c, w * 0.12f, h * 0.48f, u * 0.12f, Math.cos(a) * 0.3 - 0.4, t.accent2, 90);
        cristal(c, w * 0.75f, h * 0.84f, u * 0.15f, Math.sin(a * 2) * 0.2 + 0.9, t.accent, 80);
        cristal(c, w * 0.32f, h * 0.95f, u * 0.08f, Math.cos(a * 2) * 0.4, t.accent2, 90);
    }

    private void rayons(Canvas c, int w, int h, double a) {
        float cx = w * 0.92f, cy = h * 0.04f, R = Math.max(w, h) * 1.2f;
        p.setStyle(Paint.Style.FILL);
        for (int k = 0; k < 9; k++) {
            double ang = Math.PI * 0.5 + k * 0.16 + Math.sin(a + k) * 0.015;
            chemin.reset();
            chemin.moveTo(cx, cy);
            chemin.lineTo(cx + (float) Math.cos(ang - 0.035) * R, cy + (float) Math.sin(ang - 0.035) * R);
            chemin.lineTo(cx + (float) Math.cos(ang + 0.035) * R, cy + (float) Math.sin(ang + 0.035) * R);
            chemin.close();
            p.setShader(new RadialGradient(cx, cy, R * 0.8f, Visuel.alpha(t.accent, 60), Visuel.alpha(t.accent, 0), Shader.TileMode.CLAMP));
            c.drawPath(chemin, p);
        }
        p.setShader(null);
        sphere(c, cx, cy, Math.min(w, h) * 0.16f, t.accent, 120);
        for (int k = 0; k < 14; k++) {
            float sx = (float) ((k * 0.137 + 0.05) % 1.0) * w;
            float sy = (float) ((k * 0.291 + 0.2) % 1.0) * h;
            float sc = (float) (0.5 + 0.5 * Math.sin(a * 3 + k));
            p.setColor(Visuel.alpha(t.accent2, (int) (40 + 120 * sc)));
            float r = Visuel.dp(getContext(), 1.2f + 1.6f * sc);
            c.drawCircle(sx, sy, r, p);
        }
    }

    private void bulles(Canvas c, int w, int h, double a) {
        float u = Math.min(w, h);
        for (int k = 0; k < 9; k++) {
            float prog = (float) ((phase + k * 0.113) % 1.0);
            float x = (float) ((k * 0.173 + 0.07) % 1.0) * w + (float) Math.sin(a * 2 + k) * u * 0.02f;
            float y = h * (1.05f - prog * 1.15f);
            float r = u * (0.025f + (k % 4) * 0.018f);
            sphere(c, x, y, r, k % 2 == 0 ? t.accent2 : t.accent, 70);
        }
        sphere(c, w * 0.88f, h * 0.10f, u * 0.18f, t.accent, 60);
    }
}
