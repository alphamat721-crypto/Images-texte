package bf.alphamat.imagetexte;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.View;
import android.view.Window;

/** Thèmes 3D (couleurs + décor + matières) et fabrication des surfaces en relief. */
final class Visuel {

    static final int DECOR_ORBES = 0;
    static final int DECOR_VAGUES = 1;
    static final int DECOR_CRISTAUX = 2;
    static final int DECOR_RAYONS = 3;
    static final int DECOR_BULLES = 4;

    static final class Theme {
        final String nom;
        final String ambiance;
        final int haut, bas, accent, accent2, carte, bord, texte, texteDoux, decor;
        final boolean sombre;

        Theme(String nom, String ambiance, int haut, int bas, int accent, int accent2, int carte, int bord,
              int texte, int texteDoux, int decor, boolean sombre) {
            this.nom = nom;
            this.ambiance = ambiance;
            this.haut = haut;
            this.bas = bas;
            this.accent = accent;
            this.accent2 = accent2;
            this.carte = carte;
            this.bord = bord;
            this.texte = texte;
            this.texteDoux = texteDoux;
            this.decor = decor;
            this.sombre = sombre;
        }
    }

    static final Theme[] THEMES = {
            new Theme("Saphir nocturne", "Sphères de verre flottant dans la nuit",
                    0xFF0A1030, 0xFF1C2A70, 0xFF4F8BFF, 0xFFA77BFF, 0xFF1A2558, 0x55FFFFFF,
                    0xFFFFFFFF, 0xB3D6DEFF, DECOR_ORBES, true),
            new Theme("Perle d'aurore", "Vagues nacrées et lumière du matin",
                    0xFFF8F4FF, 0xFFDDE7FF, 0xFF5B5BD6, 0xFFE0609F, 0xFFFFFFFF, 0x33303070,
                    0xFF1D1B3A, 0xFF5C5A7A, DECOR_VAGUES, false),
            new Theme("Émeraude royale", "Cristaux taillés aux reflets d'or",
                    0xFF03201A, 0xFF0B4A3B, 0xFF2ED3A0, 0xFFE9C46A, 0xFF0F3A30, 0x55B8FFE6,
                    0xFFF2FFF9, 0xB3BFEBDD, DECOR_CRISTAUX, true),
            new Theme("Ébène & or", "Rayons dorés sur laque noire",
                    0xFF0D0C0A, 0xFF2A2419, 0xFFE8B84A, 0xFFFFE7A3, 0xFF221E16, 0x66E8B84A,
                    0xFFFFF8E6, 0xB3E9DDBE, DECOR_RAYONS, true),
            new Theme("Corail tropical", "Bulles de lagon et soleil couchant",
                    0xFFFFF3EA, 0xFFFFD3C2, 0xFFFF6B4A, 0xFF1FB5A6, 0xFFFFFFFF, 0x33FF6B4A,
                    0xFF3A1E16, 0xFF7A5A50, DECOR_BULLES, false),
    };

    private Visuel() {
    }

    static Theme theme(Context c) {
        int i = Prefs.i(c, Prefs.THEME, 0);
        if (i < 0 || i >= THEMES.length) i = 0;
        return THEMES[i];
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int couleur, int a) {
        return (couleur & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    static int melange(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a), aa = Color.alpha(a);
        return Color.argb(Math.round(aa + (Color.alpha(b) - aa) * t),
                Math.round(ar + (Color.red(b) - ar) * t),
                Math.round(ag + (Color.green(b) - ag) * t),
                Math.round(ab + (Color.blue(b) - ab) * t));
    }

    static int clair(int c, float t) {
        return melange(c, 0xFFFFFFFF | (c & 0xFF000000), t);
    }

    static int sombre(int c, float t) {
        return melange(c, 0xFF000000 | (c & 0xFF000000), t);
    }

    /** Carte en relief : ombre portée, corps bombé (dégradé), liseré et reflet brillant en haut. */
    static Drawable carte3D(Context c, Theme t, float rayonDp) {
        float r = dp(c, rayonDp);
        int o = dp(c, 3);

        GradientDrawable ombre = new GradientDrawable();
        ombre.setCornerRadius(r);
        ombre.setColor(t.sombre ? 0x66000000 : 0x22301848);

        GradientDrawable corps = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{clair(t.carte, t.sombre ? 0.10f : 0.0f), t.carte, sombre(t.carte, t.sombre ? 0.18f : 0.04f)});
        corps.setCornerRadius(r);
        corps.setStroke(Math.max(1, dp(c, 1)), t.bord);

        GradientDrawable reflet = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{t.sombre ? 0x26FFFFFF : 0x80FFFFFF, 0x00FFFFFF});
        reflet.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});

        LayerDrawable ld = new LayerDrawable(new Drawable[]{ombre, corps, reflet});
        ld.setLayerInset(0, 0, o, 0, 0);
        ld.setLayerInset(1, 0, 0, 0, o);
        ld.setLayerInset(2, dp(c, 1), dp(c, 1), dp(c, 1), dp(c, 28));
        return ld;
    }

    /** Bouton en relief (enfoncé quand on appuie). */
    static Drawable bouton3D(Context c, int couleur, float rayonDp) {
        return new StateListDrawable() {
            {
                addState(new int[]{android.R.attr.state_pressed}, surface(c, couleur, rayonDp, true));
                addState(new int[]{-android.R.attr.state_enabled}, surface(c, melange(couleur, 0xFF808080, 0.6f), rayonDp, false));
                addState(new int[]{}, surface(c, couleur, rayonDp, false));
            }
        };
    }

    private static Drawable surface(Context c, int couleur, float rayonDp, boolean presse) {
        float r = dp(c, rayonDp);
        int o = dp(c, presse ? 1 : 4);
        GradientDrawable ombre = new GradientDrawable();
        ombre.setCornerRadius(r);
        ombre.setColor(sombre(couleur, 0.55f));
        GradientDrawable corps = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                presse ? new int[]{sombre(couleur, 0.12f), couleur}
                        : new int[]{clair(couleur, 0.28f), couleur, sombre(couleur, 0.10f)});
        corps.setCornerRadius(r);
        corps.setStroke(Math.max(1, dp(c, 1)), clair(couleur, 0.35f));
        GradientDrawable reflet = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{presse ? 0x18FFFFFF : 0x50FFFFFF, 0x00FFFFFF});
        reflet.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        LayerDrawable ld = new LayerDrawable(new Drawable[]{ombre, corps, reflet});
        int dec = presse ? dp(c, 3) : 0;
        ld.setLayerInset(0, 0, dp(c, 4), 0, 0);
        ld.setLayerInset(1, 0, dec, 0, o);
        ld.setLayerInset(2, dp(c, 2), dec + dp(c, 2), dp(c, 2), dp(c, 18));
        return ld;
    }

    /** Pastille (puce) : pleine si active, en verre si inactive. */
    static Drawable puce(Context c, Theme t, boolean active) {
        float r = dp(c, 16);
        GradientDrawable g;
        if (active) {
            g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{clair(t.accent, 0.25f), t.accent, sombre(t.accent, 0.12f)});
            g.setStroke(Math.max(1, dp(c, 1)), clair(t.accent, 0.4f));
        } else {
            g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{t.sombre ? 0x22FFFFFF : 0xCCFFFFFF, t.sombre ? 0x10FFFFFF : 0x99FFFFFF});
            g.setStroke(Math.max(1, dp(c, 1)), t.bord);
        }
        g.setCornerRadius(r);
        return g;
    }

    static void barres(Activity a, Theme t) {
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(t.haut);
            w.setNavigationBarColor(t.bas);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            View d = w.getDecorView();
            int f = d.getSystemUiVisibility();
            if (!t.sombre) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                if (!t.sombre) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            d.setSystemUiVisibility(f);
        }
    }
}
