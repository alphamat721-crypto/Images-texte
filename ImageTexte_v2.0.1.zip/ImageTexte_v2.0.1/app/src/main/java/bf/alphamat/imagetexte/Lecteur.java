package bf.alphamat.imagetexte;

import android.content.Context;
import android.graphics.Bitmap;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.concurrent.TimeUnit;

/**
 * Lecture du texte d'une image, entièrement sur le téléphone (aucun envoi sur Internet).
 * Alphabet latin : français, anglais, mooré/dioula écrits en lettres latines, etc.
 * Toutes les méthodes sont bloquantes : à appeler hors du fil principal.
 */
final class Lecteur {

    private Lecteur() {
    }

    static String lire(Context c, String source, boolean ameliorer, boolean paragraphes) throws Exception {
        Bitmap b = Images.charger(c, source, Prefs.coteLecture());
        try {
            return lire(b, ameliorer, paragraphes);
        } finally {
            b.recycle();
        }
    }

    static String lire(Bitmap b, boolean ameliorer, boolean paragraphes) throws Exception {
        Bitmap aLire = b;
        if (ameliorer) {
            try {
                aLire = Retouches.niveauxAuto(b, true);
            } catch (OutOfMemoryError e) {
                aLire = b;
            }
        }
        TextRecognizer r = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        try {
            Text t = Tasks.await(r.process(InputImage.fromBitmap(aLire, 0)), 90, TimeUnit.SECONDS);
            return mettreEnForme(t, paragraphes);
        } finally {
            try {
                r.close();
            } catch (Exception ignore) {
            }
            if (aLire != b) aLire.recycle();
        }
    }

    private static String mettreEnForme(Text t, boolean paragraphes) {
        if (t == null) return "";
        StringBuilder sb = new StringBuilder();
        for (Text.TextBlock bloc : t.getTextBlocks()) {
            StringBuilder p = new StringBuilder();
            for (Text.Line l : bloc.getLines()) {
                String s = l.getText();
                if (s == null || s.trim().isEmpty()) continue;
                if (p.length() > 0) {
                    if (paragraphes) {
                        // Mot coupé en fin de ligne (« impor- tant ») : on recolle.
                        if (p.charAt(p.length() - 1) == '-' && p.length() > 1 && Character.isLetter(p.charAt(p.length() - 2)))
                            p.setLength(p.length() - 1);
                        else p.append(' ');
                    } else {
                        p.append('\n');
                    }
                }
                p.append(s.trim());
            }
            if (p.length() == 0) continue;
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(p);
        }
        return sb.toString().trim();
    }

    /** Message clair pour l'utilisateur à partir d'une erreur technique. */
    static String messageErreur(Throwable e) {
        Throwable cause = e;
        while (cause.getCause() != null && cause.getCause() != cause) cause = cause.getCause();
        if (cause instanceof OutOfMemoryError) return "Mémoire insuffisante pour cette image. Recadrez-la ou fermez d'autres applis.";
        if (cause instanceof java.util.concurrent.TimeoutException) return "La lecture a pris trop de temps. Réessayez avec une image plus petite.";
        String m = cause.getMessage();
        if (cause instanceof java.io.IOException && m != null) return m;
        return "Lecture impossible" + (m != null ? " (" + m + ")" : "");
    }
}
