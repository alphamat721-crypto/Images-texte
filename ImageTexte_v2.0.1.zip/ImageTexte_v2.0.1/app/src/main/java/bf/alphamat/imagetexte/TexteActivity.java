package bf.alphamat.imagetexte;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Un texte enregistré : lecture, modification (enregistrée automatiquement), copie, partage, export. */
public class TexteActivity extends Activity {

    static final String EXTRA_ID = "id";
    private static final int EXPORT = 31;

    private Visuel.Theme t;
    private Bibliotheque.Fiche fiche;
    private EditText zone;
    private TextView titre, infos;
    private boolean modifie, supprime;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        t = Visuel.theme(this);
        Visuel.barres(this, t);
        String id = getIntent().getStringExtra(EXTRA_ID);
        fiche = id == null ? null : Bibliotheque.lire(this, id);
        if (fiche == null) {
            Ui.toast(this, "Ce texte n'existe plus.");
            finish();
            return;
        }
        construire();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void construire() {
        FrameLayout racine = new FrameLayout(this);
        racine.addView(new Decor(this, t), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = Ui.colonne(this);
        col.setPadding(0, 0, 0, dp(24));

        LinearLayout entete = Ui.ligne(this);
        entete.setPadding(dp(8), dp(12), dp(12), dp(4));
        TextView retour = Ui.texte(this, "←", 24, t.texte, true);
        retour.setPadding(dp(10), 0, dp(12), 0);
        retour.setOnClickListener(v -> finish());
        entete.addView(retour);
        titre = Ui.texte(this, fiche.titre, 19, t.texte, true);
        titre.setMaxLines(2);
        entete.addView(titre, Ui.lpPoids(1));
        TextView renommer = Ui.texte(this, "✎", 20, t.accent, true);
        renommer.setPadding(dp(10), dp(4), dp(6), dp(4));
        renommer.setOnClickListener(v -> renommer());
        entete.addView(renommer);
        col.addView(entete);

        LinearLayout carte = Ui.colonne(this);
        carte.setBackground(Visuel.carte3D(this, t, 18));
        carte.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout haut = Ui.ligne(this);
        String v = fiche.vignette(this);
        if (v != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            try {
                Bitmap bm = BitmapFactory.decodeFile(v);
                if (bm != null) iv.setImageBitmap(bm);
            } catch (Throwable ignore) {
            }
            haut.addView(iv, Ui.lpMarges(this, dp(60), dp(60), 0, 0, 12, 0));
        }
        infos = Ui.texte(this, "", 12.5f, t.texteDoux, false);
        haut.addView(infos, Ui.lpPoids(1));
        carte.addView(haut);

        zone = new EditText(this);
        zone.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        zone.setGravity(Gravity.TOP | Gravity.START);
        zone.setTextColor(t.texte);
        zone.setTextSize(16);
        zone.setMinLines(8);
        zone.setText(fiche.texte);
        zone.setBackground(Visuel.puce(this, t, false));
        zone.setPadding(dp(12), dp(10), dp(12), dp(10));
        zone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                modifie = true;
                majInfos();
            }
        });
        carte.addView(zone, Ui.lpMarges(this, -1, -2, 0, 10, 0, 0));
        col.addView(carte, Ui.lpMarges(this, -1, -2, 14, 6, 14, 6));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout act = Ui.ligne(this);
        act.setPadding(dp(12), dp(4), dp(12), dp(4));
        act.addView(puce("📋 Copier", x -> Galerie.copier(this, zone.getText().toString())), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        act.addView(puce("📤 Partager", x -> Galerie.partagerTexte(this, zone.getText().toString())), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        act.addView(puce("⬇ Fichier .txt", x -> exporter()), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        act.addView(puce("🗑 Supprimer", x -> supprimer()), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        hs.addView(act);
        col.addView(hs);

        TextView note = Ui.texte(this, "Vos modifications sont enregistrées automatiquement.", 12, t.texteDoux, false);
        note.setPadding(dp(20), dp(8), dp(20), 0);
        col.addView(note);

        racine.addView(Ui.defilement(this, col), new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
        majInfos();
    }

    private TextView puce(String s, View.OnClickListener cl) {
        TextView p = Ui.texte(this, s, 13.5f, t.texte, true);
        p.setPadding(dp(12), dp(8), dp(12), dp(8));
        p.setBackground(Visuel.puce(this, t, false));
        p.setClickable(true);
        p.setOnClickListener(cl);
        Ui.pression(p);
        return p;
    }

    private void majInfos() {
        String s = zone == null ? fiche.texte : zone.getText().toString();
        int mots = s.trim().isEmpty() ? 0 : s.trim().split("\\s+").length;
        infos.setText("Lu le " + Ui.date(fiche.date) + "\n" + mots + (mots > 1 ? " mots" : " mot") + " • " + s.length() + " caractères");
    }

    private void renommer() {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(fiche.titre);
        e.setSelection(e.getText().length());
        LinearLayout box = Ui.colonne(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(e);
        Ui.dialogue(this, t).setTitle("Titre du texte").setView(box)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) return;
                    fiche.titre = s;
                    titre.setText(s);
                    modifie = true;
                    sauver();
                }).show();
    }

    private void supprimer() {
        Ui.dialogue(this, t).setTitle("Supprimer ce texte ?")
                .setMessage("Il sera effacé de l'appli (l'image d'origine n'est pas touchée).")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Supprimer", (d, w) -> {
                    Bibliotheque.supprimer(this, fiche.id);
                    supprime = true;
                    Ui.toastCourt(this, "Texte supprimé");
                    finish();
                }).show();
    }

    private void exporter() {
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/plain");
            String nom = fiche.titre.replaceAll("[\\\\/:*?\"<>|\\n]", " ").trim();
            if (nom.length() > 40) nom = nom.substring(0, 40).trim();
            i.putExtra(Intent.EXTRA_TITLE, (nom.isEmpty() ? "Texte" : nom) + ".txt");
            startActivityForResult(i, EXPORT);
        } catch (Exception e) {
            Ui.toast(this, "Aucune appli pour enregistrer un fichier.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != EXPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
            if (out == null) throw new java.io.IOException("Fichier inaccessible");
            out.write(zone.getText().toString().getBytes(StandardCharsets.UTF_8));
            Ui.toast(this, "Fichier texte enregistré.");
        } catch (Exception e) {
            Ui.toast(this, "Écriture impossible : " + e.getMessage());
        }
    }

    private void sauver() {
        if (supprime || !modifie || fiche == null || zone == null) return;
        fiche.texte = zone.getText().toString();
        try {
            Bibliotheque.enregistrer(this, fiche);
            modifie = false;
        } catch (Exception e) {
            Ui.toast(this, "Enregistrement impossible : " + e.getMessage());
        }
    }

    @Override
    protected void onPause() {
        sauver();
        super.onPause();
    }
}
