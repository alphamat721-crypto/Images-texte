package bf.alphamat.imagetexte;

import android.content.Context;
import android.content.SharedPreferences;

/** Réglages de l'application (un seul fichier « reglages »). */
final class Prefs {

    static final String THEME = "theme";
    static final String PREMIER = "premier";
    static final String MISE_EN_PAGE = "mise_en_page";     // 0 = lignes comme sur l'image, 1 = paragraphes
    static final String AMELIORER = "ameliorer";           // améliorer l'image avant la lecture
    static final String AUTO_ENREG = "auto_enreg";         // enregistrer automatiquement les textes lus
    static final String FORMAT = "format";                 // 0 JPEG, 1 PNG
    static final String QUALITE = "qualite";               // JPEG 60..100
    static final String TAILLE_RETOUCHE = "taille_retouche"; // 0 normale, 1 haute

    private Prefs() {
    }

    static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("reglages", Context.MODE_PRIVATE);
    }

    static boolean b(Context c, String k, boolean d) {
        try {
            return p(c).getBoolean(k, d);
        } catch (ClassCastException e) {
            return d;
        }
    }

    static int i(Context c, String k, int d) {
        try {
            return p(c).getInt(k, d);
        } catch (ClassCastException e) {
            return d;
        }
    }

    static void setB(Context c, String k, boolean v) {
        p(c).edit().putBoolean(k, v).apply();
    }

    static void setI(Context c, String k, int v) {
        p(c).edit().putInt(k, v).apply();
    }

    static boolean paragraphes(Context c) { return i(c, MISE_EN_PAGE, 0) == 1; }
    static boolean ameliorer(Context c) { return b(c, AMELIORER, false); }
    static boolean autoEnreg(Context c) { return b(c, AUTO_ENREG, true); }
    static boolean png(Context c) { return i(c, FORMAT, 0) == 1; }
    static int qualite(Context c) { return Math.max(60, Math.min(100, i(c, QUALITE, 92))); }

    /** Côté le plus long de l'image de travail dans l'éditeur (mémoire limitée sur la version Lite). */
    static int coteRetouche(Context c) {
        boolean haute = i(c, TAILLE_RETOUCHE, 0) == 1;
        if (BuildConfig.LITE) return haute ? 1600 : 1280;
        return haute ? 2560 : 1920;
    }

    /** Côté le plus long de l'image envoyée à la lecture de texte. */
    static int coteLecture() {
        return BuildConfig.LITE ? 2000 : 2600;
    }

    /** Nombre d'étapes « Annuler » gardées en mémoire dans l'éditeur. */
    static int historique() {
        return BuildConfig.LITE ? 4 : 8;
    }
}
