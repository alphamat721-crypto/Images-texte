package bf.alphamat.imagetexte;

import android.animation.LayoutTransition;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Menus repliables : ouvrir une section referme automatiquement celle qui était ouverte. */
final class Accordeon {

    private final Context c;
    private final Visuel.Theme t;
    private final LinearLayout racine;
    private final List<View> contenus = new ArrayList<>();
    private final List<TextView> chevrons = new ArrayList<>();
    private int ouverte = -1;

    Accordeon(Context c, Visuel.Theme t, LinearLayout racine) {
        this.c = c;
        this.t = t;
        this.racine = racine;
        LayoutTransition lt = new LayoutTransition();
        lt.enableTransitionType(LayoutTransition.CHANGING);
        racine.setLayoutTransition(lt);
    }

    LinearLayout section(String emoji, String titre, String resume) {
        final int index = contenus.size();
        LinearLayout bloc = Ui.colonne(c);
        bloc.setBackground(Visuel.carte3D(c, t, 18));
        bloc.setPadding(Ui.dp(c, 4), Ui.dp(c, 2), Ui.dp(c, 4), Ui.dp(c, 6));
        LayoutTransition lt = new LayoutTransition();
        lt.enableTransitionType(LayoutTransition.CHANGING);
        bloc.setLayoutTransition(lt);

        LinearLayout entete = Ui.ligne(c);
        entete.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 10));
        entete.setClickable(true);
        TextView e = Ui.texte(c, emoji, 22, t.texte, false);
        e.setPadding(0, 0, Ui.dp(c, 12), 0);
        entete.addView(e);
        LinearLayout tx = Ui.colonne(c);
        tx.addView(Ui.texte(c, titre, 16, t.texte, true));
        if (resume != null && !resume.isEmpty()) tx.addView(Ui.texte(c, resume, 12.5f, t.texteDoux, false));
        entete.addView(tx, Ui.lpPoids(1));
        TextView ch = Ui.texte(c, "⌄", 22, t.accent, true);
        ch.setGravity(Gravity.CENTER);
        entete.addView(ch, Ui.lp(Ui.dp(c, 32), Ui.dp(c, 32)));
        bloc.addView(entete);

        LinearLayout contenu = Ui.colonne(c);
        contenu.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), Ui.dp(c, 8));
        contenu.setVisibility(View.GONE);
        bloc.addView(contenu);

        entete.setOnClickListener(v -> basculer(index));
        contenus.add(contenu);
        chevrons.add(ch);
        racine.addView(bloc, Ui.lpMarges(c, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 14, 6, 14, 6));
        return contenu;
    }

    int ouverte() {
        return ouverte;
    }

    void ouvrir(int i) {
        if (i != ouverte) basculer(i);
    }

    private void basculer(int i) {
        for (int j = 0; j < contenus.size(); j++) {
            boolean ouvrir = (j == i) && ouverte != i;
            contenus.get(j).setVisibility(ouvrir ? View.VISIBLE : View.GONE);
            chevrons.get(j).animate().rotation(ouvrir ? 180f : 0f).setDuration(200).start();
        }
        ouverte = (ouverte == i) ? -1 : i;
    }
}
