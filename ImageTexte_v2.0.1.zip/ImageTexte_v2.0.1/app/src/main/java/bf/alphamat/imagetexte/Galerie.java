package bf.alphamat.imagetexte;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Enregistrement dans la galerie (Images/ImageTexte), partage et presse-papiers. */
final class Galerie {

    static final int DEMANDE_STOCKAGE = 701;
    static final String DOSSIER = "ImageTexte";

    private Galerie() {
    }

    /** Android 6 à 9 : l'écriture dans Images demande une autorisation. Renvoie true si on peut écrire tout de suite. */
    static boolean permissionOk(Activity a) {
        if (Build.VERSION.SDK_INT < 23 || Build.VERSION.SDK_INT >= 29) return true;
        if (a.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return true;
        a.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, DEMANDE_STOCKAGE);
        return false;
    }

    static String nom() {
        return "ImageTexte_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.FRANCE).format(new Date());
    }

    /** Enregistre l'image et renvoie son adresse dans la galerie. À appeler hors du fil principal. */
    static Uri enregistrer(Context c, Bitmap b, boolean png, int qualite) throws IOException {
        String nom = nom() + (png ? ".png" : ".jpg");
        String mime = png ? "image/png" : "image/jpeg";
        Bitmap aEcrire = (!png && b.hasAlpha()) ? Images.surFondBlanc(b) : b;
        try {
            ContentResolver cr = c.getContentResolver();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, nom);
                v.put(MediaStore.Images.Media.MIME_TYPE, mime);
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + DOSSIER);
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri u = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new IOException("La galerie refuse l'enregistrement");
                boolean ok = false;
                try (OutputStream out = cr.openOutputStream(u)) {
                    if (out == null) throw new IOException("Écriture impossible");
                    ok = aEcrire.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, qualite, out);
                } finally {
                    if (!ok) {
                        try {
                            cr.delete(u, null, null);
                        } catch (Exception ignore) {
                        }
                    }
                }
                if (!ok) throw new IOException("Écriture impossible");
                ContentValues fin = new ContentValues();
                fin.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(u, fin, null, null);
                return u;
            }
            @SuppressWarnings("deprecation")
            File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), DOSSIER);
            if (!d.isDirectory() && !d.mkdirs()) throw new IOException("Impossible de créer le dossier Images/" + DOSSIER);
            File f = new File(d, nom);
            try (OutputStream out = new FileOutputStream(f)) {
                if (!aEcrire.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, qualite, out))
                    throw new IOException("Écriture impossible");
            }
            Uri u = null;
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DATA, f.getAbsolutePath());
                v.put(MediaStore.Images.Media.DISPLAY_NAME, nom);
                v.put(MediaStore.Images.Media.MIME_TYPE, mime);
                v.put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
                v.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
                u = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            } catch (Exception ignore) {
            }
            MediaScannerConnection.scanFile(c.getApplicationContext(), new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
            return u != null ? u : Uri.fromFile(f);
        } finally {
            if (aEcrire != b) aEcrire.recycle();
        }
    }

    static void partagerImage(Activity a, Uri u, String mime) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(ClipData.newRawUri("image", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(i, "Partager l'image"));
        } catch (Exception e) {
            Ui.toast(a, "Aucune appli pour partager.");
        }
    }

    static void partagerTexte(Activity a, String texte) {
        if (texte == null || texte.trim().isEmpty()) {
            Ui.toast(a, "Aucun texte à partager.");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, texte);
            a.startActivity(Intent.createChooser(i, "Partager le texte"));
        } catch (Exception e) {
            Ui.toast(a, "Aucune appli pour partager.");
        }
    }

    static void copier(Context c, String texte) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Image Texte", texte));
                // Android 13+ affiche déjà sa propre confirmation.
                if (Build.VERSION.SDK_INT < 33) Ui.toastCourt(c, "Texte copié");
            }
        } catch (Exception e) {
            Ui.toast(c, "Copie impossible.");
        }
    }
}
