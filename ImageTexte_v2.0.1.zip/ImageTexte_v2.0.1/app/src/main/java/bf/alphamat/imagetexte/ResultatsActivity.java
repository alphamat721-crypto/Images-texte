package bf.alphamat.imagetexte;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Lecture du texte d'une ou plusieurs images, à la suite, avec résultat modifiable pour chacune. */
public class ResultatsActivity extends Activity {

    static final String EXTRA_SOURCES = "sources";
    private static final int RETOUCHE = 21, EXPORT = 22;

    private static final class Element {
        String source;
        String texte = "";
        String erreur;
        String idFiche;
        boolean fini, enregistre;
        Bitmap vignette;
        TextView etat, bEnreg;
        EditText zone;
        ImageView image;
        LinearLayout actions;
    }

    private Visuel.Theme t;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Element> elements = new ArrayList<>();
    private LinearLayout liste;
    private TextView progresTexte;
    private ProgressBar progres;
    private volatile boolean ferme;

    /** Prépare l'ouverture en transmettant l'autorisation de lire chaque image. */
    static Intent intention(Activity a, ArrayList<String> sources) {
        Intent i = new Intent(a, ResultatsActivity.class);
        i.putStringArrayListExtra(EXTRA_SOURCES, sources);
        ClipData cd = null;
        for (String s : sources) {
            if (s.startsWith("/")) continue;
            ClipData.Item it = new ClipData.Item(Uri.parse(s));
            if (cd == null) cd = new ClipData("images", new String[]{"image/*"}, it);
            else cd.addItem(it);
        }
        if (cd != null) {
            i.setClipData(cd);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        t = Visuel.theme(this);
        Visuel.barres(this, t);
        ArrayList<String> sources = getIntent().getStringArrayListExtra(EXTRA_SOURCES);
        if (sources == null || sources.isEmpty()) {
            Ui.toast(this, "Aucune image à lire.");
            finish();
            return;
        }
        for (String s : sources) {
            Element e = new Element();
            e.source = s;
            elements.add(e);
        }
        construire();
        lancer();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void construire() {
        FrameLayout racine = new FrameLayout(this);
        racine.addView(new Decor(this, t), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = Ui.colonne(this);
        col.setPadding(0, 0, 0, dp(24));

        LinearLayout entete = Ui.ligne(this);
        entete.setPadding(dp(8), dp(12), dp(16), dp(4));
        TextView retour = Ui.texte(this, "←", 24, t.texte, true);
        retour.setPadding(dp(10), 0, dp(12), 0);
        retour.setOnClickListener(v -> finish());
        entete.addView(retour);
        LinearLayout tit = Ui.colonne(this);
        tit.addView(Ui.texte(this, "Texte lu", 22, t.texte, true));
        tit.addView(Ui.texte(this, elements.size() == 1 ? "1 image" : elements.size() + " images", 13, t.texteDoux, false));
        entete.addView(tit, Ui.lpPoids(1));
        col.addView(entete);

        LinearLayout prog = Ui.colonne(this);
        prog.setBackground(Visuel.carte3D(this, t, 18));
        prog.setPadding(dp(16), dp(12), dp(16), dp(14));
        progresTexte = Ui.texte(this, "Préparation…", 14, t.texte, true);
        prog.addView(progresTexte);
        progres = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progres.setMax(elements.size());
        prog.addView(progres, Ui.lpMarges(this, -1, -2, 0, 6, 0, 0));
        col.addView(prog, Ui.lpMarges(this, -1, -2, 14, 6, 14, 6));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tout = Ui.ligne(this);
        tout.setPadding(dp(12), dp(2), dp(12), dp(4));
        tout.addView(puce("📋 Tout copier", v -> Galerie.copier(this, toutLeTexte(false))), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        tout.addView(puce("📤 Tout partager", v -> Galerie.partagerTexte(this, toutLeTexte(false))), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        if (elements.size() > 1)
            tout.addView(puce("🗂 Réunir en un seul texte", v -> reunir()), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        tout.addView(puce("⬇ Fichier .txt", v -> exporter()), Ui.lpMarges(this, -2, -2, 3, 0, 3, 0));
        hs.addView(tout);
        col.addView(hs);

        liste = Ui.colonne(this);
        for (int i = 0; i < elements.size(); i++) liste.addView(carte(i), Ui.lpMarges(this, -1, -2, 14, 6, 14, 6));
        col.addView(liste);

        TextView astuce = Ui.texte(this, "Texte mal lu ? Touchez « ✂️ Retoucher et relire » : recadrez la zone utile, puis Document › Remettre à plat ou Noir & blanc net.", 12.5f, t.texteDoux, false);
        astuce.setPadding(dp(20), dp(10), dp(20), 0);
        col.addView(astuce);

        racine.addView(Ui.defilement(this, col), new FrameLayout.LayoutParams(-1, -1));
        setContentView(racine);
    }

    private TextView puce(String s, View.OnClickListener cl) {
        TextView p = Ui.texte(this, s, 13.5f, t.texte, true);
        p.setPadding(dp(12), dp(8), dp(12), dp(8));
        p.setBackground(Visuel.puce(this, t, false));
        p.setClickable(true);
        p.setOnClickListener(cl);
        Ui.pression(p);
        return p;
    }

    private View carte(int i) {
        final Element e = elements.get(i);
        LinearLayout c = Ui.colonne(this);
        c.setBackground(Visuel.carte3D(this, t, 18));
        c.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout haut = Ui.ligne(this);
        e.image = new ImageView(this);
        e.image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        e.image.setBackground(Visuel.puce(this, t, false));
        haut.addView(e.image, Ui.lp(dp(56), dp(56)));
        LinearLayout tx = Ui.colonne(this);
        tx.setPadding(dp(12), 0, 0, 0);
        tx.addView(Ui.texte(this, "Image " + (i + 1), 15, t.texte, true));
        e.etat = Ui.texte(this, "En attente…", 12.5f, t.texteDoux, false);
        tx.addView(e.etat);
        haut.addView(tx, Ui.lpPoids(1));
        c.addView(haut);

        e.zone = new EditText(this);
        e.zone.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.zone.setGravity(Gravity.TOP | Gravity.START);
        e.zone.setTextColor(t.texte);
        e.zone.setHintTextColor(t.texteDoux);
        e.zone.setTextSize(15);
        e.zone.setMinLines(3);
        e.zone.setHint("Le texte lu apparaîtra ici");
        e.zone.setBackground(Visuel.puce(this, t, false));
        e.zone.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.zone.setEnabled(false);
        e.zone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!e.fini) return;
                String n = s.toString();
                if (!n.equals(e.texte)) {
                    e.texte = n;
                    if (e.enregistre) {
                        e.enregistre = false;
                        majEnreg(e);
                    }
                }
            }
        });
        c.addView(e.zone, Ui.lpMarges(this, -1, -2, 0, 10, 0, 8));

        e.actions = Ui.ligne(this);
        e.actions.addView(petit("📋 Copier", v -> Galerie.copier(this, e.texte)), Ui.lpMarges(this, -2, -2, 0, 0, 4, 0));
        e.actions.addView(petit("📤 Partager", v -> Galerie.partagerTexte(this, e.texte)), Ui.lpMarges(this, -2, -2, 4, 0, 4, 0));
        e.bEnreg = petit("💾 Enregistrer", v -> enregistrer(e, true));
        e.actions.addView(e.bEnreg, Ui.lpMarges(this, -2, -2, 4, 0, 4, 0));
        e.actions.addView(petit("✂️ Retoucher et relire", v -> retoucher(i)), Ui.lpMarges(this, -2, -2, 4, 0, 0, 0));
        e.actions.setVisibility(View.GONE);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(e.actions);
        c.addView(hs);
        return c;
    }

    private TextView petit(String s, View.OnClickListener cl) {
        TextView p = Ui.texte(this, s, 13, t.texte, true);
        p.setPadding(dp(10), dp(7), dp(10), dp(7));
        p.setBackground(Visuel.puce(this, t, false));
        p.setClickable(true);
        p.setOnClickListener(cl);
        Ui.pression(p);
        return p;
    }

    private void majEnreg(Element e) {
        if (e.bEnreg == null) return;
        e.bEnreg.setText(e.enregistre ? "✓ Enregistré" : (e.idFiche != null ? "💾 Enregistrer les modifs" : "💾 Enregistrer"));
        e.bEnreg.setBackground(Visuel.puce(this, t, e.enregistre));
        e.bEnreg.setTextColor(e.enregistre ? 0xFFFFFFFF : t.texte);
    }

    // ------------------------------------------------------------------ Lecture

    private void lancer() {
        final boolean amel = Prefs.ameliorer(this);
        final boolean para = Prefs.paragraphes(this);
        final boolean auto = Prefs.autoEnreg(this);
        final List<Element> aLire = new ArrayList<>(elements);
        App.travail().execute(() -> {
            for (int i = 0; i < aLire.size() && !ferme; i++) {
                final int n = i;
                ui.post(() -> {
                    progresTexte.setText("Lecture de l'image " + (n + 1) + " sur " + aLire.size() + "…");
                    aLire.get(n).etat.setText("Lecture en cours…");
                });
                lireUn(aLire.get(i), amel, para, auto);
                ui.post(() -> progres.setProgress(n + 1));
            }
            ui.post(this::bilan);
        });
    }

    /** Lit une image (fil de travail). */
    private void lireUn(Element e, boolean amel, boolean para, boolean auto) {
        Bitmap b = null;
        String texte = null, err = null;
        Bitmap vign = null;
        try {
            b = Images.charger(this, e.source, Prefs.coteLecture());
            try {
                int lg = Math.max(b.getWidth(), b.getHeight());
                vign = Bitmap.createScaledBitmap(b, Math.max(1, b.getWidth() * 220 / lg), Math.max(1, b.getHeight() * 220 / lg), true);
                if (vign == b) vign = b.copy(Bitmap.Config.ARGB_8888, false);
            } catch (Throwable ignore) {
            }
            texte = Lecteur.lire(b, amel, para);
        } catch (Throwable ex) {
            err = Lecteur.messageErreur(ex);
        }
        boolean sauve = false;
        if (texte != null && !texte.isEmpty() && auto && !ferme) {
            try {
                Bibliotheque.Fiche f = new Bibliotheque.Fiche();
                f.id = e.idFiche;
                f.texte = texte;
                if (e.idFiche != null) {
                    Bibliotheque.Fiche ancienne = Bibliotheque.lire(this, e.idFiche);
                    if (ancienne != null) {
                        f.date = ancienne.date;
                        f.titre = ancienne.titre;
                    }
                }
                Bibliotheque.enregistrer(this, f);
                if (b != null) Bibliotheque.enregistrerVignette(this, f.id, b);
                e.idFiche = f.id;
                sauve = true;
            } catch (Exception ignore) {
            }
        }
        if (b != null) b.recycle();
        final String ft = texte, fe = err;
        final Bitmap fv = vign;
        final boolean fs = sauve;
        ui.post(() -> {
            e.fini = true;
            e.erreur = fe;
            e.texte = ft == null ? "" : ft;
            if (fv != null) {
                if (e.vignette != null && e.vignette != fv) e.image.setImageDrawable(null);
                e.vignette = fv;
                e.image.setImageBitmap(fv);
            }
            e.zone.setEnabled(true);
            e.zone.setText(e.texte);
            e.enregistre = fs;
            if (fe != null) {
                e.etat.setText("⚠ " + fe);
            } else if (e.texte.isEmpty()) {
                e.etat.setText("Aucun texte trouvé. Essayez « Retoucher et relire ».");
            } else {
                int mots = e.texte.trim().split("\\s+").length;
                e.etat.setText(mots + (mots > 1 ? " mots" : " mot") + (fs ? " • enregistré dans Textes" : ""));
            }
            e.actions.setVisibility(View.VISIBLE);
            majEnreg(e);
        });
    }

    private void bilan() {
        if (ferme) return;
        int ok = 0, vides = 0, erreurs = 0;
        for (Element e : elements) {
            if (e.erreur != null) erreurs++;
            else if (e.texte.isEmpty()) vides++;
            else ok++;
        }
        StringBuilder sb = new StringBuilder("Terminé : ");
        sb.append(ok).append(ok > 1 ? " textes lus" : " texte lu");
        if (vides > 0) sb.append(" • ").append(vides).append(" sans texte");
        if (erreurs > 0) sb.append(" • ").append(erreurs).append(erreurs > 1 ? " erreurs" : " erreur");
        progresTexte.setText(sb.toString());
        progres.setProgress(progres.getMax());
    }

    // ------------------------------------------------------------------ Actions

    private void enregistrer(Element e, boolean message) {
        if (!e.fini) return;
        if (e.texte.trim().isEmpty()) {
            Ui.toastCourt(this, "Rien à enregistrer");
            return;
        }
        try {
            Bibliotheque.Fiche f = e.idFiche != null ? Bibliotheque.lire(this, e.idFiche) : null;
            boolean nouveau = f == null;
            if (nouveau) f = new Bibliotheque.Fiche();
            f.texte = e.texte;
            Bibliotheque.enregistrer(this, f);
            if (e.vignette != null && nouveau) Bibliotheque.enregistrerVignette(this, f.id, e.vignette);
            e.idFiche = f.id;
            e.enregistre = true;
            majEnreg(e);
            if (message) Ui.toastCourt(this, "Enregistré dans Textes");
        } catch (Exception ex) {
            Ui.toast(this, "Enregistrement impossible : " + ex.getMessage());
        }
    }

    private String toutLeTexte(boolean avecTitres) {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (int i = 0; i < elements.size(); i++) {
            Element e = elements.get(i);
            if (e.texte.trim().isEmpty()) continue;
            if (sb.length() > 0) sb.append("\n\n");
            if (avecTitres && elements.size() > 1) sb.append("— Image ").append(i + 1).append(" —\n");
            sb.append(e.texte.trim());
            n++;
        }
        return n == 0 ? "" : sb.toString();
    }

    private void reunir() {
        String tout = toutLeTexte(true);
        if (tout.isEmpty()) {
            Ui.toastCourt(this, "Aucun texte à réunir");
            return;
        }
        try {
            Bibliotheque.Fiche f = new Bibliotheque.Fiche();
            f.texte = tout;
            f.titre = Bibliotheque.titreAuto(tout.replaceFirst("^— Image 1 —\n", "")) + " (" + elements.size() + " images)";
            Bibliotheque.enregistrer(this, f);
            for (Element e : elements) {
                if (e.vignette != null) {
                    Bibliotheque.enregistrerVignette(this, f.id, e.vignette);
                    break;
                }
            }
            Ui.toast(this, "Les textes sont réunis en un seul, dans Textes.");
        } catch (Exception ex) {
            Ui.toast(this, "Enregistrement impossible : " + ex.getMessage());
        }
    }

    private void exporter() {
        if (toutLeTexte(false).isEmpty()) {
            Ui.toastCourt(this, "Aucun texte à exporter");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TITLE, Galerie.nom() + ".txt");
            startActivityForResult(i, EXPORT);
        } catch (Exception e) {
            Ui.toast(this, "Aucune appli pour enregistrer un fichier.");
        }
    }

    private void retoucher(int i) {
        Element e = elements.get(i);
        if (!e.fini) return;
        try {
            startActivityForResult(EditeurActivity.intention(this, e.source, true, i), RETOUCHE);
        } catch (Exception ex) {
            Ui.toast(this, "Ouverture impossible.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == EXPORT && data.getData() != null) {
            String tout = toutLeTexte(true);
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                if (out == null) throw new java.io.IOException("Fichier inaccessible");
                out.write(tout.getBytes(StandardCharsets.UTF_8));
                Ui.toast(this, "Fichier texte enregistré.");
            } catch (Exception ex) {
                Ui.toast(this, "Écriture impossible : " + ex.getMessage());
            }
        } else if (req == RETOUCHE) {
            String chemin = data.getStringExtra(EditeurActivity.RESULTAT_CHEMIN);
            int idx = data.getIntExtra(EditeurActivity.EXTRA_INDEX, -1);
            if (chemin == null || idx < 0 || idx >= elements.size()) return;
            final Element e = elements.get(idx);
            e.source = chemin;
            e.fini = false;
            e.zone.setEnabled(false);
            e.actions.setVisibility(View.GONE);
            e.etat.setText("Nouvelle lecture…");
            final boolean amel = Prefs.ameliorer(this), para = Prefs.paragraphes(this);
            // Relecture : on met à jour le texte déjà enregistré s'il existe, sinon on suit le réglage automatique.
            final boolean auto = e.idFiche != null || Prefs.autoEnreg(this);
            App.travail().execute(() -> lireUn(e, amel, para, auto));
        }
    }

    @Override
    protected void onDestroy() {
        ferme = true;
        super.onDestroy();
    }
}
