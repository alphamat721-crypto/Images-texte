package bf.alphamat.imagetexte;

import android.content.Context;
import android.graphics.Bitmap;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Les textes enregistrés : un petit fichier JSON par texte + une vignette de l'image d'origine. */
final class Bibliotheque {

    static final class Fiche {
        String id;
        String titre;
        String texte;
        long date;
        long modif;

        String vignette(Context c) {
            File f = fichierVignette(c, id);
            return f.isFile() ? f.getAbsolutePath() : null;
        }
    }

    private Bibliotheque() {
    }

    private static File dossier(Context c) {
        File d = new File(c.getFilesDir(), "textes");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    private static File fichierVignette(Context c, String id) {
        File d = new File(c.getFilesDir(), "vignettes");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return new File(d, id + ".jpg");
    }

    static String nouvelId() {
        return Long.toString(System.currentTimeMillis(), 36) + Integer.toString((int) (Math.random() * 1296), 36);
    }

    /** Titre automatique : la première ligne utile du texte, raccourcie. */
    static String titreAuto(String texte) {
        if (texte == null) return "Texte sans titre";
        for (String l : texte.split("\n")) {
            String s = l.trim();
            if (s.length() >= 2) return s.length() > 48 ? s.substring(0, 46).trim() + "…" : s;
        }
        return "Texte sans titre";
    }

    static synchronized void enregistrer(Context c, Fiche f) throws IOException {
        if (f.id == null) f.id = nouvelId();
        if (f.date == 0) f.date = System.currentTimeMillis();
        f.modif = System.currentTimeMillis();
        if (f.titre == null || f.titre.trim().isEmpty()) f.titre = titreAuto(f.texte);
        try {
            JSONObject o = new JSONObject();
            o.put("id", f.id);
            o.put("titre", f.titre);
            o.put("texte", f.texte == null ? "" : f.texte);
            o.put("date", f.date);
            o.put("modif", f.modif);
            File fin = new File(dossier(c), f.id + ".json");
            File tmp = new File(dossier(c), f.id + ".json.tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (!tmp.renameTo(fin)) {
                // Certains systèmes refusent d'écraser : on supprime puis on renomme.
                //noinspection ResultOfMethodCallIgnored
                fin.delete();
                if (!tmp.renameTo(fin)) throw new IOException("Enregistrement impossible");
            }
        } catch (org.json.JSONException e) {
            throw new IOException(e.getMessage());
        }
    }

    /** Petite vignette de l'image d'origine (facultative). */
    static void enregistrerVignette(Context c, String id, Bitmap b) {
        if (b == null || id == null) return;
        try {
            Bitmap v = Bitmap.createScaledBitmap(b, Math.max(1, b.getWidth() * 360 / Math.max(b.getWidth(), b.getHeight())),
                    Math.max(1, b.getHeight() * 360 / Math.max(b.getWidth(), b.getHeight())), true);
            Bitmap blanc = v.hasAlpha() ? Images.surFondBlanc(v) : v;
            try (OutputStream out = new FileOutputStream(fichierVignette(c, id))) {
                blanc.compress(Bitmap.CompressFormat.JPEG, 82, out);
            }
            if (blanc != v) blanc.recycle();
            if (v != b) v.recycle();
        } catch (Throwable ignore) {
        }
    }

    static synchronized Fiche lire(Context c, String id) {
        return lireFichier(new File(dossier(c), id + ".json"));
    }

    private static Fiche lireFichier(File f) {
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[(int) Math.min(f.length(), 8 * 1024 * 1024)];
            int lu = 0, n;
            while (lu < buf.length && (n = in.read(buf, lu, buf.length - lu)) > 0) lu += n;
            JSONObject o = new JSONObject(new String(buf, 0, lu, StandardCharsets.UTF_8));
            Fiche fi = new Fiche();
            fi.id = o.getString("id");
            fi.titre = o.optString("titre", "Texte");
            fi.texte = o.optString("texte", "");
            fi.date = o.optLong("date", f.lastModified());
            fi.modif = o.optLong("modif", fi.date);
            return fi;
        } catch (Exception e) {
            return null;
        }
    }

    /** Tous les textes, les plus récents d'abord. {@code filtre} cherche dans le titre et le texte (sans accents). */
    static synchronized List<Fiche> liste(Context c, String filtre) {
        List<Fiche> l = new ArrayList<>();
        File[] fs = dossier(c).listFiles();
        if (fs == null) return l;
        String q = filtre == null ? "" : simplifier(filtre.trim());
        for (File f : fs) {
            if (!f.getName().endsWith(".json")) continue;
            Fiche fi = lireFichier(f);
            if (fi == null) continue;
            if (!q.isEmpty() && !simplifier(fi.titre + " " + fi.texte).contains(q)) continue;
            l.add(fi);
        }
        Collections.sort(l, (a, b) -> Long.compare(b.date, a.date));
        return l;
    }

    static synchronized int nombre(Context c) {
        File[] fs = dossier(c).listFiles();
        if (fs == null) return 0;
        int n = 0;
        for (File f : fs) if (f.getName().endsWith(".json")) n++;
        return n;
    }

    static synchronized void supprimer(Context c, String id) {
        //noinspection ResultOfMethodCallIgnored
        new File(dossier(c), id + ".json").delete();
        //noinspection ResultOfMethodCallIgnored
        fichierVignette(c, id).delete();
    }

    static synchronized void toutSupprimer(Context c) {
        for (Fiche f : liste(c, null)) supprimer(c, f.id);
    }

    static String simplifier(String s) {
        String n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").toLowerCase(Locale.FRANCE);
    }

    /** Tous les textes réunis (pour l'export en un seul fichier .txt). */
    static String toutEnUn(Context c) {
        StringBuilder sb = new StringBuilder();
        for (Fiche f : liste(c, null)) {
            if (sb.length() > 0) sb.append("\n\n────────────────────\n\n");
            sb.append(f.titre).append("  (").append(Ui.date(f.date)).append(")\n\n").append(f.texte);
        }
        return sb.toString();
    }
}
