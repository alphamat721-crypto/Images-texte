package bf.alphamat.imagetexte;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mises à jour depuis le dépôt public de toutes les applis d'Alphamat (alphamat721-crypto/alphamat-applis).
 * Chaque appli y a une Release fixe « prefixe » (ex. « sonorix ») qui contient toujours la dernière version :
 * son texte dit « Dernière version : X.Y.Z. » et ses fichiers ont des noms constants (Nom.apk, Nom_Lite.apk).
 * Une seule petite requête, sans rien envoyer sur l'utilisateur.
 */
public final class MisesAJour {

    private static final String DEPOT = "alphamat721-crypto/alphamat-applis";
    private static final String PAGE = "https://github.com/" + DEPOT;
    private static final long UN_JOUR = 24L * 3600 * 1000;
    private static final String FICHIER = "mises_a_jour";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static boolean enCours;

    private MisesAJour() {
    }

    /** Au démarrage : au plus une fois par jour, en silence si tout est à jour ou si Internet manque. */
    public static void auDemarrage(Activity a) {
        try {
            SharedPreferences p = a.getSharedPreferences(FICHIER, Context.MODE_PRIVATE);
            if (!p.getBoolean("auto", true)) return;
            if (System.currentTimeMillis() - p.getLong("derniere", 0) < UN_JOUR) return;
            verifier(a, false);
        } catch (Throwable ignore) {
        }
    }

    /** Active ou coupe la recherche automatique au démarrage. */
    public static void setAuto(Context c, boolean oui) {
        c.getSharedPreferences(FICHIER, Context.MODE_PRIVATE).edit().putBoolean("auto", oui).apply();
    }

    public static boolean auto(Context c) {
        return c.getSharedPreferences(FICHIER, Context.MODE_PRIVATE).getBoolean("auto", true);
    }

    /** {@code manuel} : l'utilisateur a demandé, on répond toujours (à jour, pas d'Internet…). */
    public static void verifier(final Activity a, final boolean manuel) {
        if (enCours) return;
        final String prefixe = prefixe(a.getPackageName());
        if (prefixe == null) {
            if (manuel) toast(a, "Mises à jour non disponibles pour cette appli.");
            return;
        }
        enCours = true;
        final Context app = a.getApplicationContext();
        if (manuel) toast(a, "Recherche d'une nouvelle version…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String version = null, lien = null;
                boolean erreur = false;
                try {
                    JSONObject o = new JSONObject(lire("https://api.github.com/repos/" + DEPOT + "/releases/tags/" + prefixe));
                    Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)+)").matcher(o.optString("body", ""));
                    if (m.find()) version = m.group(1);
                    boolean lite = estLite(app);
                    String complet = null, leger = null;
                    JSONArray as = o.optJSONArray("assets");
                    if (as != null) {
                        for (int k = 0; k < as.length(); k++) {
                            JSONObject x = as.getJSONObject(k);
                            String n = x.optString("name", "");
                            if (!n.endsWith(".apk")) continue;
                            if (n.contains("_Lite")) leger = x.optString("browser_download_url", null);
                            else complet = x.optString("browser_download_url", null);
                        }
                    }
                    lien = lite && leger != null ? leger : complet;
                    if (lien == null) lien = o.optString("html_url", PAGE);
                } catch (Throwable e) {
                    erreur = true;
                }
                final String fv = version, fl = lien;
                final boolean fe = erreur || version == null;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        enCours = false;
                        SharedPreferences p = app.getSharedPreferences(FICHIER, Context.MODE_PRIVATE);
                        if (!fe) p.edit().putLong("derniere", System.currentTimeMillis()).apply();
                        if (a.isFinishing()) return;
                        String nom = nomAppli(app), actuelle = versionActuelle(app);
                        if (fe) {
                            if (manuel) toast(a, "Vérification impossible pour le moment (pas d'Internet ?). Réessayez plus tard.");
                            return;
                        }
                        if (comparer(fv, actuelle) <= 0) {
                            if (manuel) toast(a, nom + " est à jour (v" + actuelle + ").");
                            return;
                        }
                        if (!manuel && fv.equals(p.getString("ignoree", ""))) return;
                        proposer(a, nom, actuelle, fv, fl);
                    }
                });
            }
        }).start();
    }

    private static void proposer(final Activity a, String nom, String actuelle, final String version, final String lien) {
        try {
            new AlertDialog.Builder(a)
                    .setTitle("🎉 Nouvelle version de " + nom)
                    .setMessage("La version " + version + " est disponible (vous avez la " + actuelle + ").\n\n"
                            + "Touchez « Télécharger », puis ouvrez le fichier téléchargé et installez-le par-dessus : "
                            + "vos réglages et vos données sont gardés.")
                    .setPositiveButton("Télécharger", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            ouvrir(a, lien);
                        }
                    })
                    .setNegativeButton("Plus tard", null)
                    .setNeutralButton("Ignorer cette version", new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface d, int w) {
                            a.getSharedPreferences(FICHIER, Context.MODE_PRIVATE).edit().putString("ignoree", version).apply();
                        }
                    })
                    .show();
        } catch (Throwable ignore) {
        }
    }

    private static void ouvrir(Activity a, String lien) {
        try {
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(lien)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable e) {
            toast(a, "Aucun navigateur pour ouvrir : " + lien);
        }
    }

    /** Nom de la Release fixe de chaque appli dans alphamat-applis, d'après le nom du paquet. */
    static String prefixe(String paquet) {
        String p = paquet.replace(".lite", "").replace("bf.alphamat.", "");
        switch (p) {
            case "kibaru": return "appelo";
            case "avconverter": return "filesconverter";
            case "enregistreur": return "enregistreurappels";
            case "hvplus": case "imagetexte": case "capturegest": case "sonorix": case "clavierchic":
            case "statubox": case "blocbulles": case "calculmalin": case "motsmalins": case "petitgenie":
            case "bingo": case "matstorieslab": case "fasotiim": case "suguraaga": case "retour":
                return p;
            default: return null;
        }
    }

    private static boolean estLite(Context c) {
        return c.getPackageName().endsWith(".lite") || versionBrute(c).toLowerCase().contains("lite");
    }

    private static String versionBrute(Context c) {
        try {
            PackageInfo i = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return i.versionName == null ? "0" : i.versionName;
        } catch (Throwable e) {
            return "0";
        }
    }

    private static String versionActuelle(Context c) {
        Matcher m = Pattern.compile("([0-9]+(?:\\.[0-9]+)*)").matcher(versionBrute(c));
        return m.find() ? m.group(1) : "0";
    }

    private static String nomAppli(Context c) {
        try {
            return String.valueOf(c.getApplicationInfo().loadLabel(c.getPackageManager()));
        } catch (Throwable e) {
            return "l'appli";
        }
    }

    private static void toast(Context c, String s) {
        try {
            Toast.makeText(c, s, Toast.LENGTH_LONG).show();
        } catch (Throwable ignore) {
        }
    }

    private static String lire(String adresse) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(adresse).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "Alphamat-Applis");
        try {
            if (c.getResponseCode() != 200) throw new Exception("réponse " + c.getResponseCode());
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0 && out.size() < 256 * 1024) out.write(b, 0, n);
                return out.toString("UTF-8");
            } finally {
                in.close();
            }
        } finally {
            c.disconnect();
        }
    }

    /** Compare « 2.3.0 » et « 2.2.10 » chiffre par chiffre ; > 0 si a est plus récente. */
    static int comparer(String a, String b) {
        String[] x = a.split("\\."), y = b.split("\\.");
        for (int k = 0; k < Math.max(x.length, y.length); k++) {
            int i = k < x.length ? entier(x[k]) : 0, j = k < y.length ? entier(y[k]) : 0;
            if (i != j) return i < j ? -1 : 1;
        }
        return 0;
    }

    private static int entier(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }
}
